# ALTIORA : business plans assistés par IA

Une seule fonctionnalité : **construire un business plan en co-construction avec un pipeline d'agents IA**, puis l'exécuter et le suivre.

**Stack** : React (Vite) · Node.js + Express · MySQL · Groq (API compatible OpenAI)

## Démarrage

```bash
# 1. Backend
cd backend
cp .env.example .env        # renseigner DB_*, JWT_SECRET, GROQ_API_KEY
npm install
npm run db:init             # crée la base et les tables
npm run dev                 # http://localhost:4000

# 2. Frontend (autre terminal)
cd frontend
npm install
npm run dev                 # http://localhost:5173  (proxy /api vers :4000)
```

### Vérifier la connexion à Groq (à faire en premier)

```bash
cd backend
npm run check:groq
```

Le script vérifie : clé présente et valide, modèle principal et modèle de secours disponibles, et un vrai appel en mode JSON.
Au démarrage, le serveur refait la vérification et l'affiche dans la console. L'écran d'accueil montre aussi « IA Groq connectée » ou la cause du problème.

Clé Groq : https://console.groq.com. Le modèle se change avec `GROQ_MODEL`.

**Modèles gpt-oss (configuration par défaut : `openai/gpt-oss-120b`, secours `openai/gpt-oss-20b`)** : ce sont des modèles à raisonnement. Le client Groq leur envoie `include_reasoning: false` et `reasoning_effort` (variable `GROQ_REASONING_EFFORT`, `low` par défaut), ajoute une marge de 1 500 tokens car le raisonnement consomme le budget de sortie, et bascule sur le modèle de secours si la réponse revient vide ou tronquée. Ces paramètres ne sont envoyés qu'aux modèles gpt-oss, jamais aux autres (llama, etc.).

### Comportement du client Groq (`services/groq.js`)

| Situation | Réaction |
|---|---|
| Limite de débit 429 courte | Attend le délai indiqué par Groq puis réessaie (jusqu'à 4 fois) |
| Quota épuisé ou attente trop longue | Bascule sur `GROQ_FALLBACK_MODEL` (autre quota), sinon message clair avec la durée d'attente |
| Modèle retiré ou inexistant | Bascule sur le modèle de secours et indique de corriger `GROQ_MODEL` |
| JSON invalide (`json_validate_failed`) | Réessaie sans le mode JSON, puis extrait le JSON de la réponse |
| Réponse illisible | Deuxième appel à température plus basse |
| Clé invalide ou refusée (401/403) | Message explicite, sans nouvelle tentative inutile |
| Erreur 5xx ou réseau | Réessaie avec attente progressive |

Sur l'offre gratuite de Groq, la limite de tokens par minute peut ralentir les générations : une génération de section utilise 3 appels (méta-prompt, rédaction, analyse).

### Tester sans clé ni quota

```bash
cd backend
npm run dev:mock                     # faux serveur Groq sur :4900
GROQ_BASE_URL=http://localhost:4900/openai/v1 GROQ_API_KEY=test npm run dev
```

### Tests automatiques

```bash
cd backend
npm run db:init      # base de test (DB_NAME)
npm test             # 48 tests : moteur financier, client Groq, API complète avec MySQL réel, exports
```

## Le pipeline d'agents

| Agent | Rôle | Fichier |
|---|---|---|
| Planification | À partir des 3 champs, prépare le titre et le détail de chaque section, transmis aux autres agents | `agents/planner.js` |
| Méta-prompt | En coulisses, transforme la demande de l'utilisateur en instruction complète (contexte, réponses aux questions, corrections à apporter) | `agents/metaPrompt.js` |
| Rédacteur | Rédige une section à la fois | `agents/redacteur.js` |
| Analyste / guide | Note la section (grille par section), liste les manques, pose des questions, suggère une nouvelle instruction | `agents/analyste.js` |
| Cohérence finale | Relit tout le plan avant la génération du document | `agents/analyste.js` |
| Suivi | Transforme le plan en tâches, jalons et KPI, puis fait le bilan de l'avancement | `agents/suivi.js` |

Le code (`services/orchestrator.js`) enchaîne les agents : la sortie JSON de l'un devient l'entrée du suivant. Le rédacteur et l'analyste sont volontairement séparés.

## Flux utilisateur

1. **Création** : 3 champs (idée, secteur, clients visés). L'agent de planification prépare les 9 sections.
2. **Par section** : instruction (pré-remplie, modifiable) → méta-prompt caché → rédaction → analyse → guidage (note, manques, questions) → l'utilisateur répond, modifie ou relance → validation.
3. **Modèle financier** (onglet Finances) : l'utilisateur saisit ses hypothèses ; le programme calcule les chiffres. L'IA rédige ensuite la section « Plan financier » (et le résumé exécutif) en s'appuyant uniquement sur ces chiffres.
4. **Génération finale** : possible quand toutes les sections sont validées et que les textes chiffrés correspondent aux hypothèses actuelles. Document assemblé, annexe financière calculée, contrôle de cohérence, puis export Word ou PDF.
5. **Exécution et suivi** : l'utilisateur choisit la date de début. Chaque tâche reçoit une échéance datée, un statut, un avancement, une note et un KPI. Les retards sont détectés automatiquement, l'avancement réel est comparé à l'avancement prévu, les tâches sont modifiables, ajoutables et supprimables, et l'IA fait un bilan.
6. **À tout moment avant l'exécution** : le projet (3 champs) reste modifiable ; l'agent de planification peut refaire le détail des sections non validées sans toucher aux sections validées.

## Design et langues

Interface v2 : barre latérale et barre supérieure (langue, luminosité, état de l'IA, compte), parcours en 4 étapes, fenêtres modales, alertes rouge/ambre/vert/bleu toujours accompagnées d'une icône, graphiques avec infobulle, tableaux localisés, mobile et clavier pris en charge. Détails : `frontend/DESIGN_GUIDE.md`.

**Langues : français et malgache.** Le choix (en haut de chaque écran) est mémorisé et envoyé au backend (en-tête `X-Lang`) :
- interface : `frontend/src/shared/locales/fr.js` et `mg.js` ;
- IA : le backend ajoute une consigne « rédige en malgache » à chaque appel (`services/groq.js`) ;
- alertes du moteur financier : le backend envoie un code et des valeurs (`warning_items`), le texte est rédigé dans la langue active ;
- exports Word/PDF et document final : libellés fixes dans `services/labels.js` ;
- messages d'erreur du serveur : traduits côté frontend (`SERVER_ERRORS` dans `mg.js`).
Les traductions malgaches sont à relire par un locuteur natif, surtout le vocabulaire financier.

## Moteur financier (calculs en code, sans IA)

Fichiers : `services/finance/model.js` (calcul), `format.js` (tableaux et annexe), onglet **Finances** côté interface.

**Hypothèses saisies** : devise, durée (12 à 60 mois), prix par client et par mois, frais d'installation, clients au démarrage, nouveaux clients par mois et leur croissance, churn, hausse annuelle des prix, coût d'acquisition (CAC), coûts directs en % du chiffre d'affaires, charges fixes (avec mois de départ), hausse annuelle des coûts, investissement initial, financement initial et tours supplémentaires, délai de paiement des clients, impôt.

**Résultats calculés** : mois par mois (clients, chiffre d'affaires, coûts, résultat d'exploitation, impôt, encaissements, trésorerie, créances), synthèse par année, et indicateurs : point mort durable, récupération de l'investissement, trésorerie minimale, financement supplémentaire nécessaire, LTV, ratio LTV/CAC, récupération du CAC, revenu annuel récurrent.

**Alertes automatiques** (générées par le code) : trésorerie négative, absence de point mort, churn élevé, LTV/CAC inférieur à 3, CAC récupéré trop lentement, délai de paiement long, croissance irréaliste, absence de charges fixes.

**Rôle de l'IA** :
- Elle peut pré-remplir les hypothèses, mais seulement avec des valeurs déjà écrites dans le plan ; les valeurs hors bornes sont écartées par le code et l'utilisateur vérifie avant d'enregistrer.
- Elle rédige la section « Plan financier » et le résumé exécutif à partir des chiffres du moteur (qui font foi). L'analyste vérifie la cohérence entre le texte et le modèle.
- Si les hypothèses changent après la rédaction, ces sections sont signalées comme périmées et la génération finale est bloquée tant qu'elles ne sont pas régénérées.

**Simplifications à connaître** : les clients sont calculés en décimales (moyenne) ; l'impôt est appliqué au résultat positif sans report de déficit ; les frais d'installation et le CAC suivent respectivement la hausse des prix et des coûts ; les créances en fin de période ne sont pas encaissées.

## Export Word et PDF (fichiers réels)

Boutons dans l'onglet « Business plan » : `GET /api/business-plans/:id/export/docx` et `/export/pdf`.

- **Word (.docx)** : page de garde, sommaire cliquable, titres, listes, tableaux, en-tête et numéros de page, annexe financière (tableaux) et plan d'exécution si le suivi est lancé.
- **PDF** : mêmes contenus, avec un sommaire numéroté et en plus deux graphiques (chiffre d'affaires contre charges, trésorerie), polices intégrées (Public Sans et Bricolage Grotesque), tableaux dont l'en-tête se répète à chaque page.
- Le texte de l'IA (Markdown) est converti en vrais titres, listes, tableaux, gras et italique. Les caractères que la police PDF ne possède pas (emojis, flèches) sont remplacés ou retirés pour éviter les carrés vides.
- Un titre que l'IA répéterait au début d'une section est retiré (le titre est déjà ajouté par l'application). Une table ne laisse jamais une seule ligne isolée sur la dernière page.
- Le contrôle de cohérence reste dans l'application : c'est un outil de travail, il n'est pas imprimé dans le document remis.
- Disponible dès que le business plan final est généré, même pendant l'exécution.

## Traçabilité des demandes de l'encadreur

| R | Demande | Implémentation |
|---|---|---|
| R1 | Intégrer dans l'application existante | Routeur Express `routes/businessPlan.js` et dossier `frontend/src/features/business-plan/`, branchables tels quels. `middleware/auth.js` et `AuthContext` sont à remplacer par l'authentification existante |
| R2 | Pipeline multi-agents | `services/orchestrator.js` + `services/agents/*` |
| R3, R4 | Peu d'informations à saisir | Formulaire à 3 champs (`PlansPage.jsx`) ; l'agent de planification produit le détail |
| R5 | Fifandraisana IA sécurisé | Clé Groq uniquement dans `.env` du backend, JWT, helmet, CORS, rate limiting, validation zod |
| R6 | Interface de prompt | `SectionEditor.jsx` |
| R7 | Méta-prompt caché | `agents/metaPrompt.js` ; stocké mais jamais renvoyé au frontend |
| R8 | Peaufinage itératif | Régénération illimitée, édition manuelle, historique et restauration des versions |
| R9 | Agent de planification | `agents/planner.js` à la création, et à chaque modification du projet (`PATCH /:id` puis `POST /:id/replan`) ; les sections validées ne sont jamais écrasées |
| R10 | Exécution et suivi « selon le plan » | `agents/suivi.js`, `Tracking.jsx` ; tâches datées à partir de la date de début, retards détectés, avancement réel comparé au prévu, tâches modifiables / ajoutables / supprimables, bilan IA |
| R11 | Pas un simple « info → générer » | Boucle par section, avec seuil de validation |
| R12 | Prompt utilisateur envoyé à l'IA par l'application | `services/groq.js` |
| R13 | Analyse du résultat | `agents/analyste.js` |
| R14 | Guidage de l'utilisateur | `AnalysisPanel.jsx` : manques, questions, instruction suggérée |
| R15 | Amélioration jusqu'à la génération finale | `finalizePlan` (toutes les sections validées) |
| R16 | Dynamique et souple | Ordre libre des sections, retour en arrière, réouverture d'une section validée, projet modifiable, re-planification |

## Cahier des charges décrit par l'encadreur : correspondance

| Ce qui a été demandé | Où c'est dans l'application |
|---|---|
| Saisir seulement 2 ou 3 informations | Formulaire à 3 champs (idée, secteur, clients visés) : `PlansPage.jsx` |
| L'IA les reçoit, prépare la planification et le détail du business plan, et transmet tout aux agents suivants | Agent de planification (`agents/planner.js`) ; résultat affiché tout de suite (« Planification préparée par l'IA », `PlanOverview.jsx`) ; le contexte du projet et des sections voisines est transmis à chaque agent (`agents/common.js`) |
| Pipeline de plusieurs agents IA qui s'enchaînent | `services/orchestrator.js` : méta-prompt → rédacteur → analyste (et cohérence finale, financier, suivi). La chaîne est visible pendant la génération |
| L'utilisateur écrit un prompt | Zone « Instruction » (`SectionEditor.jsx`), pré-remplie et modifiable |
| Méta-prompt caché en coulisses | `agents/metaPrompt.js` : conservé côté serveur, jamais envoyé au frontend |
| Peaufiner à volonté | Régénération illimitée, modification manuelle, historique et restauration des versions, questions de guidage |
| Un agent produit le business plan complet | Génération finale (`finalizePlan`) : assemblage, annexe financière calculée, contrôle de cohérence, export Word/PDF |
| Exécuter puis suivre selon le plan | Lancement de l'exécution à une date donnée : tâches datées, retards détectés, avancement réel comparé au prévu, bilan de l'IA (`agents/suivi.js`, `Tracking.jsx`) |
| Interface sécurisée avec l'API d'IA | La clé n'existe que dans `.env` du backend ; JWT, validation zod, limitation de débit, helmet, CORS |

**Décisions prises** :
- **Fournisseur d'IA : Groq** (validé). Le modèle se change avec `GROQ_MODEL`. Vérifier les noms de modèles disponibles avec `npm run check:groq`, car la liste de Groq évolue.
- **« Exécuter »** : l'utilisateur réalise les tâches, l'application planifie, suit, détecte les retards et conseille. Aucune tâche n'est exécutée automatiquement par une IA.

## Ajouts à faire valider
- Contrôle de cohérence entre sections, seuil de validation (70/100, `VALIDATION_THRESHOLD`), versioning des itérations, protection contre l'injection de prompt (`wrapData`), verrouillage de la rédaction pendant l'exécution.
- Moteur financier en code, export Word et PDF réels, export Markdown, interface bilingue français / malgache.
- Structure des 9 sections : proposition générale, modifiable dans `agents/planner.js` (`DEFAULT_SECTIONS`).
