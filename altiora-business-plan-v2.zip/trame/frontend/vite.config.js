import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Le proxy évite tout problème CORS en développement : le navigateur ne parle qu'au frontend,
// et seul le backend connaît la clé Groq (R5).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/api': 'http://localhost:4000' },
  },
  preview: { port: 4173, proxy: { '/api': 'http://localhost:4000' } },
});
