// Tableaux et alertes du modèle financier, construits ici à partir des chiffres calculés par le backend.
// Les libellés suivent la langue de l'interface ; les montants viennent du moteur (le code fait foi, pas l'IA).

export function buildTables({ t, fmtNum, fmtMoney }, results) {
  const cur = results.currency;
  const k = results.kpis;
  const ys = results.years;
  const month = (m) => (m === null || m === undefined ? t('fin.notReached') : t('fin.monthN', { n: m }));
  const row = (key, pick, digits = 0) => [t(`fin.t.${key}`), ...ys.map((y) => fmtNum(pick(y), digits))];

  return {
    annual: {
      head: [t('fin.t.item'), ...ys.map((y) => t('fin.yearN', { n: y.year }))],
      align: ['left', ...ys.map(() => 'right')],
      rows: [
        row('revenue', (y) => y.revenue),
        row('cogs', (y) => y.cogs),
        row('gross', (y) => y.gross_profit),
        row('acquisition', (y) => y.acquisition),
        row('fixed', (y) => y.fixed),
        row('operating', (y) => y.operating_result),
        row('tax', (y) => y.tax),
        row('net', (y) => y.net_result),
        row('newCustomers', (y) => y.new_customers),
        row('customersEnd', (y) => y.customers_end),
        row('mrrEnd', (y) => y.mrr_end),
        row('cashEnd', (y) => y.cash_end),
      ],
    },
    indicators: {
      head: [t('fin.t.indicator'), t('fin.t.value')],
      align: ['left', 'right'],
      rows: [
        [t('fin.i.revenueTotal'), fmtMoney(k.revenue_total, cur)],
        [t('fin.i.grossMargin'), `${fmtNum(k.gross_margin_pct, 1)} %`],
        [t('fin.i.arr'), fmtMoney(k.arr_end, cur)],
        [t('fin.i.customersEnd'), fmtNum(k.customers_end)],
        [t('fin.i.breakEven'), month(k.break_even_month)],
        [t('fin.i.payback'), month(k.payback_month)],
        [t('fin.i.minCash'), `${fmtMoney(k.min_cash, cur)} (${month(k.min_cash_month)})`],
        [t('fin.i.gap'), fmtMoney(k.funding_gap, cur)],
        [t('fin.i.ltv'), k.ltv === null ? t('fin.i.ltvNone') : fmtMoney(k.ltv, cur)],
        [t('fin.i.ltvCac'), k.ltv_cac === null ? 'n/a' : fmtNum(k.ltv_cac, 1)],
        [t('fin.i.cacPayback'), k.cac_payback_months === null ? 'n/a' : t('fin.monthsN', { n: fmtNum(k.cac_payback_months, 1) })],
      ],
    },
    monthly: {
      head: [t('fin.t.month'), t('fin.t.newCustomers'), t('fin.t.customers'), t('fin.t.revenue'), t('fin.t.charges'), t('fin.t.operating'), t('fin.t.cash')],
      align: ['left', 'right', 'right', 'right', 'right', 'right', 'right'],
      rows: results.months.map((m) => [
        String(m.month), fmtNum(m.new_customers, 1), fmtNum(m.customers), fmtNum(m.revenue),
        fmtNum(m.cogs + m.opex + m.tax), fmtNum(m.operating_result), fmtNum(m.cash_balance),
      ]),
    },
  };
}

/** Alertes de bon sens : le backend envoie un code et des valeurs, le texte est écrit dans la langue active. */
export function warningTexts({ t, fmtNum }, results) {
  if (!results.warning_items) return results.warnings; // ancien backend : textes déjà rédigés
  return results.warning_items.map(({ code, params: p }) => t(`fin.w.${code}`, {
    ...p,
    min_cash: fmtNum(p.min_cash ?? 0), gap: fmtNum(p.gap ?? 0), annual: fmtNum(p.annual ?? 0), churn: fmtNum(p.churn ?? 0, 1),
    ratio: fmtNum(p.ratio ?? 0, 1), months_payback: fmtNum(p.months_payback ?? 0, 1), receivables: fmtNum(p.receivables ?? 0), growth: fmtNum(p.growth ?? 0, 1),
  }));
}
