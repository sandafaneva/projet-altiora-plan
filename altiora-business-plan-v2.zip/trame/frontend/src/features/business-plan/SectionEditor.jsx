import { useEffect, useState } from 'react';
import { Bot, ChevronRight, CircleCheck, Eye, History, ListChecks, Lock, Pencil, RotateCcw, Save, Sparkles, Undo2, Wand2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { api } from '../../shared/api.js';
import { useI18n } from '../../shared/i18n.jsx';
import Tip from '../../shared/Tip.jsx';
import { useConfirm, useToast } from '../../shared/feedback.jsx';
import { Alert, Button, Chip, Segmented } from '../../shared/ui.jsx';
import AnalysisPanel from './AnalysisPanel.jsx';
import VersionHistory from './VersionHistory.jsx';
import { sectionTitle, withoutTitle } from './status.js';

const isSave = (e) => (e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's';
const isRun = (e) => (e.ctrlKey || e.metaKey) && e.key === 'Enter';

// Boucle dynamique d'une section (R6, R8, R13, R14, R15, R16) :
// instruction, IA (méta-prompt caché, R7), résultat, analyse et guidage, peaufinage, validation.
export default function SectionEditor({ plan, section, threshold, onChanged, financials, onGoToFinances, onDirty }) {
  const { t } = useI18n();
  const confirm = useConfirm();
  const toast = useToast();
  const base = `/business-plans/${plan.id}/sections/${section.section_key}`;
  const locked = plan.status === 'executing';

  const [prompt, setPrompt] = useState(section.suggested_prompt || '');
  const [answers, setAnswers] = useState({});
  const [draft, setDraft] = useState(section.content || '');
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [showVersions, setShowVersions] = useState(false);
  const [view, setView] = useState('preview');

  useEffect(() => setDraft(section.content || ''), [section.content]);

  const dirty = draft !== (section.content || '');
  useEffect(() => { onDirty?.(dirty); return () => onDirty?.(false); }, [dirty, onDirty]);
  const usesFinancials = ['plan_financier', 'resume_executif'].includes(section.section_key);
  const staleFinancials = financials.stale_sections.some((s) => s.key === section.section_key);
  const validated = section.status === 'validated';
  const working = Boolean(busy);
  const title = sectionTitle(t, section);

  async function run(kind, fn) {
    setBusy(kind);
    setError('');
    try {
      const message = await fn();
      await onChanged();
      if (message) toast.success(message);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy('');
    }
  }

  const generate = () =>
    run('generate', async () => {
      const list = Object.entries(answers).filter(([, a]) => a.trim()).map(([question, answer]) => ({ question, answer }));
      const r = await api.post(`${base}/generate`, { prompt, answers: list });
      setAnswers({});
      setView('preview');
      return t('editor.generated', { score: r.section.score });
    });

  const saveDraft = () => run('save', async () => {
    const r = await api.put(`${base}/content`, { content: draft });
    return t('editor.saved', { score: r.section.score });
  });

  const validate = () =>
    run('validate', async () => {
      try {
        await api.post(`${base}/validate`, { force: false });
      } catch (err) {
        if (err.status === 409 && err.details?.score !== undefined) {
          const ok = await confirm({
            title: t('editor.belowTitle'),
            message: t('editor.belowText', { score: err.details.score, threshold: err.details.threshold }),
            confirmLabel: t('editor.validateAnyway'),
          });
          if (!ok) return undefined;
          await api.post(`${base}/validate`, { force: true });
        } else {
          throw err;
        }
      }
      return t('editor.validatedToast');
    });

  const reopen = () => run('reopen', async () => { await api.post(`${base}/unvalidate`); return t('editor.reopened'); });

  return (
    <>
      <section className="workbench">
        <header className="wb-head">
          <div className="wb-title">
            <h2>{title}</h2>
            {validated && <Chip tone="good" icon={CircleCheck}>{t('section.validated')}</Chip>}
          </div>
          {section.objective && <p>{section.objective}</p>}
          {section.key_points?.length > 0 && (
            <details className="points">
              <summary><ListChecks size={15} aria-hidden="true" />{t('editor.points')}</summary>
              <ul>{section.key_points.map((p, i) => <li key={i}>{p}</li>)}</ul>
            </details>
          )}
        </header>

        {usesFinancials && !financials.defined && !locked && (
          <Alert tone="warning" action={<Button size="sm" variant="secondary" onClick={onGoToFinances}>{t('editor.openFinances')}</Button>}>{t('editor.noFinance')}</Alert>
        )}
        {staleFinancials && !locked && <Alert tone="warning">{t('editor.staleFinance')}</Alert>}
        {locked && <Alert tone="info" title={t('editor.lockedTitle')}>{t('editor.locked')}</Alert>}

        <div className="panel">
          <div className="panel-title">
            <Wand2 size={18} aria-hidden="true" />
            <label htmlFor="prompt">{t('editor.instruction')}</label>
            <Tip text={t('editor.instructionTip')} />
          </div>
          <textarea id="prompt" rows={4} value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={4000} disabled={working || locked}
            placeholder={t('editor.instructionPh')} onKeyDown={(e) => { if (isRun(e) && !working && !locked && !dirty) { e.preventDefault(); generate(); } }} />
          <div className="actions">
            <Button icon={section.content ? RotateCcw : Sparkles} onClick={generate} busy={busy === 'generate'} busyLabel={t('editor.generating')}
              disabled={working || locked || dirty} title={dirty ? t('editor.saveFirst') : 'Ctrl + Enter'}>
              {section.content ? t('editor.regenerate') : t('editor.generate')}
            </Button>
            {dirty && <span className="hint">{t('editor.saveFirst')}</span>}
          </div>
          {busy === 'generate' && (
            <div className="agents" role="status">
              <span className="agents-label">{t('editor.agents')}</span>
              {['meta', 'writer', 'analyst'].map((k, i) => (
                <span key={k} className="agents-step">
                  {i > 0 && <ChevronRight size={14} aria-hidden="true" />}
                  <span className="agent"><Bot size={13} aria-hidden="true" />{t(`agent.${k}`)}</span>
                </span>
              ))}
              <div className="progressline" aria-hidden="true"><span /></div>
            </div>
          )}
        </div>

        {error && <Alert tone="error" onClose={() => setError('')}>{error}</Alert>}

        {section.content && (
          <div className="panel">
            <div className="panel-title wrap">
              <Segmented label={t('editor.viewMode')} value={view} onChange={setView} options={[
                { value: 'preview', label: t('editor.preview'), icon: Eye },
                { value: 'edit', label: t('editor.edit'), icon: Pencil },
              ]} />
              <Button variant="ghost" size="sm" icon={History} className="push" aria-expanded={showVersions} onClick={() => setShowVersions((v) => !v)}>{t('editor.history')}</Button>
            </div>

            {view === 'preview'
              ? <article className="prose result"><ReactMarkdown remarkPlugins={[remarkGfm]}>{withoutTitle(t, section, draft)}</ReactMarkdown></article>
              : <textarea id="draft" className="draft" rows={18} value={draft} onChange={(e) => setDraft(e.target.value)} disabled={working || locked}
                aria-label={t('editor.result')} onKeyDown={(e) => { if (isSave(e) && dirty && !working) { e.preventDefault(); saveDraft(); } }} />}

            <div className="actions">
              {dirty && <Button icon={Save} onClick={saveDraft} busy={busy === 'save'} busyLabel={t('editor.analysing')} disabled={working} title="Ctrl + S">{t('editor.saveAnalyse')}</Button>}
              {dirty && <Button variant="secondary" icon={Undo2} onClick={() => setDraft(section.content)} disabled={working}>{t('editor.discard')}</Button>}
              {!dirty && !validated && <Button variant="success" icon={CircleCheck} onClick={validate} busy={busy === 'validate'} busyLabel={t('editor.validating')} disabled={working || locked}>{t('editor.validate')}</Button>}
              {!dirty && validated && !locked && <Button variant="secondary" icon={Lock} onClick={reopen} busy={busy === 'reopen'} disabled={working}>{t('editor.reopen')}</Button>}
            </div>
            {showVersions && <VersionHistory planId={plan.id} sectionKey={section.section_key} currentContent={section.content} locked={locked || working} onRestored={onChanged} />}
          </div>
        )}
      </section>

      <AnalysisPanel section={section} threshold={threshold} answers={answers} setAnswers={setAnswers}
        onUseSuggestion={setPrompt} disabled={working || locked} />
    </>
  );
}
