import { useI18n } from '../../shared/i18n.jsx';
import ScoreMeter from './ScoreMeter.jsx';
import { SECTION_STATE, sectionTitle } from './status.js';

// La colonne des sections est un parcours : chaque étape validée fait monter l'anneau.
export default function SectionRail({ sections, activeKey, onSelect, threshold }) {
  const { t } = useI18n();
  return (
    <nav className="rail" aria-label={t('rail.label')}>
      <ol>
        {sections.map((s, i) => (
          <li key={s.section_key} className={s.section_key === activeKey ? 'active' : ''}>
            <button type="button" onClick={() => onSelect(s.section_key)} aria-current={s.section_key === activeKey ? 'step' : undefined}>
              <ScoreMeter score={s.score} validated={s.status === 'validated'} threshold={threshold} />
              <span className="rail-text">
                <span className="rail-title"><b>{i + 1}.</b> {sectionTitle(t, s)}</span>
                <span className={`rail-state ${s.status}`}>{t(SECTION_STATE[s.status].key)}</span>
              </span>
            </button>
          </li>
        ))}
      </ol>
    </nav>
  );
}
