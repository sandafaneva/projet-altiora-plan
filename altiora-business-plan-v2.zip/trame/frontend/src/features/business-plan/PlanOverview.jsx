import { ArrowRight, ListChecks, Sparkles } from 'lucide-react';
import { useI18n } from '../../shared/i18n.jsx';
import { sectionTitle } from './status.js';

/** Résultat de l'agent de planification : ce que l'IA a préparé à partir des trois champs, avant toute rédaction. */
export default function PlanOverview({ sections, onSelect }) {
  const { t } = useI18n();
  return (
    <section className="plan-ov" aria-labelledby="plan-ov-title">
      <header>
        <span className="plan-ov-icon"><Sparkles size={20} aria-hidden="true" /></span>
        <div>
          <h2 id="plan-ov-title">{t('plan.overviewTitle')}</h2>
          <p>{t('plan.overviewText')}</p>
        </div>
      </header>
      <ol>
        {sections.map((s, i) => (
          <li key={s.section_key}>
            <button type="button" onClick={() => onSelect(s.section_key)}>
              <b>{i + 1}</b>
              <span className="plan-ov-body">
                <strong>{sectionTitle(t, s)}</strong>
                {s.objective && <span className="clamp-2">{s.objective}</span>}
                {s.key_points?.length > 0 && <small><ListChecks size={13} aria-hidden="true" />{t('plan.overviewPoints', { count: s.key_points.length })}</small>}
              </span>
              <ArrowRight size={16} aria-hidden="true" />
            </button>
          </li>
        ))}
      </ol>
    </section>
  );
}
