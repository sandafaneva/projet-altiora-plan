import { useEffect, useId, useMemo, useState } from 'react';
import { Calculator, Coins, Flag, Landmark, Plus, Receipt, Repeat, Save, Scale, Settings2, Sparkles, Table2, TrendingUp, TriangleAlert, Trash2, Wallet } from 'lucide-react';
import { api } from '../../shared/api.js';
import { useI18n } from '../../shared/i18n.jsx';
import Tip from '../../shared/Tip.jsx';
import { useConfirm, useToast } from '../../shared/feedback.jsx';
import { Alert, Button, EmptyState, Kpi } from '../../shared/ui.jsx';
import LineChart from './LineChart.jsx';
import { buildTables, warningTexts } from './financeTables.js';
import { sectionTitle } from './status.js';

const EMPTY = {
  currency: 'Ar', horizon_months: '36',
  price_per_customer_month: '', setup_fee: '0', initial_customers: '0', new_customers_per_month: '', new_customers_growth_pct: '0',
  monthly_churn_pct: '0', annual_price_increase_pct: '0',
  cac: '0', cogs_pct: '0', annual_cost_increase_pct: '0', fixed_costs: [],
  initial_investment: '0', initial_funding: '0', funding_rounds: [], payment_delay_days: '30', tax_rate_pct: '0',
};

const NUMERIC = ['horizon_months', 'price_per_customer_month', 'setup_fee', 'initial_customers', 'new_customers_per_month', 'new_customers_growth_pct',
  'monthly_churn_pct', 'annual_price_increase_pct', 'cac', 'cogs_pct', 'annual_cost_increase_pct', 'initial_investment', 'initial_funding',
  'payment_delay_days', 'tax_rate_pct'];

const fromAssumptions = (a) => ({
  ...EMPTY,
  ...Object.fromEntries(Object.entries(a).filter(([k]) => k !== 'fixed_costs' && k !== 'funding_rounds').map(([k, v]) => [k, String(v)])),
  fixed_costs: (a.fixed_costs || []).map((c) => ({ label: c.label, monthly_amount: String(c.monthly_amount), start_month: String(c.start_month) })),
  funding_rounds: (a.funding_rounds || []).map((f) => ({ label: f.label, month: String(f.month), amount: String(f.amount) })),
});

const num = (v) => (v === '' || v === null || v === undefined ? undefined : Number(v));
function toPayload(f) {
  const out = { currency: f.currency.trim() || 'Ar' };
  for (const k of NUMERIC) if (num(f[k]) !== undefined) out[k] = num(f[k]);
  out.fixed_costs = f.fixed_costs.map((c) => ({ label: c.label, monthly_amount: num(c.monthly_amount) ?? 0, start_month: num(c.start_month) ?? 1 }));
  out.funding_rounds = f.funding_rounds.map((r) => ({ label: r.label, month: num(r.month) ?? 1, amount: num(r.amount) ?? 0 }));
  return out;
}

function NumField({ label, hint, value, onChange, suffix, disabled, required, error, step = 'any', min = 0 }) {
  const id = useId();
  return (
    <div className={`field ${error ? 'invalid' : ''}`}>
      <div className="field-label"><label htmlFor={id}>{label}{required && <span className="req" aria-hidden="true"> *</span>}</label>{hint && <Tip text={hint} />}</div>
      <div className="control unit">
        <input id={id} type="number" inputMode="decimal" step={step} min={min} value={value} onChange={(e) => onChange(e.target.value)} disabled={disabled} required={required} aria-invalid={error ? true : undefined} />
        {suffix && <em>{suffix}</em>}
      </div>
    </div>
  );
}

function Fieldset({ icon: Icon, title, disabled, children }) {
  return (
    <fieldset className="fset" disabled={disabled}>
      <legend><span className="fset-icon"><Icon size={17} aria-hidden="true" /></span>{title}</legend>
      {children}
    </fieldset>
  );
}

function Table({ t, className = '', caption }) {
  return (
    <div className={`tablewrap ${className}`} tabIndex={0} role="region" aria-label={caption}>
      <table className="fintable">
        <thead><tr>{t.head.map((h, i) => <th key={i} scope="col" className={t.align[i]}>{h}</th>)}</tr></thead>
        <tbody>{t.rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j} className={t.align[j]}>{c}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

export default function Financials({ plan, staleSections, onChanged, onGoToSection, onDirty }) {
  const i18n = useI18n();
  const { t, fmtNum, fmtMoney } = i18n;
  const confirm = useConfirm();
  const toast = useToast();
  const locked = plan.status === 'executing';
  const [loaded, setLoaded] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [preview, setPreview] = useState(null);
  const [previewError, setPreviewError] = useState('');
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [aiInfo, setAiInfo] = useState(null);
  const [showMonthly, setShowMonthly] = useState(false);
  const [saved, setSaved] = useState(''); // empreinte des hypothèses enregistrées

  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const payload = useMemo(() => toPayload(form), [form]);
  const dirty = loaded && JSON.stringify(payload) !== saved;
  useEffect(() => { onDirty?.(dirty); return () => onDirty?.(false); }, [dirty, onDirty]);

  // Chargement des hypothèses enregistrées et de leurs résultats
  useEffect(() => {
    let off = false;
    api.get(`/business-plans/${plan.id}/financials`)
      .then((d) => {
        if (off) return;
        if (d.assumptions) {
          const f = fromAssumptions(d.assumptions);
          setForm(f);
          setSaved(JSON.stringify(toPayload(f)));
          setPreview({ results: d.results });
        } else {
          setSaved(JSON.stringify(toPayload(EMPTY)));
        }
        setLoaded(true);
      })
      .catch((e) => { if (!off) { setError(e.message); setLoaded(true); } });
    return () => { off = true; };
  }, [plan.id]);

  // Aperçu en direct : le serveur recalcule après une courte pause dans la saisie
  useEffect(() => {
    if (!loaded) return undefined;
    if (!payload.price_per_customer_month) { setPreview(null); setPreviewError(''); return undefined; }
    let cancelled = false;
    const timer = setTimeout(async () => {
      try {
        const d = await api.post(`/business-plans/${plan.id}/financials/preview`, payload);
        if (!cancelled) { setPreview(d); setPreviewError(''); }
      } catch (e) {
        if (!cancelled) setPreviewError(e.message);
      }
    }, 450);
    return () => { cancelled = true; clearTimeout(timer); };
  }, [payload, plan.id, loaded]);

  async function save(e) {
    e?.preventDefault();
    if (locked || busy || !payload.price_per_customer_month) return;
    if (plan.status === 'generated') {
      const ok = await confirm({ title: t('fin.invalidateTitle'), message: t('fin.invalidateText'), confirmLabel: t('common.save') });
      if (!ok) return;
    }
    setBusy('save'); setError('');
    try {
      await api.put(`/business-plans/${plan.id}/financials`, payload);
      setSaved(JSON.stringify(payload));
      await onChanged();
      toast.success(t('fin.saved'));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy('');
    }
  }

  async function suggest() {
    setBusy('suggest'); setError('');
    try {
      const d = await api.post(`/business-plans/${plan.id}/financials/suggest`);
      const s = d.suggestions;
      setForm((f) => {
        const next = { ...f };
        for (const [k, v] of Object.entries(s)) {
          if (k === 'fixed_costs') next.fixed_costs = v.map((c) => ({ label: c.label, monthly_amount: String(c.monthly_amount), start_month: String(c.start_month ?? 1) }));
          else next[k] = String(v);
        }
        return next;
      });
      setAiInfo({ found: d.found, missing: d.missing, count: Object.keys(s).length });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy('');
    }
  }

  const updateRow = (list, i, key, value) => setForm((f) => ({ ...f, [list]: f[list].map((r, j) => (j === i ? { ...r, [key]: value } : r)) }));
  const addRow = (list, row) => setForm((f) => ({ ...f, [list]: [...f[list], row] }));
  const removeRow = (list, i) => setForm((f) => ({ ...f, [list]: f[list].filter((_, j) => j !== i) }));

  const cur = form.currency || 'Ar';
  const res = preview?.results;
  const warns = res ? warningTexts(i18n, res) : [];
  const k = res?.kpis;
  const tables = useMemo(() => (res ? buildTables(i18n, res) : null), [res, i18n]);

  if (!loaded) return <p className="hint">{error || t('common.loading')}</p>;

  return (
    <div className="fin">
      {staleSections.length > 0 && (
        <Alert tone="warning" title={t('fin.staleTitle')}
          action={<span className="btn-row">{staleSections.map((s) => <Button key={s.key} size="sm" variant="secondary" onClick={() => onGoToSection(s.key)}>{t('fin.open', { title: sectionTitle(t, { section_key: s.key, title: s.title }) })}</Button>)}</span>}>
          {t('fin.staleText')}
        </Alert>
      )}
      {locked && <Alert tone="info">{t('fin.locked')}</Alert>}

      <form className="fin-layout" onSubmit={save} onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); } }} noValidate>
        <div className="fin-form">
          {!locked && (
            <div className="panel prefill">
              <span className="prefill-icon"><Sparkles size={20} aria-hidden="true" /></span>
              <div>
                <h2>{t('fin.prefill')}</h2>
                <p className="muted">{t('fin.prefillHint')}</p>
              </div>
              <Button variant="secondary" size="sm" icon={Sparkles} onClick={suggest} busy={busy === 'suggest'} busyLabel={t('fin.reading')} disabled={Boolean(busy)}>{t('fin.prefillAction')}</Button>
              {aiInfo && (
                <div className="aiinfo">
                  <p><strong>{t('fin.prefilled', { count: aiInfo.count })}</strong> {t('fin.checkBeforeSave')}</p>
                  {aiInfo.found.length > 0 && <ul>{aiInfo.found.map((x, i) => <li key={i}>{x}</li>)}</ul>}
                  {aiInfo.missing.length > 0 && (<><p><strong>{t('fin.toFill')}</strong></p><ul>{aiInfo.missing.map((x, i) => <li key={i}>{x}</li>)}</ul></>)}
                </div>
              )}
            </div>
          )}

          <Fieldset icon={Settings2} title={t('fin.general')} disabled={locked}>
            <div className="fgrid">
              <div className="field">
                <div className="field-label"><label htmlFor="cur">{t('fin.currency')}</label></div>
                <div className="control"><input id="cur" value={form.currency} onChange={(e) => set('currency')(e.target.value)} maxLength={8} /></div>
              </div>
              <div className="field">
                <div className="field-label"><label htmlFor="hor">{t('fin.horizon')}</label></div>
                <div className="control">
                  <select id="hor" value={form.horizon_months} onChange={(e) => set('horizon_months')(e.target.value)}>
                    {[12, 24, 36, 48, 60].map((m) => <option key={m} value={m}>{t('fin.monthsN', { n: m })}</option>)}
                  </select>
                </div>
              </div>
            </div>
          </Fieldset>

          <Fieldset icon={TrendingUp} title={t('fin.revenue')} disabled={locked}>
            <div className="fgrid">
              <NumField label={t('fin.price')} required suffix={cur} value={form.price_per_customer_month} onChange={set('price_per_customer_month')} hint={t('fin.priceTip')} />
              <NumField label={t('fin.setup')} suffix={cur} value={form.setup_fee} onChange={set('setup_fee')} hint={t('fin.setupTip')} />
              <NumField label={t('fin.initialCustomers')} value={form.initial_customers} onChange={set('initial_customers')} />
              <NumField label={t('fin.newCustomers')} value={form.new_customers_per_month} onChange={set('new_customers_per_month')} />
              <NumField label={t('fin.growth')} suffix={t('fin.perMonthPct')} min={-50} value={form.new_customers_growth_pct} onChange={set('new_customers_growth_pct')} hint={t('fin.growthTip')} />
              <NumField label={t('fin.churn')} suffix={t('fin.perMonthPct')} value={form.monthly_churn_pct} onChange={set('monthly_churn_pct')} hint={t('fin.churnTip')} />
              <NumField label={t('fin.priceUp')} suffix="%" min={-50} value={form.annual_price_increase_pct} onChange={set('annual_price_increase_pct')} />
            </div>
          </Fieldset>

          <Fieldset icon={Receipt} title={t('fin.costs')} disabled={locked}>
            <div className="fgrid">
              <NumField label={t('fin.cac')} suffix={cur} value={form.cac} onChange={set('cac')} hint={t('fin.cacTip')} />
              <NumField label={t('fin.cogs')} suffix={t('fin.ofRevenue')} value={form.cogs_pct} onChange={set('cogs_pct')} hint={t('fin.cogsTip')} />
              <NumField label={t('fin.costUp')} suffix="%" min={-50} value={form.annual_cost_increase_pct} onChange={set('annual_cost_increase_pct')} />
            </div>
            <h3>{t('fin.fixed')}</h3>
            {form.fixed_costs.length > 0 && (
              <div className="rowedit head" aria-hidden="true"><span>{t('fin.rowLabel')}</span><span>{t('fin.rowAmount', { currency: cur })}</span><span>{t('fin.rowFrom')}</span><span /></div>
            )}
            {form.fixed_costs.map((c, i) => (
              <div className="rowedit" key={i}>
                <input aria-label={t('fin.rowLabel')} placeholder={t('fin.fixedPh')} value={c.label} onChange={(e) => updateRow('fixed_costs', i, 'label', e.target.value)} maxLength={80} />
                <input aria-label={t('fin.rowAmount', { currency: cur })} type="number" step="any" min="0" value={c.monthly_amount} onChange={(e) => updateRow('fixed_costs', i, 'monthly_amount', e.target.value)} />
                <input aria-label={t('fin.rowFrom')} type="number" min="1" max="60" step="1" value={c.start_month} onChange={(e) => updateRow('fixed_costs', i, 'start_month', e.target.value)} />
                <Button variant="ghost" size="sm" iconOnly icon={Trash2} className="danger-hover" onClick={() => removeRow('fixed_costs', i)} aria-label={t('common.remove')} title={t('common.remove')} />
              </div>
            ))}
            <Button variant="secondary" size="sm" icon={Plus} onClick={() => addRow('fixed_costs', { label: '', monthly_amount: '', start_month: '1' })}>{t('fin.addFixed')}</Button>
          </Fieldset>

          <Fieldset icon={Landmark} title={t('fin.cash')} disabled={locked}>
            <div className="fgrid">
              <NumField label={t('fin.investment')} suffix={cur} value={form.initial_investment} onChange={set('initial_investment')} hint={t('fin.investmentTip')} />
              <NumField label={t('fin.funding')} suffix={cur} value={form.initial_funding} onChange={set('initial_funding')} hint={t('fin.fundingTip')} />
              <NumField label={t('fin.delay')} suffix={t('fin.days')} step="1" value={form.payment_delay_days} onChange={set('payment_delay_days')} hint={t('fin.delayTip')} />
              <NumField label={t('fin.tax')} suffix="%" value={form.tax_rate_pct} onChange={set('tax_rate_pct')} hint={t('fin.taxTip')} />
            </div>
            <h3>{t('fin.rounds')}</h3>
            {form.funding_rounds.length > 0 && (
              <div className="rowedit head" aria-hidden="true"><span>{t('fin.rowLabel')}</span><span>{t('fin.roundAmount', { currency: cur })}</span><span>{t('fin.roundMonth')}</span><span /></div>
            )}
            {form.funding_rounds.map((r, i) => (
              <div className="rowedit" key={i}>
                <input aria-label={t('fin.rowLabel')} placeholder={t('fin.roundPh')} value={r.label} onChange={(e) => updateRow('funding_rounds', i, 'label', e.target.value)} maxLength={80} />
                <input aria-label={t('fin.roundAmount', { currency: cur })} type="number" step="any" min="0" value={r.amount} onChange={(e) => updateRow('funding_rounds', i, 'amount', e.target.value)} />
                <input aria-label={t('fin.roundMonth')} type="number" min="1" max="60" step="1" value={r.month} onChange={(e) => updateRow('funding_rounds', i, 'month', e.target.value)} />
                <Button variant="ghost" size="sm" iconOnly icon={Trash2} className="danger-hover" onClick={() => removeRow('funding_rounds', i)} aria-label={t('common.remove')} title={t('common.remove')} />
              </div>
            ))}
            <Button variant="secondary" size="sm" icon={Plus} onClick={() => addRow('funding_rounds', { label: '', amount: '', month: '6' })}>{t('fin.addRound')}</Button>
          </Fieldset>

          {error && <Alert tone="error" onClose={() => setError('')}>{error}</Alert>}
          {!locked && (
            <div className="savebar">
              <Button type="submit" icon={Save} busy={busy === 'save'} busyLabel={t('common.saving')} disabled={Boolean(busy) || !payload.price_per_customer_month}
                title={!payload.price_per_customer_month ? t('fin.priceRequired') : 'Ctrl + S'}>{t('fin.save')}</Button>
              {dirty && <span className="unsaved"><TriangleAlert size={15} aria-hidden="true" />{t('common.unsaved')}</span>}
              {!payload.price_per_customer_month && <span className="hint">{t('fin.priceRequired')}</span>}
            </div>
          )}
        </div>

        <aside className="fin-results" aria-live="polite" aria-label={t('fin.results')}>
          {!res && !previewError && <EmptyState compact icon={Calculator} title={t('fin.results')} text={t('fin.resultsEmpty')} />}
          {previewError && <Alert tone="error">{previewError}</Alert>}
          {res && (
            <>
              <div className="kpis">
                <Kpi icon={Flag} label={t('fin.k.breakEven')} tone={k.break_even_month ? 'good' : 'low'} value={k.break_even_month ? t('fin.monthN', { n: k.break_even_month }) : t('fin.notReached')} sub={t('fin.k.breakEvenSub')} />
                <Kpi icon={Wallet} label={t('fin.k.minCash')} tone={k.min_cash < 0 ? 'low' : 'good'} value={fmtMoney(k.min_cash, cur)} sub={t('fin.k.atMonth', { n: k.min_cash_month })} />
                <Kpi icon={Landmark} label={t('fin.k.gap')} tone={k.funding_gap > 0 ? 'low' : 'good'} value={fmtMoney(k.funding_gap, cur)} sub={t('fin.k.gapSub')} />
                <Kpi icon={Scale} label="LTV / CAC" tone={k.ltv_cac === null ? '' : k.ltv_cac >= 3 ? 'good' : 'mid'} value={k.ltv_cac === null ? 'n/a' : fmtNum(k.ltv_cac, 1)} sub={t('fin.k.ltvGoal')} />
                <Kpi icon={Coins} label={t('fin.k.revenueY1')} value={fmtMoney(res.years[0].revenue, cur)} />
                <Kpi icon={Repeat} label={t('fin.k.mrr')} value={fmtMoney(k.mrr_end, cur)} sub={t('fin.k.perMonth')} />
              </div>

              {warns.length > 0 && (
                <Alert tone="warning" title={t('fin.warnings')}>
                  <ul className="alert-list">{warns.map((w, i) => <li key={i}>{w}</li>)}</ul>
                </Alert>
              )}

              <LineChart title={t('fin.chart.revenue')} currency={cur} series={[
                { name: t('fin.chart.revenueLegend'), tone: 'brand', values: res.months.map((m) => m.revenue) },
                { name: t('fin.chart.charges'), tone: 'bad', values: res.months.map((m) => m.cogs + m.opex + m.tax) },
              ]} />
              <LineChart title={t('fin.chart.cash')} currency={cur} series={[
                { name: t('fin.chart.cashLegend'), tone: 'ink', values: res.months.map((m) => m.cash_balance) },
              ]} />

              <h3>{t('fin.byYear')}</h3>
              <Table t={tables.annual} caption={t('fin.byYear')} />
              <h3>{t('fin.indicators')}</h3>
              <Table t={tables.indicators} caption={t('fin.indicators')} />
              <Button variant="ghost" size="sm" icon={Table2} aria-expanded={showMonthly} onClick={() => setShowMonthly((v) => !v)}>{showMonthly ? t('fin.hideMonthly') : t('fin.showMonthly')}</Button>
              {showMonthly && <Table t={tables.monthly} className="tall" caption={t('fin.monthly')} />}
            </>
          )}
        </aside>
      </form>
    </div>
  );
}
