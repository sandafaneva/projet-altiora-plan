import { useCallback, useEffect, useMemo, useState } from 'react';
import { AlarmClock, Ban, CalendarClock, ChevronDown, Circle, CircleAlert, CircleCheck, Gauge, ListChecks, LoaderCircle, Pencil, Plus, Sparkles, Trash2, TriangleAlert } from 'lucide-react';
import { api } from '../../shared/api.js';
import { useI18n } from '../../shared/i18n.jsx';
import { useConfirm, useToast } from '../../shared/feedback.jsx';
import { Alert, Button, Chip, EmptyState, Field, Kpi, Segmented } from '../../shared/ui.jsx';
import Modal from '../../shared/Modal.jsx';
import { SkeletonPage } from '../../shared/Skeleton.jsx';

const STATUS_ICON = { todo: Circle, in_progress: LoaderCircle, done: CircleCheck, blocked: Ban };
const HEALTH = { on_track: { key: 'track.onTrack', tone: 'good', icon: CircleCheck }, at_risk: { key: 'track.atRisk', tone: 'mid', icon: TriangleAlert }, late: { key: 'track.late', tone: 'low', icon: CircleAlert } };

function DueBadge({ task }) {
  const { t } = useI18n();
  if (task.status === 'done' || !task.due_date) return null;
  if (task.is_overdue) return <Chip tone="low" icon={AlarmClock}>{t('track.lateBy', { count: task.days_late })}</Chip>;
  if (task.days_left <= 7) return <Chip tone="mid" icon={CalendarClock}>{task.days_left === 0 ? t('track.dueToday') : t('track.dueIn', { count: task.days_left })}</Chip>;
  return null;
}

const emptyForm = (phase = '') => ({ phase, title: '', description: '', kpi: '', target_value: '', due_date: '' });
const toBody = (f) => ({
  phase: f.phase.trim(), title: f.title.trim(), description: f.description.trim() || null,
  kpi: f.kpi.trim() || null, target_value: f.target_value.trim() || null, due_date: f.due_date || null,
});

/** Formulaire d'une tâche (ajout ou modification), dans une fenêtre : la liste reste propre. */
function TaskDialog({ open, onClose, initial, phases, onSubmit, title }) {
  const { t } = useI18n();
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => { setForm({ ...form, [k]: e.target.value }); if (errors[k]) setErrors({ ...errors, [k]: undefined }); };

  async function submit(ev) {
    ev.preventDefault();
    const e = {};
    if (form.title.trim().length < 2) e.title = t('val.required');
    if (!form.phase.trim()) e.phase = t('val.required');
    setErrors(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    const ok = await onSubmit(toBody(form));
    setBusy(false);
    if (ok) onClose();
  }

  return (
    <Modal open={open} onClose={onClose} busy={busy} icon={Pencil} title={title}
      footer={(
        <>
          <Button variant="secondary" onClick={onClose} disabled={busy}>{t('common.cancel')}</Button>
          <Button type="submit" form="task-form" busy={busy} busyLabel={t('common.saving')}>{t('common.save')}</Button>
        </>
      )}>
      <form id="task-form" onSubmit={submit} noValidate>
        <Field label={t('task.title')} error={errors.title} required><input value={form.title} onChange={set('title')} maxLength={250} autoFocus /></Field>
        <div className="row2">
          <Field label={t('task.phase')} error={errors.phase} required><input list="phases" value={form.phase} onChange={set('phase')} maxLength={150} /></Field>
          <Field label={t('task.due')}><input type="date" value={form.due_date} onChange={set('due_date')} /></Field>
        </div>
        <Field label={t('task.description')}><textarea rows={2} value={form.description} onChange={set('description')} maxLength={1000} /></Field>
        <div className="row2">
          <Field label={t('task.kpi')}><input value={form.kpi} onChange={set('kpi')} maxLength={250} /></Field>
          <Field label={t('task.target')}><input value={form.target_value} onChange={set('target_value')} maxLength={150} /></Field>
        </div>
        <datalist id="phases">{phases.map((p) => <option key={p} value={p} />)}</datalist>
      </form>
    </Modal>
  );
}

function TaskRow({ task, onPatch, onEdit, onDelete }) {
  const { t, fmtDate } = useI18n();
  const confirm = useConfirm();
  const [progress, setProgress] = useState(task.progress);
  const [note, setNote] = useState(task.note || '');
  const [open, setOpen] = useState(false);
  useEffect(() => setProgress(task.progress), [task.progress]);

  const done = task.status === 'done';
  const StatusIcon = STATUS_ICON[task.status];
  const commit = () => progress !== task.progress && onPatch(task.id, { progress });

  return (
    <li className={`task ${task.status} ${task.is_overdue ? 'overdue' : ''}`}>
      <button type="button" className={`task-check ${task.status}`} onClick={() => onPatch(task.id, { status: done ? 'todo' : 'done' })}
        aria-label={done ? t('task.reopen', { title: task.title }) : t('task.complete', { title: task.title })} title={done ? t('task.reopenShort') : t('task.completeShort')}>
        <StatusIcon size={22} aria-hidden="true" />
      </button>

      <div className="task-body">
        <div className="task-line">
          <strong>{task.title}</strong>
          <DueBadge task={task} />
          {task.source === 'manual' && <Chip>{t('task.added')}</Chip>}
        </div>
        <p className="task-meta">
          {task.due_date ? t('task.dueOn', { date: fmtDate(task.due_date) }) : t('task.noDue')}
          {task.kpi && <> · <b>KPI</b> {task.kpi}{task.target_value && ` (${task.target_value})`}</>}
        </p>
        {open && (
          <div className="task-more">
            {task.description && <p>{task.description}</p>}
            <input className="note" value={note} onChange={(e) => setNote(e.target.value)} maxLength={1000} placeholder={t('task.notePh')}
              onBlur={() => note !== (task.note || '') && onPatch(task.id, { note: note || null })} aria-label={t('task.note', { title: task.title })} />
          </div>
        )}
      </div>

      <div className="task-controls">
        <select value={task.status} onChange={(e) => onPatch(task.id, { status: e.target.value })} aria-label={t('task.status', { title: task.title })}>
          {Object.keys(STATUS_ICON).map((k) => <option key={k} value={k}>{t(`task.s.${k}`)}</option>)}
        </select>
        <label className="range">
          <input type="range" min="0" max="100" step="5" value={progress} onChange={(e) => setProgress(Number(e.target.value))}
            onPointerUp={commit} onKeyUp={commit} aria-label={t('task.progress', { title: task.title })} />
          <span>{progress} %</span>
        </label>
        <span className="task-icons">
          <Button variant="ghost" size="sm" iconOnly icon={ChevronDown} className={open ? 'flip' : ''} aria-expanded={open} aria-label={t('task.details')} title={t('task.details')} onClick={() => setOpen((o) => !o)} />
          <Button variant="ghost" size="sm" iconOnly icon={Pencil} aria-label={t('common.edit')} title={t('common.edit')} onClick={() => onEdit(task)} />
          <Button variant="ghost" size="sm" iconOnly icon={Trash2} className="danger-hover" aria-label={t('common.delete')} title={t('common.delete')}
            onClick={async () => { if (await confirm({ title: t('task.deleteTitle'), message: t('task.deleteText', { title: task.title }), confirmLabel: t('common.delete'), tone: 'danger' })) onDelete(task.id); }} />
        </span>
      </div>
    </li>
  );
}

export default function Tracking({ plan }) {
  const { t, fmtDate, fmtDateTime } = useI18n();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState('all');
  const [dialog, setDialog] = useState(null); // { task } pour modifier, {} pour ajouter

  const load = useCallback(async () => {
    try { setData(await api.get(`/business-plans/${plan.id}/tracking`)); } catch (e) { setError(e.message); }
  }, [plan.id]);
  useEffect(() => { load(); }, [load]);

  // Chaque action renvoie true si elle a réussi
  const act = async (fn) => {
    setError('');
    try { await fn(); await load(); return true; } catch (e) { setError(e.message); return false; }
  };
  const patch = (id, body) => act(() => api.patch(`/business-plans/${plan.id}/tasks/${id}`, body));
  const remove = (id) => act(async () => { await api.del(`/business-plans/${plan.id}/tasks/${id}`); toast.success(t('task.deleted')); });
  const add = (body) => act(async () => { await api.post(`/business-plans/${plan.id}/tasks`, body); toast.success(t('task.addedToast')); });
  async function review() {
    setBusy(true);
    await act(async () => { await api.post(`/business-plans/${plan.id}/tracking/review`); toast.success(t('track.reviewDone')); });
    setBusy(false);
  }

  const tasks = data?.tasks ?? [];
  const shown = useMemo(() => tasks.filter((k) => filter === 'all' || (filter === 'late' ? k.is_overdue : filter === 'done' ? k.status === 'done' : k.status !== 'done')), [tasks, filter]);

  if (!data) return error ? <Alert tone="error">{error}</Alert> : <SkeletonPage />;

  const { stats, alerts, last_review: rev, start_date: start } = data;
  const phases = [...new Set(tasks.map((k) => k.phase))];
  const health = HEALTH[stats.schedule];
  const revHealth = rev ? HEALTH[rev.health] : null;

  return (
    <div className="tracking">
      <div className="kpis kpis-4">
        <Kpi icon={Gauge} tone={health.tone} label={t('track.real')} value={`${stats.progress} %`} sub={t('track.planned', { value: stats.planned_progress })} />
        <Kpi icon={CircleCheck} tone="good" label={t('track.done')} value={`${stats.done} / ${stats.total}`} sub={t('track.startedOn', { date: fmtDate(start) })} />
        <Kpi icon={AlarmClock} tone={stats.overdue ? 'low' : 'good'} label={t('track.overdue')} value={stats.overdue} sub={stats.overdue ? t('track.needsAction') : t('track.allGood')} />
        <Kpi icon={CalendarClock} tone={stats.due_soon ? 'mid' : ''} label={t('track.dueSoon')} value={stats.due_soon} sub={t('track.within7')} />
      </div>

      <div className="panel overview">
        <div className="overview-main">
          <div className="overview-head">
            <h2>{t('track.schedule')}</h2>
            <Chip tone={health.tone} icon={health.icon}>{t(health.key)}</Chip>
          </div>
          <div className="dual" role="img" aria-label={t('track.dualAria', { real: stats.progress, planned: stats.planned_progress })}>
            <span className="planned" style={{ width: `${stats.planned_progress}%` }} />
            <span className="real" style={{ width: `${stats.progress}%` }} />
          </div>
          <p className="legend"><span className="sw real" />{t('track.legendReal')}<span className="sw planned" />{t('track.legendPlanned')}</p>
        </div>
        <ul className="phase-stats">
          {stats.by_phase.map((p) => (
            <li key={p.phase}>
              <span>{p.phase}</span>
              <span className="bar sm" aria-hidden="true"><span style={{ width: `${p.progress}%` }} /></span>
              <strong>{p.progress} %</strong>
            </li>
          ))}
        </ul>
      </div>

      {error && <Alert tone="error" onClose={() => setError('')}>{error}</Alert>}

      {alerts.length > 0 && (
        <Alert tone="error" title={t('track.alertsTitle', { count: alerts.length })}>
          <ul className="alert-list">
            {alerts.map((k) => <li key={k.id}><strong>{k.title}</strong> · {t('track.lateBy', { count: k.days_late })} ({fmtDate(k.due_date)})</li>)}
          </ul>
        </Alert>
      )}

      <div className="panel">
        <div className="panel-title wrap">
          <Sparkles size={18} aria-hidden="true" />
          <h3>{t('track.review')}</h3>
          <Button variant="secondary" size="sm" icon={Sparkles} className="push" onClick={review} busy={busy} busyLabel={t('track.analysing')} disabled={tasks.length === 0}>
            {rev ? t('track.refresh') : t('track.ask')}
          </Button>
        </div>
        {!rev && <p className="muted">{t('track.reviewEmpty')}</p>}
        {rev && (
          <div className="review-body">
            <p><Chip tone={revHealth.tone} icon={revHealth.icon}>{t(revHealth.key)}</Chip> {rev.summary}</p>
            <div className="review-cols four">
              {rev.achievements?.length > 0 && <div className="callout good"><h3><CircleCheck size={16} aria-hidden="true" />{t('track.achievements')}</h3><ul>{rev.achievements.map((x, i) => <li key={i}>{x}</li>)}</ul></div>}
              {rev.risks?.length > 0 && <div className="callout bad"><h3><CircleAlert size={16} aria-hidden="true" />{t('track.risks')}</h3><ul>{rev.risks.map((x, i) => <li key={i}>{x}</li>)}</ul></div>}
              {rev.recommendations?.length > 0 && <div className="callout brand"><h3><Sparkles size={16} aria-hidden="true" />{t('track.recommendations')}</h3><ul>{rev.recommendations.map((x, i) => <li key={i}>{x}</li>)}</ul></div>}
              {rev.next_actions?.length > 0 && <div className="callout warn"><h3><TriangleAlert size={16} aria-hidden="true" />{t('track.nextActions')}</h3><ul>{rev.next_actions.map((x, i) => <li key={i}>{x}</li>)}</ul></div>}
            </div>
            <p className="hint">{t('track.reviewOn', { date: fmtDateTime(rev.created_at) })}</p>
          </div>
        )}
      </div>

      <div className="toolbar">
        <Segmented label={t('track.filter')} value={filter} onChange={setFilter} options={[
          { value: 'all', label: `${t('common.all')} (${tasks.length})` },
          { value: 'open', label: t('track.filterOpen'), icon: ListChecks },
          { value: 'late', label: `${t('track.filterLate')} (${stats.overdue})`, icon: AlarmClock },
          { value: 'done', label: t('track.filterDone'), icon: CircleCheck },
        ]} />
        <Button icon={Plus} className="push" onClick={() => setDialog({})}>{t('task.add')}</Button>
      </div>

      {shown.length === 0 && <EmptyState compact icon={ListChecks} title={t('track.noTasks')} />}
      {phases.map((phase) => {
        const list = shown.filter((k) => k.phase === phase);
        if (!list.length) return null;
        const info = stats.by_phase.find((p) => p.phase === phase);
        return (
          <section key={phase} className="panel phase">
            <header className="phase-head">
              <h3>{phase}</h3>
              {info && <span className="hint">{t('track.phaseCount', { done: info.done, total: info.total })}</span>}
            </header>
            <ul className="tasks">
              {list.map((k) => <TaskRow key={k.id} task={k} onPatch={patch} onDelete={remove} onEdit={(task) => setDialog({ task })} />)}
            </ul>
          </section>
        );
      })}

      {dialog && (
        <TaskDialog open onClose={() => setDialog(null)} phases={phases} title={dialog.task ? t('task.edit') : t('task.new')}
          initial={dialog.task
            ? { phase: dialog.task.phase, title: dialog.task.title, description: dialog.task.description || '', kpi: dialog.task.kpi || '', target_value: dialog.task.target_value || '', due_date: dialog.task.due_date || '' }
            : emptyForm(phases[phases.length - 1] || '')}
          onSubmit={(body) => (dialog.task ? patch(dialog.task.id, body) : add(body))} />
      )}
    </div>
  );
}
