import { useRef, useState } from 'react';
import { useI18n } from '../../shared/i18n.jsx';

// Graphique en courbes en SVG pur (aucune bibliothèque). Survol ou toucher : une ligne repère et une infobulle donnent les valeurs du mois.
const niceStep = (range, ticks) => {
  const raw = range / ticks || 1;
  const mag = 10 ** Math.floor(Math.log10(raw));
  const n = raw / mag;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * mag;
};

export default function LineChart({ title, series, currency }) {
  const { t, fmtCompact, fmtNum } = useI18n();
  const [hover, setHover] = useState(null);
  const svgRef = useRef(null);
  const W = 560, H = 250, L = 58, R = 14, T = 14, B = 30;
  const n = series[0].values.length;
  const all = series.flatMap((s) => s.values);
  let min = Math.min(0, ...all);
  let max = Math.max(0, ...all);
  if (max === min) max = min + 1;
  const step = niceStep(max - min, 4);
  min = Math.floor(min / step) * step;
  max = Math.ceil(max / step) * step;
  const x = (i) => L + (i / Math.max(1, n - 1)) * (W - L - R);
  const y = (v) => T + (H - T - B) - ((v - min) / (max - min)) * (H - T - B);
  const ticks = [];
  for (let v = min; v <= max + step / 2; v += step) ticks.push(v);
  const every = n > 36 ? 12 : 6;

  function onMove(e) {
    const r = svgRef.current.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * W;
    setHover(Math.max(0, Math.min(n - 1, Math.round(((px - L) / (W - L - R)) * (n - 1)))));
  }

  const line = (s) => s.values.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');

  return (
    <figure className="chart">
      <figcaption>
        <strong>{title}</strong>
        <span className="legend">
          {series.map((s) => (<span key={s.name}><span className="sw" style={{ background: `var(--chart-${s.tone})` }} />{s.name}</span>))}
        </span>
      </figcaption>
      <div className="chart-box" onPointerLeave={() => setHover(null)}>
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`${title}, ${currency}`} onPointerMove={onMove} onPointerDown={onMove}>
          <defs>
            {series.map((s) => (
              <linearGradient key={s.name} id={`g-${title.length}-${s.tone}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={`var(--chart-${s.tone})`} stopOpacity="0.22" />
                <stop offset="100%" stopColor={`var(--chart-${s.tone})`} stopOpacity="0" />
              </linearGradient>
            ))}
          </defs>
          {ticks.map((v) => (
            <g key={v}>
              <line x1={L} x2={W - R} y1={y(v)} y2={y(v)} className={v === 0 ? 'zero' : 'grid'} />
              <text x={L - 8} y={y(v) + 4.5} textAnchor="end" className="tick">{fmtCompact(v)}</text>
            </g>
          ))}
          {Array.from({ length: n }, (_, i) => i).filter((i) => i === 0 || (i + 1) % every === 0).map((i) => (
            <text key={i} x={x(i)} y={H - 9} textAnchor="middle" className="tick">{t('fin.m', { n: i + 1 })}</text>
          ))}
          {series.length === 1 && (
            <polygon points={`${x(0)},${y(0)} ${line(series[0])} ${x(n - 1)},${y(0)}`} fill={`url(#g-${title.length}-${series[0].tone})`} />
          )}
          {series.map((s) => (
            <polyline key={s.name} fill="none" style={{ stroke: `var(--chart-${s.tone})` }} strokeWidth="2.6" strokeLinejoin="round" strokeLinecap="round" points={line(s)}><title>{s.name}</title></polyline>
          ))}
          {hover !== null && (
            <g pointerEvents="none">
              <line x1={x(hover)} x2={x(hover)} y1={T} y2={H - B} className="cursor" />
              {series.map((s) => <circle key={s.name} cx={x(hover)} cy={y(s.values[hover])} r="4.5" className="dot" style={{ stroke: `var(--chart-${s.tone})` }} />)}
            </g>
          )}
        </svg>
        {hover !== null && (
          <div className="chart-tip" style={{ '--x': `${(x(hover) / W) * 100}%` }} role="status">
            <strong>{t('fin.m', { n: hover + 1 })}</strong>
            {series.map((s) => (
              <span key={s.name}><i className="sw" style={{ background: `var(--chart-${s.tone})` }} />{s.name} : <b>{fmtNum(Math.round(s.values[hover]))} {currency}</b></span>
            ))}
          </div>
        )}
      </div>
      <p className="hint">{t('fin.chartUnit', { currency })}</p>
    </figure>
  );
}
