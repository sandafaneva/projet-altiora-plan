import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CalendarDays, FolderKanban, FolderPlus, Lightbulb, Mountain, Plus, Rocket, Search, Sparkles, Trash2, PencilLine, Target, Users } from 'lucide-react';
import { api } from '../../shared/api.js';
import { useI18n } from '../../shared/i18n.jsx';
import { useConfirm, useToast } from '../../shared/feedback.jsx';
import { removePlanLocal, refreshPlans, usePlans } from '../../shared/plansStore.js';
import { Alert, Button, Chip, EmptyState, Field, Segmented } from '../../shared/ui.jsx';
import Modal from '../../shared/Modal.jsx';
import { SkeletonCards } from '../../shared/Skeleton.jsx';
import useDocumentTitle from '../../shared/useDocumentTitle.js';
import { PLAN_STATUS } from './status.js';

function NewPlanDialog({ open, onClose }) {
  const { t } = useI18n();
  const nav = useNavigate();
  const [form, setForm] = useState({ idea: '', sector: '', target_clients: '' });
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => { setForm({ ...form, [k]: e.target.value }); if (errors[k]) setErrors({ ...errors, [k]: undefined }); };

  function validate() {
    const e = {};
    if (form.idea.trim().length < 10) e.idea = t('val.ideaMin');
    if (form.sector.trim().length < 2) e.sector = t('val.required');
    if (form.target_clients.trim().length < 2) e.target_clients = t('val.required');
    return e;
  }

  // R3, R4 : trois champs seulement. Le reste est construit avec l'IA, section par section.
  async function create(ev) {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    setError('');
    if (Object.keys(e).length) return;
    setBusy(true);
    try {
      const d = await api.post('/business-plans', { idea: form.idea.trim(), sector: form.sector.trim(), target_clients: form.target_clients.trim() });
      refreshPlans();
      nav(`/plans/${d.plan.id}`);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} busy={busy} size="md" icon={FolderPlus} title={t('plans.newTitle')} description={t('plans.newSub')}
      footer={(
        <>
          <Button variant="secondary" onClick={onClose} disabled={busy}>{t('common.cancel')}</Button>
          <Button type="submit" form="new-plan" busy={busy} busyLabel={t('plans.preparing')} icon={Sparkles}>{t('plans.create')}</Button>
        </>
      )}>
      <form id="new-plan" onSubmit={create} noValidate>
        <Field label={t('plan.idea')} icon={Lightbulb} error={errors.idea} required>
          <textarea rows={4} value={form.idea} onChange={set('idea')} maxLength={2000} placeholder={t('plans.ideaPh')} autoFocus />
        </Field>
        <div className="row2">
          <Field label={t('plan.sector')} icon={Target} error={errors.sector} required>
            <input value={form.sector} onChange={set('sector')} maxLength={160} placeholder={t('plans.sectorPh')} />
          </Field>
          <Field label={t('plan.clients')} icon={Users} error={errors.target_clients} required>
            <input value={form.target_clients} onChange={set('target_clients')} maxLength={255} placeholder={t('plans.clientsPh')} />
          </Field>
        </div>
        {busy && <><div className="progressline" aria-hidden="true"><span /></div><p className="hint center-text">{t('plans.preparingHint')}</p></>}
        {error && <Alert tone="error">{error}</Alert>}
      </form>
    </Modal>
  );
}

function StatCard({ icon: Icon, label, value, tone }) {
  return (
    <div className={`stat ${tone}`}>
      <span className="stat-icon"><Icon size={18} aria-hidden="true" /></span>
      <div><strong>{value}</strong><span>{label}</span></div>
    </div>
  );
}

export default function PlansPage() {
  const { t, fmtDate } = useI18n();
  const confirm = useConfirm();
  const toast = useToast();
  useDocumentTitle(t('nav.projects'));
  const { plans, error } = usePlans();
  const [creating, setCreating] = useState(false);
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => { refreshPlans(); }, []);

  const visible = useMemo(() => (plans || []).filter((p) => (filter === 'all' || p.status === filter)
    && (!q.trim() || `${p.title} ${p.sector}`.toLowerCase().includes(q.trim().toLowerCase()))), [plans, q, filter]);

  async function remove(plan) {
    const ok = await confirm({ title: t('plans.deleteTitle'), message: t('plans.deleteText', { title: plan.title }), confirmLabel: t('common.delete'), tone: 'danger' });
    if (!ok) return;
    try {
      await api.del(`/business-plans/${plan.id}`);
      removePlanLocal(plan.id);
      toast.success(t('plans.deleted'));
    } catch (err) {
      toast.error(err.message);
    }
  }

  const count = (s) => (plans || []).filter((p) => p.status === s).length;
  const many = (plans?.length ?? 0) > 3;

  return (
    <>
      <header className="ph">
        <div>
          <h1>{t('nav.projects')}</h1>
          {plans?.length > 0 && <p className="ph-sub">{t('plans.count', { count: plans.length })}</p>}
        </div>
        <Button icon={Plus} onClick={() => setCreating(true)}>{t('plans.new')}</Button>
      </header>

      {error && !plans && <Alert tone="error">{error}</Alert>}
      {plans === null && !error && <SkeletonCards />}

      {plans?.length === 0 && (
        <EmptyState icon={Mountain} title={t('plans.emptyTitle')} text={t('plans.emptyText')}
          action={<Button icon={Plus} onClick={() => setCreating(true)}>{t('plans.new')}</Button>} />
      )}

      {plans?.length > 0 && (
        <>
          <div className="stats">
            <StatCard icon={FolderKanban} tone="brand" label={t('plans.statTotal')} value={plans.length} />
            <StatCard icon={PencilLine} tone="neutral" label={t('status.drafting')} value={count('drafting')} />
            <StatCard icon={Rocket} tone="good" label={t('status.executing')} value={count('executing')} />
          </div>

          {many && (
            <div className="toolbar">
              <div className="search">
                <Search size={17} aria-hidden="true" />
                <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('plans.search')} aria-label={t('plans.search')} />
              </div>
              <Segmented label={t('plans.filter')} value={filter} onChange={setFilter} options={[
                { value: 'all', label: t('common.all') },
                { value: 'drafting', label: t('status.drafting') },
                { value: 'generated', label: t('status.generated') },
                { value: 'executing', label: t('status.executing') },
              ]} />
            </div>
          )}

          {visible.length === 0 ? (
            <EmptyState compact icon={Search} title={t('plans.noResult')} />
          ) : (
            <ul className="pcards">
              {visible.map((p) => {
                const st = PLAN_STATUS[p.status];
                const pct = p.sections_total ? Math.round((p.sections_validated / p.sections_total) * 100) : 0;
                return (
                  <li key={p.id} className="pcard">
                    <Link to={`/plans/${p.id}`} className="pcard-main">
                      <Chip tone={st.tone} icon={st.icon}>{t(st.key)}</Chip>
                      <span className="pcard-title">{p.title}</span>
                      <span className="pcard-sector">{p.sector}</span>
                      <span className="pcard-progress">
                        <span className="bar" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label={t('plans.progress')}><span style={{ width: `${pct}%` }} /></span>
                        <span>{t('plans.sectionsOf', { done: p.sections_validated, total: p.sections_total })}</span>
                      </span>
                      <span className="pcard-date"><CalendarDays size={14} aria-hidden="true" />{fmtDate(p.updated_at)}</span>
                    </Link>
                    <Button variant="ghost" size="sm" iconOnly icon={Trash2} className="pcard-del" onClick={() => remove(p)} aria-label={`${t('common.delete')} : ${p.title}`} title={t('common.delete')} />
                  </li>
                );
              })}
            </ul>
          )}
        </>
      )}

      <NewPlanDialog open={creating} onClose={() => setCreating(false)} key={creating ? 'open' : 'closed'} />
    </>
  );
}
