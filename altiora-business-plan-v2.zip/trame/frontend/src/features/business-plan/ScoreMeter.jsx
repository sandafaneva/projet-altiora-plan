import { Check } from 'lucide-react';
import { useI18n } from '../../shared/i18n.jsx';

/** Anneau de score : vert = seuil atteint ou validée, ambre = à consolider, rouge = incomplète. Le nombre reste écrit dans l'anneau. */
export default function ScoreMeter({ score, validated = false, size = 'sm', threshold = 70 }) {
  const { t } = useI18n();
  const hasScore = score !== null && score !== undefined;
  const tone = validated ? 'good' : !hasScore ? 'none' : score >= threshold ? 'good' : score >= 40 ? 'mid' : 'low';
  const label = validated ? t('section.validated') : hasScore ? t('score.aria', { score }) : t('score.none');
  return (
    <span className={`meter ${size} ${tone} ${validated ? 'valid' : ''}`} style={{ '--p': validated ? 100 : score ?? 0 }} role="img" aria-label={label}>
      <span className="meter-in">{validated ? <Check size={size === 'lg' ? 30 : 15} strokeWidth={3} /> : hasScore ? score : ''}</span>
    </span>
  );
}

/** Anneau de progression du projet : sections validées sur le total. */
export function Ring({ value, total, size = 56 }) {
  const { t } = useI18n();
  const pct = total ? Math.round((value / total) * 100) : 0;
  return (
    <span className="ring" style={{ '--p': pct, '--s': `${size}px` }} role="img" aria-label={t('ring.aria', { value, total })}>
      <span className="ring-in">{value}<small>/{total}</small></span>
    </span>
  );
}
