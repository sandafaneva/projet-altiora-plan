import { useState } from 'react';
import { Lightbulb, Pencil, RefreshCw, Save, Target, Users } from 'lucide-react';
import { api } from '../../shared/api.js';
import { useI18n } from '../../shared/i18n.jsx';
import { useToast } from '../../shared/feedback.jsx';
import { Alert, Button, Field } from '../../shared/ui.jsx';
import Modal from '../../shared/Modal.jsx';

// R16 : le projet reste modifiable. R9 : l'agent de planification peut refaire le détail des sections non validées.

/** Relance la planification sans toucher aux sections validées. */
export function useReplan(planId, onChanged) {
  const { t } = useI18n();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  async function replan() {
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const d = await api.post(`/business-plans/${planId}/replan`);
      if (d.kept_validated.length) setNotice(t('replan.kept', { count: d.kept_validated.length }));
      else toast.success(t('replan.done'));
      await onChanged();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }
  return { replan, busy, notice, error, clear: () => { setNotice(''); setError(''); } };
}

export function ReplanBanner({ replan, busy, notice, error, clear, stale }) {
  const { t } = useI18n();
  return (
    <>
      {stale && (
        <Alert tone="warning" title={t('replan.staleTitle')}
          action={<Button size="sm" icon={RefreshCw} busy={busy} busyLabel={t('replan.running')} onClick={replan}>{t('replan.action')}</Button>}>
          {t('replan.staleText')}
        </Alert>
      )}
      {busy && !stale && <Alert tone="info">{t('replan.running')}</Alert>}
      {notice && <Alert tone="success" onClose={clear}>{notice}</Alert>}
      {error && <Alert tone="error" onClose={clear}>{error}</Alert>}
    </>
  );
}

export function EditProjectDialog({ plan, open, onClose, onChanged }) {
  const { t } = useI18n();
  const toast = useToast();
  const [form, setForm] = useState({ idea: plan.idea, sector: plan.sector, target_clients: plan.target_clients });
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => { setForm({ ...form, [k]: e.target.value }); if (errors[k]) setErrors({ ...errors, [k]: undefined }); };

  async function save(ev) {
    ev.preventDefault();
    const e = {};
    if (form.idea.trim().length < 10) e.idea = t('val.ideaMin');
    if (form.sector.trim().length < 2) e.sector = t('val.required');
    if (form.target_clients.trim().length < 2) e.target_clients = t('val.required');
    setErrors(e);
    setError('');
    if (Object.keys(e).length) return;
    setBusy(true);
    try {
      await api.patch(`/business-plans/${plan.id}`, { idea: form.idea.trim(), sector: form.sector.trim(), target_clients: form.target_clients.trim() });
      await onChanged();
      toast.success(t('project.updated'));
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} busy={busy} icon={Pencil} title={t('project.edit')} description={t('project.editSub')}
      footer={(
        <>
          <Button variant="secondary" onClick={onClose} disabled={busy}>{t('common.cancel')}</Button>
          <Button type="submit" form="edit-project" icon={Save} busy={busy} busyLabel={t('common.saving')}>{t('common.save')}</Button>
        </>
      )}>
      <form id="edit-project" onSubmit={save} noValidate>
        <Field label={t('plan.idea')} icon={Lightbulb} error={errors.idea} required>
          <textarea rows={4} value={form.idea} onChange={set('idea')} maxLength={2000} />
        </Field>
        <div className="row2">
          <Field label={t('plan.sector')} icon={Target} error={errors.sector} required>
            <input value={form.sector} onChange={set('sector')} maxLength={160} />
          </Field>
          <Field label={t('plan.clients')} icon={Users} error={errors.target_clients} required>
            <input value={form.target_clients} onChange={set('target_clients')} maxLength={255} />
          </Field>
        </div>
        {error && <Alert tone="error">{error}</Alert>}
      </form>
    </Modal>
  );
}
