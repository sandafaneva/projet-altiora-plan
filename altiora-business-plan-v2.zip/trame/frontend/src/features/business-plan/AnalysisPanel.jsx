import { ArrowUpRight, CircleAlert, CircleCheck, CircleHelp, Sparkles, Target, TriangleAlert } from 'lucide-react';
import { useI18n } from '../../shared/i18n.jsx';
import { Button, EmptyState } from '../../shared/ui.jsx';
import ScoreMeter from './ScoreMeter.jsx';

function Insight({ tone, icon: Icon, title, items }) {
  return (
    <div className={`callout ${tone}`}>
      <h3><Icon size={16} aria-hidden="true" />{title}</h3>
      <ul>{items.map((x, i) => <li key={i}>{x}</li>)}</ul>
    </div>
  );
}

// R13 (analyse du résultat) et R14 (guidage) : la colonne de droite dit où en est la section
// et pose des questions concrètes dont les réponses alimentent la prochaine génération.
export default function AnalysisPanel({ section, threshold, answers, setAnswers, onUseSuggestion, disabled }) {
  const { t } = useI18n();
  const a = section.analysis;

  if (!a) {
    return (
      <aside className="guidance" aria-label={t('analysis.title')}>
        <EmptyState compact icon={Sparkles} title={t('analysis.title')} text={t('analysis.empty')} />
      </aside>
    );
  }

  const reached = a.score >= threshold;
  const tone = reached ? 'good' : a.score >= 40 ? 'mid' : 'low';

  return (
    <aside className="guidance" aria-label={t('analysis.title')}>
      <div className="score-head">
        <ScoreMeter score={a.score} size="lg" threshold={threshold} />
        <div>
          <h3 className={`verdict-title ${tone}`}>{reached ? t('analysis.ok') : a.score >= 40 ? t('analysis.mid') : t('analysis.low')}</h3>
          <p className="hint"><Target size={13} aria-hidden="true" />{t('analysis.threshold', { threshold })}</p>
        </div>
      </div>
      {a.verdict && <p className="verdict">{a.verdict}</p>}

      {a.points_forts.length > 0 && <Insight tone="good" icon={CircleCheck} title={t('analysis.strengths')} items={a.points_forts} />}
      {a.manques.length > 0 && <Insight tone="warn" icon={TriangleAlert} title={t('analysis.gaps')} items={a.manques} />}
      {a.incoherences?.length > 0 && <Insight tone="bad" icon={CircleAlert} title={t('analysis.inconsistencies')} items={a.incoherences} />}

      {a.questions_guidees.length > 0 && (
        <div className="callout brand">
          <h3><CircleHelp size={16} aria-hidden="true" />{t('analysis.questions')}</h3>
          {a.questions_guidees.map((q) => (
            <label key={q} className="question">
              {q}
              <textarea rows={2} value={answers[q] || ''} onChange={(e) => setAnswers({ ...answers, [q]: e.target.value })} maxLength={1500} disabled={disabled} placeholder={t('analysis.answerPh')} />
            </label>
          ))}
        </div>
      )}

      {a.suggestion_prompt && (
        <div className="callout brand">
          <h3><Sparkles size={16} aria-hidden="true" />{t('analysis.suggestion')}</h3>
          <p className="suggestion">{a.suggestion_prompt}</p>
          <Button variant="secondary" size="sm" icon={ArrowUpRight} onClick={() => onUseSuggestion(a.suggestion_prompt)} disabled={disabled}>{t('analysis.use')}</Button>
        </div>
      )}
    </aside>
  );
}
