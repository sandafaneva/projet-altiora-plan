import { useEffect, useState } from 'react';
import { Bot, PencilLine, RotateCcw, History } from 'lucide-react';
import { api } from '../../shared/api.js';
import { useI18n } from '../../shared/i18n.jsx';
import { useToast } from '../../shared/feedback.jsx';
import { Alert, Button, Chip } from '../../shared/ui.jsx';

const SOURCE = { ai: { key: 'ver.ai', icon: Bot }, manual: { key: 'ver.manual', icon: PencilLine }, restore: { key: 'ver.sourceRestore', icon: RotateCcw } };

export default function VersionHistory({ planId, sectionKey, currentContent, locked, onRestored }) {
  const { t, fmtDateTime } = useI18n();
  const toast = useToast();
  const [items, setItems] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get(`/business-plans/${planId}/sections/${sectionKey}/iterations`)
      .then((d) => setItems(d.iterations))
      .catch((e) => setError(e.message));
  }, [planId, sectionKey, currentContent]);

  async function restore(id) {
    try {
      await api.post(`/business-plans/${planId}/sections/${sectionKey}/restore/${id}`);
      await onRestored();
      toast.success(t('ver.restored'));
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div className="versions">
      {error && <Alert tone="error">{error}</Alert>}
      {items === null && !error && <p className="hint">{t('common.loading')}</p>}
      {items?.length === 0 && <p className="hint">{t('ver.none')}</p>}
      <ul>
        {items?.map((it) => {
          const src = SOURCE[it.source] || SOURCE.ai;
          const Icon = src.icon;
          return (
            <li key={it.id}>
              <span className="ver-icon"><Icon size={16} aria-hidden="true" /></span>
              <div className="ver-main">
                <strong>{t('ver.version', { n: it.version })}</strong>
                <span className="muted">{t(src.key)}{it.score !== null && ` · ${it.score}/100`}</span>
                <span className="hint">{fmtDateTime(it.created_at)}</span>
                {it.user_prompt && <span className="hint clamp-2">{it.user_prompt}</span>}
              </div>
              {it.result !== currentContent && !locked && <Button variant="secondary" size="sm" icon={History} onClick={() => restore(it.id)}>{t('ver.restore')}</Button>}
              {it.result === currentContent && <Chip tone="brand">{t('ver.current')}</Chip>}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
