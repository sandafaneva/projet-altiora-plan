import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { BookOpen, Check, ChevronRight, Ellipsis, FileText, Lock, Pencil, RefreshCw, Rocket, TriangleAlert, WalletCards } from 'lucide-react';
import { api } from '../../shared/api.js';
import { useI18n } from '../../shared/i18n.jsx';
import { useConfirm } from '../../shared/feedback.jsx';
import { refreshPlans } from '../../shared/plansStore.js';
import { Alert, Button, Chip } from '../../shared/ui.jsx';
import Menu from '../../shared/Menu.jsx';
import { SkeletonPage } from '../../shared/Skeleton.jsx';
import useDocumentTitle from '../../shared/useDocumentTitle.js';
import SectionRail from './SectionRail.jsx';
import SectionEditor from './SectionEditor.jsx';
import FinalDocument from './FinalDocument.jsx';
import Tracking from './Tracking.jsx';
import Financials from './Financials.jsx';
import { EditProjectDialog, ReplanBanner, useReplan } from './ProjectInfo.jsx';
import { Ring } from './ScoreMeter.jsx';
import PlanOverview from './PlanOverview.jsx';
import { PLAN_STATUS } from './status.js';

export default function PlanWorkspace() {
  const { t } = useI18n();
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('redaction');
  const [activeKey, setActiveKey] = useState(null);
  const [editing, setEditing] = useState(false);
  const confirm = useConfirm();
  const navigate = useNavigate();
  const dirtyRef = useRef(false); // vrai tant qu'une vue contient des modifications non enregistrées
  const markDirty = useCallback((v) => { dirtyRef.current = v; }, []);
  useDocumentTitle(data?.plan.title);

  // Toute sortie de la vue (autre étape, autre section, retour aux projets) demande confirmation s'il reste du travail non enregistré
  const guard = useCallback(async (action) => {
    if (dirtyRef.current) {
      const ok = await confirm({ title: t('guard.title'), message: t('guard.text'), confirmLabel: t('guard.leave'), cancelLabel: t('guard.stay'), tone: 'danger' });
      if (!ok) return;
      dirtyRef.current = false;
    }
    action();
  }, [confirm, t]);

  useEffect(() => {
    const warn = (e) => { if (dirtyRef.current) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, []);

  const load = useCallback(async () => {
    try {
      const d = await api.get(`/business-plans/${id}`);
      setData(d);
      setActiveKey((k) => k ?? d.sections.find((s) => s.status !== 'validated')?.section_key ?? d.sections[0]?.section_key);
      refreshPlans(); // la barre latérale et la liste des projets suivent l'avancement
    } catch (e) {
      setError(e.message);
    }
  }, [id]);

  useEffect(() => { load(); }, [load]);
  const replanner = useReplan(id, load);

  if (error) {
    return (
      <>
        <Alert tone="error">{error}</Alert>
        <Link to="/" className="link">{t('common.backToProjects')}</Link>
      </>
    );
  }
  if (!data) return <SkeletonPage />;

  const { plan, sections, validation_threshold: threshold, financials } = data;
  const validated = sections.filter((s) => s.status === 'validated').length;
  const active = sections.find((s) => s.section_key === activeKey) || sections[0];
  const executing = plan.status === 'executing';
  const generated = plan.status !== 'drafting';
  const financeStale = financials.stale_sections.length > 0;
  const status = PLAN_STATUS[plan.status];
  const untouched = !executing && sections.every((s) => !s.content);

  // Parcours en 4 étapes : chacune montre son état (terminée, à revoir, verrouillée) pour que l'utilisateur sache toujours où il en est
  const steps = [
    { key: 'redaction', icon: BookOpen, state: validated === sections.length ? 'done' : '', sub: t('plans.sectionsOf', { done: validated, total: sections.length }) },
    { key: 'finances', icon: WalletCards, state: financeStale ? 'warn' : financials.defined ? 'done' : '', sub: financeStale ? t('tab.financesStale') : financials.defined ? t('tab.financesOk') : t('tab.financesTodo') },
    { key: 'final', icon: FileText, state: generated ? 'done' : '', sub: generated ? t('tab.finalOk') : t('tab.finalTodo') },
    { key: 'suivi', icon: Rocket, state: executing ? 'done' : '', disabled: !executing, sub: executing ? t('tab.suiviOk') : t('tab.suiviLocked') },
  ];

  return (
    <>
      <nav className="crumbs" aria-label={t('a11y.breadcrumb')}>
        <Link to="/" onClick={(e) => { if (dirtyRef.current) { e.preventDefault(); guard(() => navigate('/')); } }}>{t('nav.projects')}</Link>
        <ChevronRight size={14} aria-hidden="true" />
        <span aria-current="page">{plan.title}</span>
      </nav>

      <header className="ph plan-head">
        <Ring value={validated} total={sections.length} />
        <div className="ph-main">
          <h1>{plan.title}</h1>
          <p className="ph-sub">
            <Chip tone={status.tone} icon={status.icon}>{t(status.key)}</Chip>
            <span>{plan.sector}</span><i aria-hidden="true">·</i><span>{plan.target_clients}</span>
          </p>
        </div>
        {!executing && (
          <div className="ph-actions">
            <Button variant="secondary" icon={Pencil} onClick={() => setEditing(true)}>{t('project.edit')}</Button>
            <Menu label={t('common.more')} className="more" trigger={<Ellipsis size={18} aria-hidden="true" />}
              items={[{ key: 'replan', icon: RefreshCw, label: t('replan.action'), onClick: replanner.replan, disabled: replanner.busy }]} />
          </div>
        )}
      </header>

      <ReplanBanner {...replanner} stale={Boolean(plan.outline?.stale) && !executing} />

      <div className="steps" role="tablist" aria-label={t('steps.label')}>
        {steps.map(({ key, icon: Icon, state, disabled, sub }, i) => (
          <button key={key} type="button" role="tab" id={`tab-${key}`} aria-selected={tab === key} aria-controls="view" disabled={disabled}
            className={`step ${state}`} title={disabled ? t('tab.suiviHint') : undefined} onClick={() => guard(() => setTab(key))}>
            <span className="step-badge" aria-hidden="true">
              {state === 'done' ? <Check size={16} strokeWidth={3} /> : state === 'warn' ? <TriangleAlert size={15} /> : disabled ? <Lock size={14} /> : i + 1}
            </span>
            <span className="step-text"><strong><Icon size={16} aria-hidden="true" />{t(`tab.${key}`)}</strong><small>{sub}</small></span>
          </button>
        ))}
      </div>

      <div key={tab} className="view" id="view" role="tabpanel" aria-labelledby={`tab-${tab}`}>
        {tab === 'redaction' && untouched && (
          <PlanOverview sections={sections} onSelect={(k) => { setActiveKey(k); requestAnimationFrame(() => document.getElementById('prompt')?.focus()); }} />
        )}
        {tab === 'redaction' && (
          <div className="workspace">
            <SectionRail sections={sections} activeKey={active.section_key} onSelect={(k) => guard(() => setActiveKey(k))} threshold={threshold} />
            <SectionEditor key={active.section_key} plan={plan} section={active} threshold={threshold} onChanged={load}
              financials={financials} onGoToFinances={() => guard(() => setTab('finances'))} onDirty={markDirty} />
          </div>
        )}
        {tab === 'finances' && (
          <Financials key={plan.id} plan={plan} staleSections={financials.stale_sections} onChanged={load} onDirty={markDirty}
            onGoToSection={(k) => guard(() => { setActiveKey(k); setTab('redaction'); })} />
        )}
        {tab === 'final' && (
          <FinalDocument plan={plan} sections={sections} financials={financials} onChanged={load}
            onStarted={() => setTab('suivi')} onGoToFinances={() => setTab('finances')}
            onGoToSection={(k) => { setActiveKey(k); setTab('redaction'); }} />
        )}
        {tab === 'suivi' && executing && <Tracking plan={plan} />}
      </div>

      <EditProjectDialog key={`${plan.idea}|${plan.sector}|${plan.target_clients}|${editing}`} plan={plan} open={editing} onClose={() => setEditing(false)} onChanged={load} />
    </>
  );
}
