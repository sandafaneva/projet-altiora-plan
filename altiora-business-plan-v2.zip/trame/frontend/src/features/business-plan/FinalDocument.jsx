import { useState } from 'react';
import { CalendarDays, ChevronDown, Circle, CircleAlert, CircleCheck, Copy, Download, FileCheck2, FileDown, FileText, Rocket, ShieldCheck, Sparkles, TriangleAlert } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { api, download } from '../../shared/api.js';
import { useI18n } from '../../shared/i18n.jsx';
import { useConfirm, useToast } from '../../shared/feedback.jsx';
import { Alert, Button, Field } from '../../shared/ui.jsx';
import Menu from '../../shared/Menu.jsx';
import ScoreMeter from './ScoreMeter.jsx';
import { sectionTitle } from './status.js';

const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

// R15 : génération finale du business plan, une fois toutes les sections validées.
// R10 : lancement de l'exécution et du suivi.
export default function FinalDocument({ plan, sections, financials, onChanged, onStarted, onGoToFinances, onGoToSection }) {
  const { t } = useI18n();
  const confirm = useConfirm();
  const toast = useToast();
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [startDate, setStartDate] = useState(today);

  const pending = sections.filter((s) => s.status !== 'validated');
  const done = sections.length - pending.length;
  const canGenerate = pending.length === 0 && plan.status !== 'executing';
  const review = plan.final_review;

  async function generate() {
    setBusy('final');
    setError('');
    try {
      await api.post(`/business-plans/${plan.id}/generate-final`);
      await onChanged();
      toast.success(t('final.generated'));
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy('');
    }
  }

  async function startExecution() {
    const ok = await confirm({ title: t('final.startTitle'), message: t('final.startText'), confirmLabel: t('final.startConfirm') });
    if (!ok) return;
    setBusy('start');
    setError('');
    try {
      await api.post(`/business-plans/${plan.id}/execution/start`, { start_date: startDate });
      await onChanged();
      toast.success(t('final.started'));
      onStarted();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy('');
    }
  }

  async function exportFile(format) {
    setBusy(format);
    setError('');
    try {
      await download(`/business-plans/${plan.id}/export/${format}`, `business-plan.${format}`);
      toast.success(format === 'docx' ? t('final.wordDone') : t('final.pdfDone'));
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy('');
    }
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(plan.final_document);
      toast.success(t('final.copied'));
    } catch {
      toast.error(t('err.copy'));
    }
  }

  function downloadMarkdown() {
    const blob = new Blob([plan.final_document], { type: 'text/markdown;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${plan.title.replace(/[^\p{L}\p{N}]+/gu, '-').toLowerCase()}.md`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  return (
    <div className="final">
      {!plan.final_document && (
        <div className="panel ready">
          <div className="ready-head">
            <span className="ready-icon"><ShieldCheck size={22} aria-hidden="true" /></span>
            <div>
              <h2>{t('final.readyTitle')}</h2>
              <p className="muted">{pending.length ? t('final.readyPending', { count: pending.length }) : t('final.readyOk')}</p>
            </div>
            <span className="ready-count">{done}/{sections.length}</span>
          </div>
          <div className="bar lg" role="progressbar" aria-valuenow={done} aria-valuemin={0} aria-valuemax={sections.length} aria-label={t('plans.progress')}><span style={{ width: `${(done / sections.length) * 100}%` }} /></div>

          <ul className="checklist">
            {sections.map((s) => {
              const ok = s.status === 'validated';
              return (
                <li key={s.section_key} className={ok ? 'ok' : ''}>
                  {ok ? <CircleCheck size={18} aria-hidden="true" /> : <Circle size={18} aria-hidden="true" />}
                  <span>{sectionTitle(t, s)}</span>
                  {!ok && <button type="button" className="link" onClick={() => onGoToSection(s.section_key)}>{t('final.goWrite')}</button>}
                </li>
              );
            })}
            <li className={financials.defined ? 'ok' : 'opt'}>
              {financials.defined ? <CircleCheck size={18} aria-hidden="true" /> : <TriangleAlert size={18} aria-hidden="true" />}
              <span>{t('final.financeItem')}</span>
              {!financials.defined && <button type="button" className="link" onClick={onGoToFinances}>{t('final.goFinance')}</button>}
            </li>
          </ul>

          {error && <Alert tone="error" onClose={() => setError('')}>{error}</Alert>}
          <Button size="lg" icon={Sparkles} onClick={generate} disabled={!canGenerate} busy={busy === 'final'} busyLabel={t('final.generating')}>{t('final.generate')}</Button>
          {busy === 'final' && <div className="progressline" aria-hidden="true"><span /></div>}
        </div>
      )}

      {plan.final_document && (
        <>
          <div className="actionbar no-print">
            <span className="actionbar-title"><FileCheck2 size={18} aria-hidden="true" />{t('final.ready')}</span>
            <Menu label={t('final.export')} align="right" triggerClass="btn primary" trigger={<><Download size={17} aria-hidden="true" /><span>{t('final.export')}</span><ChevronDown size={15} aria-hidden="true" /></>}
              items={[
                { key: 'docx', icon: FileDown, label: t('final.word'), onClick: () => exportFile('docx') },
                { key: 'pdf', icon: FileDown, label: t('final.pdf'), onClick: () => exportFile('pdf') },
                { key: 'md', icon: FileText, label: t('final.markdown'), onClick: downloadMarkdown },
                { key: 'copy', icon: Copy, label: t('final.copy'), onClick: copy },
              ]} />
          </div>
          {busy === 'docx' || busy === 'pdf' ? <Alert tone="info">{t('final.preparing')}</Alert> : null}
          {error && <Alert tone="error" onClose={() => setError('')}>{error}</Alert>}

          {plan.status === 'generated' && (
            <div className="panel launch no-print">
              <span className="launch-icon"><Rocket size={22} aria-hidden="true" /></span>
              <div className="launch-text">
                <h2>{t('final.nextTitle')}</h2>
                <p className="muted">{t('final.nextText')}</p>
              </div>
              <Field label={t('final.startDate')} icon={CalendarDays} className="launch-date">
                <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
              </Field>
              <Button variant="success" icon={Rocket} onClick={startExecution} disabled={!startDate} busy={busy === 'start'} busyLabel={t('final.starting')}>{t('final.start')}</Button>
            </div>
          )}

          {review && (
            <div className="panel review no-print">
              <div className="review-top">
                <ScoreMeter score={review.coherence_score} size="lg" />
                <div>
                  <h2>{t('final.coherence')}</h2>
                  {review.verdict && <p className="muted">{review.verdict}</p>}
                </div>
              </div>
              <div className="review-cols">
                {review.incoherences.length > 0 && (
                  <div className="callout bad"><h3><CircleAlert size={16} aria-hidden="true" />{t('final.inconsistencies')}</h3><ul>{review.incoherences.map((x, i) => <li key={i}>{x}</li>)}</ul></div>
                )}
                {review.recommandations.length > 0 && (
                  <div className="callout warn"><h3><TriangleAlert size={16} aria-hidden="true" />{t('final.beforePresenting')}</h3><ul>{review.recommandations.map((x, i) => <li key={i}>{x}</li>)}</ul></div>
                )}
              </div>
            </div>
          )}

          <article className="prose document">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{plan.final_document}</ReactMarkdown>
          </article>
        </>
      )}
    </div>
  );
}
