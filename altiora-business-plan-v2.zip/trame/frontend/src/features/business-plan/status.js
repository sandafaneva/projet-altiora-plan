import { CircleCheck, FileCheck2, PencilLine, Rocket } from 'lucide-react';

// Chaque état du projet a une couleur, une icône et un texte : jamais la couleur seule.
export const PLAN_STATUS = {
  drafting: { icon: PencilLine, tone: 'neutral', key: 'status.drafting' },
  generated: { icon: FileCheck2, tone: 'brand', key: 'status.generated' },
  executing: { icon: Rocket, tone: 'good', key: 'status.executing' },
};

export const SECTION_STATE = {
  pending: { key: 'section.pending' },
  in_progress: { key: 'section.inProgress' },
  validated: { key: 'section.validated', icon: CircleCheck },
};

/** Le titre d'une section suit la langue de l'interface ; on retombe sur le titre enregistré si la clé est inconnue. */
export function sectionTitle(t, section) {
  const key = `sec.${section.section_key ?? section.key}.title`;
  const v = t(key);
  return v === key ? section.title : v;
}

const norm = (x) => String(x ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/^\d+\s+/, '').trim();

/** Le titre de la section est déjà affiché au-dessus : on retire un titre identique répété au début du texte. */
export function withoutTitle(t, section, markdown) {
  const text = String(markdown ?? '');
  const m = text.match(/^\s*(?:#{1,6}\s+|\*\*)([^\n]+?)\**\s*(?:\n+|$)/);
  if (!m) return text;
  const known = [section.title, sectionTitle(t, section)].map(norm);
  return known.includes(norm(m[1])) ? text.slice(m[0].length).trimStart() : text;
}
