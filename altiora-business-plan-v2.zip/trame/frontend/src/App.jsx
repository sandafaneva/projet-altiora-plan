import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './shared/AuthContext.jsx';
import { LangProvider, useI18n } from './shared/i18n.jsx';
import { ThemeProvider } from './shared/theme.jsx';
import { FeedbackProvider } from './shared/feedback.jsx';
import ErrorBoundary from './shared/ErrorBoundary.jsx';
import AuthPage from './shared/AuthPage.jsx';
import Layout from './shared/Layout.jsx';
import PlansPage from './features/business-plan/PlansPage.jsx';
import PlanWorkspace from './features/business-plan/PlanWorkspace.jsx';

function Protected({ children }) {
  const { t } = useI18n();
  const { user, loading } = useAuth();
  if (loading) return <div className="boot" aria-busy="true"><span className="spin-ring" aria-hidden="true" />{t('common.loading')}</div>;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

// R1 : la fonctionnalité vit dans src/features/business-plan. Dans l'application existante,
// il suffit de déclarer ces deux routes et de réutiliser l'authentification en place.
export default function App() {
  return (
    <ErrorBoundary>
      <LangProvider>
        <ThemeProvider>
          <FeedbackProvider>
            <AuthProvider>
              <Routes>
                <Route path="/login" element={<AuthPage />} />
                <Route element={<Protected><Layout /></Protected>}>
                  <Route path="/" element={<PlansPage />} />
                  <Route path="/plans/:id" element={<PlanWorkspace />} />
                </Route>
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </AuthProvider>
          </FeedbackProvider>
        </ThemeProvider>
      </LangProvider>
    </ErrorBoundary>
  );
}
