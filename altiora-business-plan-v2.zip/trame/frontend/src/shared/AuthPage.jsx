import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { ArrowRight, BrainCircuit, Eye, EyeOff, FileText, Lightbulb, Lock, Mail, TrendingUp, User, WalletCards } from 'lucide-react';
import { useAuth } from './AuthContext.jsx';
import { useI18n } from './i18n.jsx';
import { Alert, Button, Field, Segmented } from './ui.jsx';
import Logo from './Logo.jsx';
import Contours from './Contours.jsx';
import ThemeToggle from './ThemeToggle.jsx';
import LangSwitch from './LangSwitch.jsx';
import useDocumentTitle from './useDocumentTitle.js';

const STEPS = [
  { icon: Lightbulb, key: 'auth.step.idea' },
  { icon: BrainCircuit, key: 'auth.step.analysis' },
  { icon: WalletCards, key: 'auth.step.finance' },
  { icon: FileText, key: 'auth.step.plan' },
  { icon: TrendingUp, key: 'auth.step.follow' },
];

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function AuthPage() {
  const { t } = useI18n();
  const { user, authenticate } = useAuth();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [show, setShow] = useState(false);

  useDocumentTitle(mode === 'login' ? t('auth.login') : t('auth.register'));
  if (user) return <Navigate to="/" replace />;

  const set = (k) => (e) => { setForm({ ...form, [k]: e.target.value }); if (errors[k]) setErrors({ ...errors, [k]: undefined }); };

  // Validation dans la langue de l'interface (les messages du navigateur ne suivent pas le choix de langue)
  function validate() {
    const e = {};
    if (mode === 'register' && form.name.trim().length < 2) e.name = t('val.name');
    if (!EMAIL_RE.test(form.email.trim())) e.email = t('val.email');
    if (!form.password) e.password = t('val.passwordRequired');
    else if (mode === 'register' && form.password.length < 8) e.password = t('val.passwordMin');
    return e;
  }

  async function submit(ev) {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    setError('');
    if (Object.keys(e).length) {
      requestAnimationFrame(() => document.querySelector('.auth-card [aria-invalid="true"]')?.focus());
      return;
    }
    setBusy(true);
    try {
      await authenticate(mode, mode === 'login'
        ? { email: form.email.trim(), password: form.password }
        : { name: form.name.trim(), email: form.email.trim(), password: form.password });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  const switchMode = (m) => { setMode(m); setErrors({}); setError(''); };

  return (
    <div className="auth">
      <section className="auth-hero">
        <Contours />
        <div className="auth-brand"><Logo size={38} />ALTIORA</div>
        <div className="auth-copy">
          <h1>{t('auth.headline')}</h1>
          <p>{t('auth.sub')}</p>
        </div>
        <ol className="route" aria-label={t('auth.journey')}>
          {STEPS.map(({ icon: Icon, key }, i) => (
            <li key={key} style={{ '--i': i }}><span className="route-node"><Icon size={18} aria-hidden="true" /></span>{t(key)}</li>
          ))}
        </ol>
      </section>

      <main className="auth-panel">
        <div className="auth-tools"><LangSwitch /><ThemeToggle /></div>
        <div className="auth-card">
          <Segmented className="auth-tabs" label={t('auth.mode')} value={mode} onChange={switchMode} options={[
            { value: 'login', label: t('auth.login') },
            { value: 'register', label: t('auth.register') },
          ]} />
          <div className="auth-title">
            <h1>{mode === 'login' ? t('auth.welcome') : t('auth.create')}</h1>
            <p>{mode === 'login' ? t('auth.welcomeSub') : t('auth.createSub')}</p>
          </div>
          <form onSubmit={submit} noValidate>
            {mode === 'register' && (
              <Field label={t('auth.name')} icon={User} error={errors.name} required>
                <input value={form.name} onChange={set('name')} autoComplete="name" />
              </Field>
            )}
            <Field label={t('auth.email')} icon={Mail} error={errors.email} required>
              <input type="email" value={form.email} onChange={set('email')} autoComplete="email" inputMode="email" placeholder={t('auth.emailPh')} />
            </Field>
            <Field label={t('auth.password')} icon={Lock} error={errors.password} required
              hint={mode === 'register' ? t('auth.passwordHint') : undefined}
              after={<button type="button" className="control-btn" onClick={() => setShow((s) => !s)} aria-pressed={show}
                aria-label={show ? t('auth.hide') : t('auth.show')} title={show ? t('auth.hide') : t('auth.show')}>{show ? <EyeOff size={17} /> : <Eye size={17} />}</button>}>
              <input type={show ? 'text' : 'password'} value={form.password} onChange={set('password')} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} />
            </Field>
            {error && <Alert tone="error">{error}</Alert>}
            <Button type="submit" size="lg" block busy={busy} busyLabel={t('common.wait')} icon={ArrowRight}>
              {mode === 'login' ? t('auth.submitLogin') : t('auth.submitRegister')}
            </Button>
          </form>
        </div>
      </main>
    </div>
  );
}
