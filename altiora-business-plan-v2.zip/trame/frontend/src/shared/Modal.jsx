import { useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import { useI18n } from './i18n.jsx';

/** Fenêtre modale sur l'élément <dialog> natif : focus piégé, fond inerte, Échap pour fermer. */
export default function Modal({ open, onClose, title, icon: Icon, tone = 'brand', size = 'md', busy = false, children, footer, description }) {
  if (!open) return null;
  return <ModalInner {...{ onClose, title, Icon, tone, size, busy, footer, description }}>{children}</ModalInner>;
}

function ModalInner({ onClose, title, Icon, tone, size, busy, footer, description, children }) {
  const { t } = useI18n();
  const ref = useRef(null);
  useEffect(() => {
    const d = ref.current;
    if (d && !d.open) d.showModal();
    return () => { if (d?.open) d.close(); };
  }, []);
  const close = () => { if (!busy) onClose(); };

  return (
    <dialog ref={ref} className={`modal ${size}`} aria-labelledby="modal-title" aria-describedby={description ? 'modal-desc' : undefined}
      onCancel={(e) => { e.preventDefault(); close(); }} onMouseDown={(e) => { if (e.target === ref.current) close(); }}>
      <header className="modal-head">
        {Icon && <span className={`modal-icon ${tone}`}><Icon size={20} aria-hidden="true" /></span>}
        <div>
          <h2 id="modal-title">{title}</h2>
          {description && <p id="modal-desc">{description}</p>}
        </div>
        <button type="button" className="icon-btn" onClick={close} aria-label={t('common.close')} disabled={busy}><X size={18} /></button>
      </header>
      <div className="modal-body">{children}</div>
      {footer && <footer className="modal-foot">{footer}</footer>}
    </dialog>
  );
}
