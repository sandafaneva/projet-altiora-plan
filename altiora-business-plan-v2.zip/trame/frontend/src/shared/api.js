// Le frontend ne parle qu'au backend. Aucune clé IA ici (R5).
import { getLang, tr, translateServerError } from './i18n.jsx';

const BASE = '/api';

export const getToken = () => localStorage.getItem('trame_token');
export const setToken = (t) => (t ? localStorage.setItem('trame_token', t) : localStorage.removeItem('trame_token'));

export class ApiError extends Error {
  constructor(message, status, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

// La langue active accompagne chaque requête : l'IA rédige dans la langue choisie par l'utilisateur.
const headers = (token, json = true) => ({
  ...(json ? { 'Content-Type': 'application/json' } : {}),
  'X-Lang': getLang(),
  ...(token ? { Authorization: `Bearer ${token}` } : {}),
});

async function request(method, path, body) {
  const token = getToken();
  let res;
  try {
    res = await fetch(BASE + path, { method, headers: headers(token), body: body !== undefined ? JSON.stringify(body) : undefined });
  } catch {
    throw new ApiError(tr('err.unreachable'), 0);
  }
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* réponse vide (204) */
  }
  if (!res.ok) {
    if (res.status === 401 && token) {
      setToken(null);
      window.dispatchEvent(new Event('trame:logout'));
    }
    throw new ApiError(translateServerError(data?.error) || tr('err.generic'), res.status, data?.details);
  }
  return data;
}

/** Télécharge un fichier protégé par l'authentification (Word, PDF). */
export async function download(path, fallbackName) {
  let res;
  try {
    res = await fetch(BASE + path, { headers: headers(getToken(), false) });
  } catch {
    throw new ApiError(tr('err.unreachable'), 0);
  }
  if (!res.ok) {
    let message = tr('err.download');
    try { message = translateServerError((await res.json()).error) || message; } catch { /* corps non JSON */ }
    throw new ApiError(message, res.status);
  }
  const name = (res.headers.get('content-disposition') || '').match(/filename="([^"]+)"/)?.[1] || fallbackName;
  const url = URL.createObjectURL(await res.blob());
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export const api = {
  get: (p) => request('GET', p),
  post: (p, b = {}) => request('POST', p, b),
  put: (p, b) => request('PUT', p, b),
  patch: (p, b) => request('PATCH', p, b),
  del: (p) => request('DELETE', p),
};
