import { Info } from 'lucide-react';

// Aide contextuelle : garde l'écran propre, l'explication reste accessible au survol et au clavier.
export default function Tip({ text }) {
  return (
    <span className="tip" tabIndex={0} role="img" aria-label={text} data-tip={text}>
      <Info size={14} strokeWidth={2} />
    </span>
  );
}
