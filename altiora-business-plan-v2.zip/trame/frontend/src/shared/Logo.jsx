// Deux sommets et un point d'or : l'altitude dans ALTIORA.
export default function Logo({ size = 32 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true" className="logo">
      <rect width="32" height="32" rx="9" fill="#315EFB" />
      <path d="M6.5 23.5 13.2 11l4.1 7.2 2.2-3.4 6 8.7" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="13.2" cy="8.2" r="1.9" fill="#F5B83D" />
    </svg>
  );
}
