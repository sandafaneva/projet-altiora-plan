import { useI18n } from './i18n.jsx';

/** Emplacements grisés pendant le chargement : la page garde sa forme. */
export const SkeletonCards = ({ count = 3 }) => {
  const { t } = useI18n();
  return (
    <div className="skel-grid" aria-busy="true" aria-label={t('common.loading')}>
      {Array.from({ length: count }, (_, i) => <span key={i} className="skel card" />)}
    </div>
  );
};

export const SkeletonPage = () => {
  const { t } = useI18n();
  return (
    <div aria-busy="true" aria-label={t('common.loading')}>
      <span className="skel title" />
      <div className="skel-stack">
        <span className="skel line" style={{ width: '60%' }} />
        <span className="skel bar" />
        <span className="skel card" />
        <span className="skel card" />
      </div>
    </div>
  );
};
