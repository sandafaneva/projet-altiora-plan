import { useSyncExternalStore } from 'react';
import { api } from './api.js';

// Liste des projets partagée entre la page Projets et la barre latérale (accès rapide) : une seule source, pas de clignotement.
let state = { plans: null, error: '' };
const subs = new Set();
const emit = (next) => { state = { ...state, ...next }; subs.forEach((fn) => fn()); };

export async function refreshPlans() {
  try {
    const d = await api.get('/business-plans');
    emit({ plans: d.plans, error: '' });
  } catch (e) {
    emit({ error: e.message });
  }
}

export const removePlanLocal = (id) => emit({ plans: (state.plans || []).filter((p) => p.id !== id) });
export const resetPlans = () => emit({ plans: null, error: '' });

export function usePlans() {
  return useSyncExternalStore((fn) => { subs.add(fn); return () => subs.delete(fn); }, () => state);
}
