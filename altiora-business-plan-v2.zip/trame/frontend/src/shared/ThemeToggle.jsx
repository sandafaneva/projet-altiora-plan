import { Monitor, Moon, Sun } from 'lucide-react';
import { Segmented } from './ui.jsx';
import { useI18n } from './i18n.jsx';
import { useTheme } from './theme.jsx';

/** Luminosité : clair, automatique (suit l'appareil) ou sombre. Toujours visible dans la barre supérieure. */
export default function ThemeToggle({ className = '' }) {
  const { t } = useI18n();
  const { pref, set } = useTheme();
  return (
    <Segmented className={className} iconOnly label={t('theme.label')} value={pref} onChange={set} options={[
      { value: 'light', label: t('theme.light'), icon: Sun },
      { value: 'system', label: t('theme.system'), icon: Monitor },
      { value: 'dark', label: t('theme.dark'), icon: Moon },
    ]} />
  );
}
