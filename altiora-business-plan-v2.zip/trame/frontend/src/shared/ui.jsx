import { cloneElement, isValidElement, useId } from 'react';
import { CircleAlert, CircleCheck, Info, Loader2, TriangleAlert, X } from 'lucide-react';
import { useI18n } from './i18n.jsx';
import Tip from './Tip.jsx';

// Les couleurs portent toujours un sens : rouge = erreur, ambre = attention, vert = réussite, bleu = information.
// La couleur n'est jamais seule : chaque état a aussi une icône et un texte (accessibilité, daltonisme).
const TONE_ICON = { error: CircleAlert, warning: TriangleAlert, success: CircleCheck, info: Info };

export function Alert({ tone = 'info', title, children, action, onClose, className = '' }) {
  const { t } = useI18n();
  const Icon = TONE_ICON[tone];
  return (
    <div className={`alert ${tone} ${className}`} role={tone === 'error' ? 'alert' : 'status'}>
      <Icon className="alert-icon" size={20} aria-hidden="true" />
      <div className="alert-body">
        {title && <strong className="alert-title">{title}</strong>}
        {children && <div className="alert-text">{children}</div>}
      </div>
      {action && <div className="alert-action">{action}</div>}
      {onClose && <button type="button" className="alert-close" onClick={onClose} aria-label={t('common.close')}><X size={16} /></button>}
    </div>
  );
}

export function Button({ variant = 'primary', size, icon: Icon, busy = false, busyLabel, iconOnly = false, block = false, className = '', children, disabled, type = 'button', ...rest }) {
  const px = size === 'sm' ? 15 : 17;
  const cls = ['btn', variant, size, iconOnly && 'icon', block && 'block', className].filter(Boolean).join(' ');
  return (
    <button type={type} className={cls} disabled={disabled || busy} aria-busy={busy || undefined} {...rest}>
      {busy ? <Loader2 size={px} className="spin" aria-hidden="true" /> : Icon && <Icon size={px} aria-hidden="true" />}
      {!iconOnly && <span>{busy && busyLabel ? busyLabel : children}</span>}
    </button>
  );
}

/** Champ de formulaire : libellé au-dessus, aide en infobulle, erreur en rouge avec icône, lien accessible entre le champ et son message. */
export function Field({ label, error, hint, tip, required, icon: Icon, after, children, className = '' }) {
  const id = useId();
  const errId = `${id}-err`;
  const child = isValidElement(children)
    ? cloneElement(children, { id, 'aria-invalid': error ? true : undefined, 'aria-describedby': error ? errId : undefined })
    : children;
  return (
    <div className={`field ${error ? 'invalid' : ''} ${className}`}>
      <div className="field-label">
        <label htmlFor={id}>{label}{required && <span className="req" aria-hidden="true"> *</span>}</label>
        {tip && <Tip text={tip} />}
      </div>
      <div className={`control ${Icon ? 'has-icon' : ''} ${after ? 'has-after' : ''}`}>
        {Icon && <Icon className="control-icon" size={17} aria-hidden="true" />}
        {child}
        {after}
      </div>
      {error ? <p className="field-error" id={errId}><CircleAlert size={14} aria-hidden="true" />{error}</p> : hint ? <p className="field-hint">{hint}</p> : null}
    </div>
  );
}

export function Chip({ tone = 'neutral', icon: Icon, children, className = '' }) {
  return <span className={`chip ${tone} ${className}`}>{Icon && <Icon size={13} aria-hidden="true" />}{children}</span>;
}

export function EmptyState({ icon: Icon, title, text, action, compact = false }) {
  return (
    <div className={`empty ${compact ? 'compact' : ''}`}>
      {Icon && <span className="empty-icon"><Icon size={compact ? 22 : 28} strokeWidth={1.7} aria-hidden="true" /></span>}
      <strong>{title}</strong>
      {text && <span>{text}</span>}
      {action}
    </div>
  );
}

/** Contrôle segmenté (choix unique, toujours visible) : luminosité, langue, filtres, aperçu/édition. Flèches du clavier prises en charge. */
export function Segmented({ value, onChange, options, label, className = '', iconOnly = false }) {
  const move = (e, i) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    e.preventDefault();
    const next = options[(i + (e.key === 'ArrowRight' ? 1 : options.length - 1)) % options.length];
    onChange(next.value);
    e.currentTarget.parentElement.querySelector(`[data-v="${next.value}"]`)?.focus();
  };
  return (
    <div className={`seg ${className}`} role="radiogroup" aria-label={label}>
      {options.map(({ value: v, label: text, icon: Icon, title }, i) => (
        <button key={v} type="button" role="radio" data-v={v} aria-checked={value === v} tabIndex={value === v ? 0 : -1}
          aria-label={iconOnly ? text : undefined} title={title || (iconOnly ? text : undefined)} onClick={() => onChange(v)} onKeyDown={(e) => move(e, i)}>
          {Icon && <Icon size={15} aria-hidden="true" />}
          {!iconOnly && <span>{text}</span>}
        </button>
      ))}
    </div>
  );
}

/** Carte d'indicateur : valeur en grand, contexte en dessous. Le bord et l'icône prennent la couleur du sens (vert bon, ambre à surveiller, rouge critique). */
export function Kpi({ icon: Icon, label, value, sub, tone = '' }) {
  return (
    <div className={`kpi ${tone}`}>
      {Icon && <span className="kpi-icon"><Icon size={17} aria-hidden="true" /></span>}
      <span className="kpi-label">{label}</span>
      <strong>{value}</strong>
      {sub && <span className="kpi-sub">{sub}</span>}
    </div>
  );
}
