import { Component } from 'react';
import { RotateCw } from 'lucide-react';
import Logo from './Logo.jsx';
import { tr } from './i18n.jsx';

/** Évite l'écran blanc : une erreur d'affichage propose de recharger la page. */
export default class ErrorBoundary extends Component {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(error) { console.error(error); }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="fallback" role="alert">
        <div>
          <Logo size={44} />
          <h1>{tr('boundary.title')}</h1>
          <p className="muted">{tr('boundary.text')}</p>
          <button type="button" className="btn primary" onClick={() => window.location.reload()}><RotateCw size={17} />{tr('boundary.reload')}</button>
        </div>
      </div>
    );
  }
}
