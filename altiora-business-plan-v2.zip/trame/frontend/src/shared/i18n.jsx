import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import fr from './locales/fr.js';
import mg, { SERVER_ERRORS } from './locales/mg.js';

// Deux langues : français (par défaut) et malgache. Le choix est mémorisé sur l'appareil,
// appliqué à <html lang> et envoyé au backend (en-tête X-Lang) pour que l'IA rédige dans la même langue.
export const LANGS = [
  { code: 'fr', label: 'Français', short: 'FR' },
  { code: 'mg', label: 'Malagasy', short: 'MG' },
];
const KEY = 'altiora_lang';
const DICTS = { fr, mg };

function detect() {
  try {
    const saved = localStorage.getItem(KEY);
    if (saved && DICTS[saved]) return saved;
  } catch { /* stockage indisponible */ }
  return (navigator.language || 'fr').toLowerCase().startsWith('mg') ? 'mg' : 'fr';
}

let current = detect();
const listeners = new Set();

export const getLang = () => current;

export function setLang(code) {
  if (!DICTS[code] || code === current) return;
  current = code;
  try { localStorage.setItem(KEY, code); } catch { /* stockage indisponible */ }
  document.documentElement.lang = code;
  listeners.forEach((fn) => fn(code));
}

/** Traduit une clé. Une valeur peut être un texte, ou { one, other } pour le pluriel (paramètre count). */
export function tr(key, params = {}) {
  let v = DICTS[current][key] ?? fr[key];
  if (v === undefined) return key;
  if (typeof v === 'object') v = params.count === 0 || params.count === 1 ? v.one : v.other;
  return v.replace(/\{(\w+)\}/g, (_, k) => (params[k] ?? ''));
}

/** Message d'erreur du serveur (écrit en français) traduit dans la langue active quand un motif est connu. */
export function translateServerError(message) {
  if (!message || current === 'fr') return message;
  for (const [re, out] of SERVER_ERRORS) {
    const m = message.match(re);
    if (m) return out.replace(/\$(\d)/g, (_, i) => m[Number(i)] ?? '');
  }
  return message;
}

/* ---------- Dates et nombres ---------- */

const MONTHS_MG = ['Janoary', 'Febroary', 'Martsa', 'Aprily', 'Mey', 'Jona', 'Jolay', 'Aogositra', 'Septambra', 'Oktobra', 'Novambra', 'Desambra'];
const MONTHS_MG_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'Mey', 'Jon', 'Jol', 'Aog', 'Sep', 'Okt', 'Nov', 'Des'];

// 'AAAA-MM-JJ' est lu comme une date locale (pas de décalage de fuseau) ; un horodatage complet passe par Date.
function toDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  const s = String(value);
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  const d = m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : new Date(s);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function fmtDate(value, { long = false } = {}) {
  const d = toDate(value);
  if (!d) return '';
  if (current === 'mg') {
    return `${d.getDate()} ${(long ? MONTHS_MG : MONTHS_MG_SHORT)[d.getMonth()]} ${d.getFullYear()}`;
  }
  return d.toLocaleDateString('fr-FR', { day: 'numeric', month: long ? 'long' : 'short', year: 'numeric' });
}

export function fmtDateTime(value) {
  const d = toDate(value);
  if (!d) return '';
  const time = d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  return `${fmtDate(d)}, ${time}`;
}

// Le malgache écrit les nombres comme le français : espace pour les milliers, virgule pour les décimales.
export const fmtNum = (n, digits = 0) => Number(n ?? 0).toLocaleString('fr-FR', { maximumFractionDigits: digits, minimumFractionDigits: 0 });
export const fmtMoney = (n, cur) => `${fmtNum(Math.round(n))}\u00A0${cur}`;
export const fmtCompact = (n) => {
  const a = Math.abs(n);
  const s = n < 0 ? '-' : '';
  if (a >= 1e9) return `${s}${fmtNum(a / 1e9, 1)}\u00A0Md`;
  if (a >= 1e6) return `${s}${fmtNum(a / 1e6, 1)}\u00A0M`;
  if (a >= 1e3) return `${s}${Math.round(a / 1e3)}\u00A0k`;
  return `${s}${Math.round(a)}`;
};

/* ---------- Contexte React ---------- */

const LangContext = createContext(null);

export function LangProvider({ children }) {
  const [lang, setL] = useState(current);
  useEffect(() => {
    document.documentElement.lang = current;
    listeners.add(setL);
    return () => listeners.delete(setL);
  }, []);
  // Le changement de langue recrée la valeur du contexte : tous les composants qui l'utilisent se réaffichent.
  const value = useMemo(() => ({ lang, setLang, t: tr, fmtDate, fmtDateTime, fmtNum, fmtMoney, fmtCompact }), [lang]);
  return <LangContext.Provider value={value}>{children}</LangContext.Provider>;
}

export const useI18n = () => useContext(LangContext);
