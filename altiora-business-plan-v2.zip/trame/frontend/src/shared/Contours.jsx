// Courbes de niveau : le motif de la marque (l'altitude). Générées une fois, un seul trait est doré.
const PATHS = Array.from({ length: 13 }, (_, k) => {
  const r = 36 + k * 30;
  const pts = Array.from({ length: 121 }, (_, i) => {
    const a = (i / 120) * Math.PI * 2;
    const wob = 1 + 0.07 * Math.sin(3 * a + k * 0.55) + 0.045 * Math.sin(5 * a - k * 0.8) + 0.02 * Math.sin(9 * a + k);
    return `${(Math.cos(a) * r * wob * 1.25).toFixed(1)},${(Math.sin(a) * r * wob).toFixed(1)}`;
  });
  return `M${pts.join('L')}Z`;
});

export default function Contours({ className = 'contours' }) {
  return (
    <svg className={className} viewBox="-420 -300 840 600" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      {PATHS.map((d, i) => <path key={i} d={d} className={i === 6 ? 'gold' : ''} />)}
    </svg>
  );
}
