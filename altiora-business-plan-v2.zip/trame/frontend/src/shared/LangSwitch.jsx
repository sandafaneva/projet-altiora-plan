import { Globe } from 'lucide-react';
import { LANGS, setLang, useI18n } from './i18n.jsx';

/** Choix de la langue : Français ou Malagasy. Le libellé complet est en infobulle, le code court reste lisible. */
export default function LangSwitch({ className = '' }) {
  const { t, lang } = useI18n();
  return (
    <div className={`seg lang ${className}`} role="radiogroup" aria-label={t('lang.label')}>
      <Globe size={15} className="seg-lead" aria-hidden="true" />
      {LANGS.map(({ code, label, short }) => (
        <button key={code} type="button" role="radio" lang={code} aria-checked={lang === code} tabIndex={lang === code ? 0 : -1}
          title={label} aria-label={label} onClick={() => setLang(code)}
          onKeyDown={(e) => {
            if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
            e.preventDefault();
            const other = LANGS.find((l) => l.code !== code);
            setLang(other.code);
            e.currentTarget.parentElement.querySelector(`[lang="${other.code}"]`)?.focus();
          }}>
          {short}
        </button>
      ))}
    </div>
  );
}
