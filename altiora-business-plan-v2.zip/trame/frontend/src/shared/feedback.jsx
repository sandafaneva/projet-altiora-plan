import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';
import { CircleAlert, CircleCheck, Info, TriangleAlert, X } from 'lucide-react';
import { Button } from './ui.jsx';
import Modal from './Modal.jsx';
import { useI18n } from './i18n.jsx';

// Notifications brèves (résultat d'une action) et confirmations. Rouge + icône pour les erreurs, vert + icône pour les réussites.
const FeedbackContext = createContext(null);
export const useToast = () => useContext(FeedbackContext).toast;
export const useConfirm = () => useContext(FeedbackContext).confirm;

const ICONS = { success: CircleCheck, error: CircleAlert, info: Info };
const DURATION = { success: 4200, info: 4200, error: 8000 };

export function FeedbackProvider({ children }) {
  const { t } = useI18n();
  const [toasts, setToasts] = useState([]);
  const [dlg, setDlg] = useState(null);
  const seq = useRef(0);

  const dismiss = useCallback((id) => setToasts((list) => list.filter((x) => x.id !== id)), []);
  const push = useCallback((kind, message) => {
    const id = ++seq.current;
    setToasts((list) => [...list.slice(-2), { id, kind, message }]);
    setTimeout(() => dismiss(id), DURATION[kind]);
  }, [dismiss]);

  const toast = useMemo(() => ({ success: (m) => push('success', m), error: (m) => push('error', m), info: (m) => push('info', m) }), [push]);
  const confirm = useCallback((options) => new Promise((resolve) => setDlg({ ...options, resolve })), []);

  function close(result) {
    dlg.resolve(result);
    setDlg(null);
  }

  const danger = dlg?.tone === 'danger';

  return (
    <FeedbackContext.Provider value={{ toast, confirm }}>
      {children}

      <div className="toasts" role="region" aria-label={t('a11y.notifications')} aria-live="polite">
        {toasts.map(({ id, kind, message }) => {
          const Icon = ICONS[kind];
          return (
            <div key={id} className={`toast ${kind}`} style={{ '--dur': `${DURATION[kind]}ms` }}>
              <Icon size={20} aria-hidden="true" />
              <span>{message}</span>
              <button type="button" onClick={() => dismiss(id)} aria-label={t('common.close')}><X size={15} /></button>
              <i className="toast-timer" aria-hidden="true" />
            </div>
          );
        })}
      </div>

      <Modal open={Boolean(dlg)} onClose={() => close(false)} size="sm" title={dlg?.title} icon={danger ? TriangleAlert : Info} tone={danger ? 'danger' : 'brand'}
        footer={dlg && (
          <>
            <Button variant="secondary" onClick={() => close(false)} autoFocus={danger}>{dlg.cancelLabel || t('common.cancel')}</Button>
            <Button variant={danger ? 'danger' : 'primary'} onClick={() => close(true)} autoFocus={!danger}>{dlg.confirmLabel || t('common.confirm')}</Button>
          </>
        )}>
        <p className="modal-text">{dlg?.message}</p>
      </Modal>
    </FeedbackContext.Provider>
  );
}
