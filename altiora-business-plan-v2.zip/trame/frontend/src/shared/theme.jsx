import { createContext, useCallback, useContext, useEffect, useState } from 'react';

// Préférence : 'light', 'dark' ou 'system' (suit le réglage de l'appareil). Mémorisée sur cet appareil.
const KEY = 'altiora_theme';
const ThemeContext = createContext(null);
export const useTheme = () => useContext(ThemeContext);

const prefersDark = () => window.matchMedia('(prefers-color-scheme: dark)').matches;

function apply(pref) {
  const dark = pref === 'dark' || (pref === 'system' && prefersDark());
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#0a1122' : '#f3f5fa');
  return dark ? 'dark' : 'light';
}

export function ThemeProvider({ children }) {
  const [pref, setPref] = useState(() => {
    try { return localStorage.getItem(KEY) || 'system'; } catch { return 'system'; }
  });
  const [resolved, setResolved] = useState(() => document.documentElement.dataset.theme || 'light');

  useEffect(() => {
    setResolved(apply(pref));
    if (pref !== 'system') return undefined;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = () => setResolved(apply('system'));
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, [pref]);

  const set = useCallback((value) => {
    try { localStorage.setItem(KEY, value); } catch { /* stockage indisponible */ }
    setPref(value);
  }, []);

  return <ThemeContext.Provider value={{ pref, resolved, set }}>{children}</ThemeContext.Provider>;
}
