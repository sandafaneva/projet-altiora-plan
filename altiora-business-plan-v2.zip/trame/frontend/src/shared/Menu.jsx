import { useEffect, useRef, useState } from 'react';

/** Menu déroulant accessible : Échap et clic à l'extérieur le ferment, flèches haut/bas pour naviguer. */
export default function Menu({ label, trigger, items, header, align = 'right', className = '', triggerClass = '' }) {
  const [open, setOpen] = useState(false);
  const root = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => { if (!root.current?.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === 'Escape') { setOpen(false); root.current?.querySelector('[aria-haspopup]')?.focus(); } };
    document.addEventListener('pointerdown', onDown);
    document.addEventListener('keydown', onKey);
    root.current?.querySelector('[role="menuitem"]')?.focus();
    return () => { document.removeEventListener('pointerdown', onDown); document.removeEventListener('keydown', onKey); };
  }, [open]);

  function arrows(e) {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
    e.preventDefault();
    const els = [...root.current.querySelectorAll('[role="menuitem"]:not(:disabled)')];
    const i = els.indexOf(document.activeElement);
    els[(i + (e.key === 'ArrowDown' ? 1 : els.length - 1)) % els.length]?.focus();
  }

  return (
    <div className={`menu ${className}`} ref={root}>
      <button type="button" className={`menu-trigger ${triggerClass}`} aria-haspopup="menu" aria-expanded={open} aria-label={label} title={label} onClick={() => setOpen((o) => !o)}>
        {trigger}
      </button>
      {open && (
        <div className={`menu-pop ${align}`} role="menu" aria-label={label} onKeyDown={arrows}>
          {header && <div className="menu-head">{header}</div>}
          {items.map(({ key, icon: Icon, label: text, onClick, tone, disabled }) => (
            <button key={key} type="button" role="menuitem" className={`menu-item ${tone || ''}`} disabled={disabled}
              onClick={() => { setOpen(false); onClick(); }}>
              {Icon && <Icon size={16} aria-hidden="true" />}{text}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
