import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useMatch } from 'react-router-dom';
import { ChevronDown, CircleAlert, FolderKanban, LogOut, Menu as MenuIcon, Sparkles, X } from 'lucide-react';
import { api } from './api.js';
import { useAuth } from './AuthContext.jsx';
import { useI18n } from './i18n.jsx';
import { refreshPlans, usePlans } from './plansStore.js';
import Logo from './Logo.jsx';
import Contours from './Contours.jsx';
import ThemeToggle from './ThemeToggle.jsx';
import LangSwitch from './LangSwitch.jsx';
import Menu from './Menu.jsx';

let aiCache = null; // le statut IA est vérifié au plus une fois par minute

function AiStatus() {
  const { t } = useI18n();
  const [ai, setAi] = useState(aiCache?.value ?? null);
  useEffect(() => {
    if (aiCache && Date.now() - aiCache.at < 60_000) return;
    api.get('/ai/status')
      .then((v) => { aiCache = { value: v, at: Date.now() }; setAi(v); })
      .catch(() => setAi({ error: true }));
  }, []);
  if (!ai) return null;
  const off = Boolean(ai.error);
  const title = off ? `${t('ai.off')}${typeof ai.error === 'string' ? ` : ${ai.error}` : ''}` : `${t('ai.on')} : ${ai.model?.name ?? ''}`;
  return (
    <span className={`ai-pill ${off ? 'off' : 'on'}`} title={title} role="status">
      {off ? <CircleAlert size={15} aria-hidden="true" /> : <Sparkles size={15} aria-hidden="true" />}
      <span className="ai-pill-text">{off ? t('ai.off') : t('ai.on')}</span>
      <i aria-hidden="true" />
    </span>
  );
}

function UserMenu() {
  const { t } = useI18n();
  const { user, logout } = useAuth();
  const initials = user.name.split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  return (
    <Menu label={t('user.menu')} className="user-menu" trigger={
      <>
        <span className="avatar" aria-hidden="true">{initials}</span>
        <span className="user-name">{user.name}</span>
        <ChevronDown size={15} aria-hidden="true" />
      </>
    } header={<><strong>{user.name}</strong><span>{user.email}</span></>}
      items={[{ key: 'out', icon: LogOut, label: t('user.logout'), onClick: logout, tone: 'danger' }]} />
  );
}

const DOT = { drafting: 'st-draft', generated: 'st-gen', executing: 'st-exec' };

function Sidebar({ open, onClose }) {
  const { t } = useI18n();
  const { plans } = usePlans();
  const current = useMatch('/plans/:id')?.params.id;
  useEffect(() => { if (plans === null) refreshPlans(); }, [plans]);
  const recent = (plans || []).slice(0, 6);

  return (
    <aside className={`side ${open ? 'open' : ''}`} aria-label={t('nav.label')}>
      <Contours className="side-contours" />
      <div className="side-top">
        <Link to="/" className="side-brand"><Logo />ALTIORA</Link>
        <button type="button" className="icon-btn light side-close" onClick={onClose} aria-label={t('common.close')}><X size={18} /></button>
      </div>
      <nav className="side-nav" aria-label={t('nav.label')}>
        <NavLink to="/" end><FolderKanban size={18} aria-hidden="true" />{t('nav.projects')}</NavLink>
      </nav>
      {recent.length > 0 && (
        <nav className="side-recent" aria-label={t('nav.recent')}>
          <h2>{t('nav.recent')}</h2>
          <ul>
            {recent.map((p) => (
              <li key={p.id}>
                <Link to={`/plans/${p.id}`} aria-current={String(p.id) === current ? 'page' : undefined} title={p.title}>
                  <i className={`sdot ${DOT[p.status]}`} aria-hidden="true" />
                  <span>{p.title}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </aside>
  );
}

/** Cadre de l'application : barre latérale (navigation), barre supérieure (langue, luminosité, IA, compte) et zone de travail. */
export default function Layout() {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => { setOpen(false); }, [pathname]);

  return (
    <div className="app">
      <a className="skip" href="#main">{t('a11y.skip')}</a>
      <Sidebar open={open} onClose={() => setOpen(false)} />
      {open && <div className="scrim" onClick={() => setOpen(false)} aria-hidden="true" />}
      <div className="col">
        <header className="topbar">
          <button type="button" className="icon-btn menu-btn" onClick={() => setOpen(true)} aria-label={t('nav.open')}><MenuIcon size={20} /></button>
          <Link to="/" className="topbar-brand" aria-label="ALTIORA"><Logo size={28} /></Link>
          <div className="topbar-right">
            <AiStatus />
            <LangSwitch />
            <ThemeToggle />
            <UserMenu />
          </div>
        </header>
        <main className="content" id="main" tabIndex={-1}><Outlet /></main>
      </div>
    </div>
  );
}
