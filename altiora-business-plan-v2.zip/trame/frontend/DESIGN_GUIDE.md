# ALTIORA : guide de design (v2)

ALTIORA évoque l'altitude : courbes de niveau sur la connexion et la barre latérale, repère doré sur la page active, anneau doré de progression.

## Couleurs et sens
| Nom | Valeur | Usage |
|---|---|---|
| Nuit | `#0E1A3A` | Barre latérale, hero de connexion, couverture du PDF |
| Cobalt | `#315EFB` | Action principale, étape active, liens |
| Or | `#F5B83D` | Repère de marque, anneau de progression |
| Vert | `#0A7D55` | Réussi, validé, dans les temps |
| Ambre | `#9A5B00` | Attention, à consolider |
| Rouge | `#D63B3B` | Erreur, retard, incohérence |
| Bleu information | `#2447D6` | Information, conseils |

**Règle** : une couleur n'est jamais seule. Chaque état a une icône et un texte (rouge = `CircleAlert`, ambre = `TriangleAlert`, vert = `CircleCheck`, bleu = `Info`). Composants : `Alert`, `Chip`, `Kpi`, toasts (`shared/ui.jsx`, `shared/feedback.jsx`).

## Luminosité et langue (toujours visibles)
- Barre supérieure et page de connexion : `ThemeToggle` (clair, automatique, sombre) et `LangSwitch` (FR, MG).
- Thème : variables en tête de `styles.css` (`html[data-theme='dark']`), mémorisé (`altiora_theme`), appliqué avant le premier affichage.
- Langue : `shared/i18n.jsx`, dictionnaires `shared/locales/fr.js` (référence) et `mg.js`. Mémorisée (`altiora_lang`), écrite dans `<html lang>`, envoyée au backend (en-tête `X-Lang`).
- Ajouter un texte : une clé dans `fr.js` **et** `mg.js`, puis `t('cle')`. Pluriels : `{ one, other }` avec le paramètre `count`.

## Principes d'IHM appliqués
1. **Visibilité de l'état** : parcours en 4 étapes (terminée, à revoir, verrouillée), anneau de progression, statut IA, barres de chargement, toasts.
2. **Adéquation au monde réel** : vocabulaire métier, dates et nombres localisés.
3. **Contrôle de l'utilisateur** : annuler, Échap, historique et restauration des versions, Ctrl+Entrée pour générer, Ctrl+S pour enregistrer.
4. **Cohérence** : mêmes composants partout (`Button`, `Field`, `Alert`, `Modal`, `Segmented`, `Menu`).
5. **Prévention des erreurs** : confirmation avant suppression ou perte de modifications, validation dans la langue choisie, bouton désactivé avec explication.
6. **Reconnaissance plutôt que rappel** : fil d'Ariane, projets récents, libellés visibles au-dessus des champs et en-têtes de colonnes.
7. **Efficacité** : un clic pour terminer une tâche, filtres, recherche, raccourcis clavier.
8. **Sobriété** : les aides passent en infobulle, les détails en `<details>` ou en fenêtre, seul l'utile est affiché.
9. **Aide à la récupération** : message d'erreur en rouge, icône, cause claire, écran de secours.

## Typographie
Bricolage Grotesque (titres 600 à 800), Public Sans (texte, chiffres tabulaires). Polices installées avec l'application (`@fontsource`).

## Accessibilité et adaptation
Focus visible, lien d'évitement, rôles ARIA (`tablist`, `radiogroup`, `dialog`, `status`, `alert`), contrastes vérifiés dans les deux thèmes, `prefers-reduced-motion`. Barre latérale en tiroir sous 1024 px, aucune barre de défilement horizontale à 390 px.
