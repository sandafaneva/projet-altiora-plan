import app from './app.js';
import { env } from './config/env.js';
import { pool } from './db/pool.js';

try {
  await pool.query('SELECT 1');
  console.log('[db] MySQL connecté');
} catch (err) {
  console.error('[db] Connexion impossible :', err.message);
  console.error('    → Vérifiez DB_* dans .env et lancez : npm run db:init');
  process.exit(1);
}
import('./services/groq.js').then(async ({ checkGroq }) => {
  const r = await checkGroq();
  if (r.error) console.warn(`[groq] ⚠ ${r.error}`);
  else console.log(`[groq] clé valide, modèle « ${r.model.name} » disponible`);
});

app.listen(env.port, () => console.log(`[api] http://localhost:${env.port}`));
