import { AsyncLocalStorage } from 'node:async_hooks';

// Langue de la requête en cours (en-tête X-Lang envoyé par le frontend) : 'fr' (défaut) ou 'mg' (malgache).
// Elle sert à faire rédiger l'IA dans la langue choisie et à libeller les exports Word/PDF et les tableaux chiffrés.
export const SUPPORTED_LANGS = ['fr', 'mg'];
const store = new AsyncLocalStorage();

export const getLang = () => store.getStore()?.lang ?? 'fr';

export function langMiddleware(req, res, next) {
  const raw = String(req.headers['x-lang'] || req.headers['accept-language'] || '').toLowerCase().slice(0, 2);
  store.run({ lang: SUPPORTED_LANGS.includes(raw) ? raw : 'fr' }, next);
}

/** Exécute une fonction dans une langue donnée (tests, tâches hors requête). */
export const withLang = (lang, fn) => store.run({ lang }, fn);
