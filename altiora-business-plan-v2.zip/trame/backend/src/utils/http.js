import { ZodError } from 'zod';

export class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

export const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export function notFound(req, res) {
  res.status(404).json({ error: 'Route introuvable' });
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err instanceof ZodError) {
    const details = err.issues.map((i) => ({ champ: i.path.join('.'), message: i.message }));
    return res.status(400).json({
      error: `Champs invalides : ${[...new Set(details.map((d) => d.champ))].join(', ')}`,
      details,
    });
  }
  if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON invalide' });
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({
    error: status >= 500 && !(err instanceof HttpError) ? 'Erreur interne du serveur' : err.message,
    details: err.details,
  });
}
