import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { requireAuth } from '../middleware/auth.js';
import { asyncHandler, HttpError } from '../utils/http.js';
import * as bp from '../services/orchestrator.js';
import { renderDocx, renderPdf, exportFilename } from '../services/export/index.js';

const router = Router();
router.use(requireAuth);

// Limite les appels coûteux à l'IA, par utilisateur
const aiLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 40,
  keyGenerator: (req) => String(req.user.id),
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Trop de requêtes IA. Patientez quelques minutes.' },
});

// Les exports demandent du calcul (pas d'IA) : limite plus souple
const exportLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 30,
  keyGenerator: (req) => String(req.user.id),
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Trop d\'exports. Patientez quelques minutes.' },
});

const idOf = (v) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n <= 0) throw new HttpError(400, 'Identifiant invalide');
  return n;
};
const keyOf = (v) => {
  if (!/^[a-z_]{2,60}$/.test(v)) throw new HttpError(400, 'Section invalide');
  return v;
};

/* R3/R4 : seulement 3 champs à saisir */
const createSchema = z.object({
  idea: z.string().trim().min(10).max(2000),
  sector: z.string().trim().min(2).max(160),
  target_clients: z.string().trim().min(2).max(255),
});

const generateSchema = z.object({
  prompt: z.string().trim().max(4000).optional(),
  answers: z
    .array(z.object({ question: z.string().trim().min(1).max(400), answer: z.string().trim().max(1500) }))
    .max(6)
    .optional(),
});

const contentSchema = z.object({ content: z.string().trim().min(20).max(20000) });
const validateSchema = z.object({ force: z.boolean().optional() });
const updatePlanSchema = z
  .object({
    idea: z.string().trim().min(10).max(2000).optional(),
    sector: z.string().trim().min(2).max(160).optional(),
    target_clients: z.string().trim().min(2).max(255).optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Aucune modification');

const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Format AAAA-MM-JJ');
const startSchema = z.object({ start_date: dateStr.optional() });

const taskFields = {
  phase: z.string().trim().min(1).max(150),
  title: z.string().trim().min(2).max(250),
  description: z.string().trim().max(1000).nullable().optional(),
  kpi: z.string().trim().max(250).nullable().optional(),
  target_value: z.string().trim().max(150).nullable().optional(),
  due_date: dateStr.nullable().optional(),
  due_week: z.number().int().min(1).max(52).nullable().optional(),
};
const createTaskSchema = z.object(taskFields);
const taskSchema = z
  .object({
    ...Object.fromEntries(Object.entries(taskFields).map(([k, v]) => [k, v.optional()])),
    status: z.enum(['todo', 'in_progress', 'done', 'blocked']).optional(),
    progress: z.number().int().min(0).max(100).optional(),
    note: z.string().trim().max(1000).nullable().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Aucune modification');

/* ---------- Plans ---------- */
router.get('/', asyncHandler(async (req, res) => res.json({ plans: await bp.listPlans(req.user.id) })));

router.post(
  '/',
  aiLimiter,
  asyncHandler(async (req, res) => {
    const input = createSchema.parse(req.body);
    const planId = await bp.createPlan(req.user.id, input);
    res.status(201).json(await bp.getPlanDetail(req.user.id, planId));
  }),
);

router.get('/:id', asyncHandler(async (req, res) => res.json(await bp.getPlanDetail(req.user.id, idOf(req.params.id)))));

// R16 : le projet reste modifiable ; la planification peut être refaite sans toucher aux sections validées
router.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    const input = updatePlanSchema.parse(req.body);
    res.json(await bp.updatePlanInputs(req.user.id, idOf(req.params.id), input));
  }),
);

router.post(
  '/:id/replan',
  aiLimiter,
  asyncHandler(async (req, res) => res.json(await bp.replanPlan(req.user.id, idOf(req.params.id)))),
);

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    await bp.deletePlan(req.user.id, idOf(req.params.id));
    res.status(204).end();
  }),
);

/* ---------- Modèle financier (calculs en code) ---------- */
router.get('/:id/financials', asyncHandler(async (req, res) => res.json(await bp.getFinancials(req.user.id, idOf(req.params.id)))));

router.put(
  '/:id/financials',
  asyncHandler(async (req, res) => res.json(await bp.saveFinancials(req.user.id, idOf(req.params.id), req.body))),
);

// Aperçu du calcul pendant la saisie : rien n'est enregistré
router.post(
  '/:id/financials/preview',
  asyncHandler(async (req, res) => {
    idOf(req.params.id);
    res.json(bp.previewFinancials(req.body));
  }),
);

// L'IA propose seulement les valeurs déjà écrites dans le plan
router.post(
  '/:id/financials/suggest',
  aiLimiter,
  asyncHandler(async (req, res) => res.json(await bp.suggestFinancials(req.user.id, idOf(req.params.id)))),
);

/* ---------- Boucle par section ---------- */
router.post(
  '/:id/sections/:key/generate',
  aiLimiter,
  asyncHandler(async (req, res) => {
    const input = generateSchema.parse(req.body);
    res.json(await bp.generateSection(req.user.id, idOf(req.params.id), keyOf(req.params.key), input));
  }),
);

router.put(
  '/:id/sections/:key/content',
  aiLimiter,
  asyncHandler(async (req, res) => {
    const { content } = contentSchema.parse(req.body);
    res.json(await bp.saveManualContent(req.user.id, idOf(req.params.id), keyOf(req.params.key), content));
  }),
);

router.get(
  '/:id/sections/:key/iterations',
  asyncHandler(async (req, res) => {
    res.json({ iterations: await bp.listIterations(req.user.id, idOf(req.params.id), keyOf(req.params.key)) });
  }),
);

router.post(
  '/:id/sections/:key/restore/:iterationId',
  asyncHandler(async (req, res) => {
    res.json(await bp.restoreIteration(req.user.id, idOf(req.params.id), keyOf(req.params.key), idOf(req.params.iterationId)));
  }),
);

router.post(
  '/:id/sections/:key/validate',
  asyncHandler(async (req, res) => {
    const { force } = validateSchema.parse(req.body ?? {});
    res.json(await bp.validateSection(req.user.id, idOf(req.params.id), keyOf(req.params.key), Boolean(force)));
  }),
);

router.post(
  '/:id/sections/:key/unvalidate',
  asyncHandler(async (req, res) => {
    res.json(await bp.unvalidateSection(req.user.id, idOf(req.params.id), keyOf(req.params.key)));
  }),
);

/* ---------- Génération finale ---------- */
router.post(
  '/:id/generate-final',
  aiLimiter,
  asyncHandler(async (req, res) => res.json(await bp.finalizePlan(req.user.id, idOf(req.params.id)))),
);

/* ---------- Export Word et PDF ---------- */
const MIME = {
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  pdf: 'application/pdf',
};
router.get(
  '/:id/export/:format',
  exportLimiter,
  asyncHandler(async (req, res) => {
    const { format } = req.params;
    if (!MIME[format]) throw new HttpError(400, 'Format inconnu (docx ou pdf).');
    const data = await bp.getExportData(req.user.id, idOf(req.params.id));
    const file = format === 'docx' ? await renderDocx(data) : await renderPdf(data);
    res.set({
      'Content-Type': MIME[format],
      'Content-Disposition': `attachment; filename="${exportFilename(data.plan, format)}"`,
      'Content-Length': file.length,
      'Cache-Control': 'no-store',
    });
    res.send(file);
  }),
);

/* ---------- Exécution et suivi ---------- */
router.post(
  '/:id/execution/start',
  aiLimiter,
  asyncHandler(async (req, res) => {
    const { start_date } = startSchema.parse(req.body ?? {});
    res.status(201).json(await bp.startExecution(req.user.id, idOf(req.params.id), start_date));
  }),
);

router.get('/:id/tracking', asyncHandler(async (req, res) => res.json(await bp.getTracking(req.user.id, idOf(req.params.id)))));

router.post(
  '/:id/tasks',
  asyncHandler(async (req, res) => {
    const input = createTaskSchema.parse(req.body);
    res.status(201).json({ task: await bp.createTask(req.user.id, idOf(req.params.id), input) });
  }),
);

router.delete(
  '/:id/tasks/:taskId',
  asyncHandler(async (req, res) => {
    await bp.deleteTask(req.user.id, idOf(req.params.id), idOf(req.params.taskId));
    res.status(204).end();
  }),
);

router.patch(
  '/:id/tasks/:taskId',
  asyncHandler(async (req, res) => {
    const patch = taskSchema.parse(req.body);
    res.json({ task: await bp.updateTask(req.user.id, idOf(req.params.id), idOf(req.params.taskId), patch) });
  }),
);

router.post(
  '/:id/tracking/review',
  aiLimiter,
  asyncHandler(async (req, res) => res.json({ review: await bp.reviewTracking(req.user.id, idOf(req.params.id)) })),
);

export default router;
