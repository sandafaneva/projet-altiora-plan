import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { env } from '../config/env.js';
import { query } from '../db/pool.js';
import { requireAuth } from '../middleware/auth.js';
import { asyncHandler, HttpError } from '../utils/http.js';

const router = Router();

const registerSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().toLowerCase().email().max(190),
  password: z.string().min(8).max(100),
});
const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(1).max(100),
});

const sign = (id) => jwt.sign({ sub: String(id) }, env.jwtSecret, { expiresIn: env.jwtExpiresIn });

router.post(
  '/register',
  asyncHandler(async (req, res) => {
    const { name, email, password } = registerSchema.parse(req.body);
    const exists = await query('SELECT id FROM users WHERE email = ?', [email]);
    if (exists.length) throw new HttpError(409, 'Cet e-mail est déjà utilisé');
    const hash = await bcrypt.hash(password, 10);
    const result = await query('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)', [name, email, hash]);
    res.status(201).json({ token: sign(result.insertId), user: { id: result.insertId, name, email } });
  }),
);

router.post(
  '/login',
  asyncHandler(async (req, res) => {
    const { email, password } = loginSchema.parse(req.body);
    const rows = await query('SELECT id, name, email, password_hash FROM users WHERE email = ?', [email]);
    const user = rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      throw new HttpError(401, 'E-mail ou mot de passe incorrect');
    }
    res.json({ token: sign(user.id), user: { id: user.id, name: user.name, email: user.email } });
  }),
);

router.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const rows = await query('SELECT id, name, email FROM users WHERE id = ?', [req.user.id]);
    if (!rows.length) throw new HttpError(401, 'Compte introuvable');
    res.json({ user: rows[0] });
  }),
);

export default router;
