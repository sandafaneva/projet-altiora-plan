import 'dotenv/config';

function need(name) {
  const value = process.env[name];
  if (!value) {
    console.error(`[config] Variable d'environnement manquante : ${name} (voir .env.example)`);
    process.exit(1);
  }
  return value;
}

export const env = {
  port: Number(process.env.PORT || 4000),
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'trame',
  },
  jwtSecret: need('JWT_SECRET'),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  // La clé Groq n'est lue que côté serveur (R5)
  groqApiKey: process.env.GROQ_API_KEY || '',
  groqBaseUrl: (process.env.GROQ_BASE_URL || 'https://api.groq.com/openai/v1').replace(/\/+$/, ''),
  groqModel: process.env.GROQ_MODEL || 'openai/gpt-oss-120b',
  // Modèle de secours si le principal est indisponible ou si son quota est épuisé (vide = désactivé)
  groqFallbackModel: process.env.GROQ_FALLBACK_MODEL ?? 'openai/gpt-oss-20b',
  // Effort de raisonnement des modèles gpt-oss (low, medium ou high). Plus bas = plus rapide et moins de tokens. Vide = valeur par défaut de Groq.
  groqReasoningEffort: process.env.GROQ_REASONING_EFFORT ?? 'low',
  validationThreshold: Number(process.env.VALIDATION_THRESHOLD || 70),
};
