import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { HttpError } from '../utils/http.js';

/**
 * Vérifie le JWT et place l'identifiant dans req.user.id.
 * R1 : lors de l'intégration à l'application existante, remplacer ce middleware
 * par celui de l'application (il suffit que req.user.id soit renseigné).
 */
export function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return next(new HttpError(401, 'Authentification requise'));
  try {
    const payload = jwt.verify(token, env.jwtSecret);
    req.user = { id: Number(payload.sub) };
    return next();
  } catch {
    return next(new HttpError(401, 'Session expirée, reconnectez-vous'));
  }
}
