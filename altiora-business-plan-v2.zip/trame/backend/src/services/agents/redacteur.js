import { chat } from '../groq.js';
import { stripLeadingTitle } from '../labels.js';
import { BASE_RULES, wrapData, clip, planContext, sectionsSummary } from './common.js';

const SYSTEM = `${BASE_RULES}
Tu es l'agent rédacteur d'un business plan. Tu rédiges UNE section à la fois, à partir d'une instruction détaillée.
Format :
- Markdown. Ne répète jamais le titre de la section et n'utilise pas de titre de niveau 1 ou 2 (le titre est ajouté par l'application) : utilise des sous-titres ### et des listes ou tableaux quand ils clarifient.
- 350 à 700 mots, dense, sans remplissage ni formule creuse.
- Écris du point de vue du porteur de projet (« notre offre », « nos clients »).
- Pas de préambule ni de conclusion adressée à l'utilisateur : uniquement le contenu de la section.
Rigueur : chaque chiffre est soit fourni par l'utilisateur, soit marqué "[Hypothèse à valider]". Les informations manquantes sont signalées "[À compléter : ...]" plutôt qu'inventées.
Modèle financier : si un bloc modele_financier_calcule est fourni, ses chiffres ont été calculés par un moteur de calcul et font foi. Utilise-les tels quels (ne les recalcule pas, ne les arrondis pas différemment, n'en invente aucun autre) et explique-les : hypothèses, évolution, point mort, besoin de financement, points d'attention.`;

/** Agent rédacteur : rédige une section à partir du méta-prompt. Distinct de l'analyste pour éviter l'auto-complaisance. */
export async function writeSection({ plan, section, others, metaPrompt, previousContent, financials }) {
  const parts = [
    planContext(plan),
    `Section : ${section.title}`,
    `Instruction à suivre :\n${metaPrompt}`,
  ];
  if (previousContent) parts.push(wrapData('version_precedente_a_ameliorer', clip(previousContent, 2500)));
  const summary = sectionsSummary(others, { max: 500 });
  if (summary) parts.push(summary);
  if (financials) parts.push(wrapData('modele_financier_calcule', financials));

  const { content, tokens } = await chat({ system: SYSTEM, user: parts.join('\n\n'), temperature: 0.5, maxTokens: 1800 });
  // Retire un éventuel titre de niveau 1-2 ajouté par le modèle
  const cleaned = stripLeadingTitle(content.trim().replace(/^\s*#{1,2}\s[^\n]*\n+/, '').trim(), section).trim();
  if (!cleaned) throw new Error("Le rédacteur n'a rien produit");
  return { content: cleaned, tokens };
}
