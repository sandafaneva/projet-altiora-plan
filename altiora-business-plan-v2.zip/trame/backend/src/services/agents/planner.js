import { chatJson } from '../groq.js';
import { BASE_RULES, wrapData, clip, asStringArray } from './common.js';

/** Structure de référence. L'agent de planification l'adapte au projet (objectifs, points clés, prompt suggéré). */
export const DEFAULT_SECTIONS = [
  {
    key: 'probleme_solution',
    title: 'Problème et proposition de valeur',
    objective: "Décrire le problème vécu par le client et la valeur concrète apportée par la solution.",
    key_points: ['Problème et son coût pour le client', 'Solution proposée', 'Bénéfices mesurables (ROI, temps gagné, coûts réduits)', 'Preuves ou premiers retours'],
    suggested_prompt: "Décris le problème précis que rencontrent mes clients, ce qu'il leur coûte, et comment ma solution le résout avec un bénéfice mesurable.",
  },
  {
    key: 'marche_cibles',
    title: 'Marché et clients cibles',
    objective: 'Définir les segments de clients visés, les personas et la taille du marché.',
    key_points: ['Segments (taille, secteur, zone)', 'Décideur, utilisateur, prescripteur', 'Taille du marché (TAM, SAM, SOM) avec hypothèses', 'Tendances'],
    suggested_prompt: 'Présente mon marché : segments d\'entreprises visés, personas de décision (décideur, utilisateur, prescripteur) et estimation de la taille du marché avec hypothèses explicites.',
  },
  {
    key: 'offre_pricing',
    title: 'Offre et modèle économique',
    objective: "Préciser l'offre, le modèle de revenus et la logique de prix.",
    key_points: ['Offre et packaging', 'Modèle de revenus (abonnement, licence, projet)', 'Prix justifié', 'Unit economics (CAC, LTV, marge)'],
    suggested_prompt: "Décris mon offre, mon modèle de revenus et ma politique de prix, en justifiant le prix et en donnant la logique du CAC, de la LTV et de la marge.",
  },
  {
    key: 'concurrence',
    title: 'Concurrence et différenciation',
    objective: 'Cartographier les concurrents et les alternatives, et démontrer une différenciation défendable.',
    key_points: ['Concurrents directs et indirects', 'Alternatives internes du client', 'Comparaison', 'Avantage défendable'],
    suggested_prompt: 'Analyse ma concurrence (directe, indirecte et solutions internes des clients) et explique ce qui me différencie de façon durable.',
  },
  {
    key: 'strategie_commerciale',
    title: 'Stratégie commerciale et cycle de vente',
    objective: "Expliquer comment les entreprises cibles seront atteintes puis converties en clients.",
    key_points: ['Canaux d\'acquisition', 'Étapes du cycle de vente et durée', 'Objectifs de conversion', 'Partenariats et ressources commerciales'],
    suggested_prompt: "Détaille ma stratégie commerciale : canaux d'acquisition, étapes et durée du cycle de vente, objectifs de conversion et ressources nécessaires.",
  },
  {
    key: 'plan_operationnel',
    title: 'Plan opérationnel et équipe',
    objective: "Décrire l'organisation, l'équipe et les moyens pour livrer et supporter les clients.",
    key_points: ['Équipe et rôles', 'Processus de livraison et support', 'Outils et fournisseurs', 'Jalons de mise en œuvre'],
    suggested_prompt: "Présente mon plan opérationnel : équipe, organisation de la livraison et du support client, outils, fournisseurs et jalons principaux.",
  },
  {
    key: 'plan_financier',
    title: 'Plan financier et hypothèses',
    objective: "Présenter les hypothèses, les revenus, les coûts, le point mort et le besoin de financement.",
    key_points: ['Hypothèses explicites', 'Revenus et coûts', 'Seuil de rentabilité', 'Trésorerie et besoin de financement'],
    suggested_prompt: "Construis mon plan financier sur la base de mes hypothèses : revenus, coûts, seuil de rentabilité, trésorerie et besoin de financement, en signalant les hypothèses à valider.",
  },
  {
    key: 'risques',
    title: 'Risques et plan de mitigation',
    objective: "Identifier les principaux risques et les actions pour les réduire.",
    key_points: ['Risques marché, commerciaux, techniques, financiers, juridiques', 'Probabilité et impact', 'Actions de mitigation'],
    suggested_prompt: "Liste les principaux risques de mon projet (marché, commercial, technique, financier, juridique) avec leur probabilité, leur impact et les actions de mitigation.",
  },
  {
    key: 'resume_executif',
    title: 'Résumé exécutif',
    objective: "Synthétiser le projet en une page cohérente avec toutes les autres sections (rédigé en dernier, placé en tête du document).",
    key_points: ['Problème et solution', 'Cible', 'Modèle économique', 'Objectifs chiffrés et besoin de financement'],
    suggested_prompt: "Rédige le résumé exécutif de mon business plan en reprenant le problème, la solution, la cible, le modèle économique et les objectifs, de façon cohérente avec les autres sections.",
  },
];

const SYSTEM = `${BASE_RULES}
Tu es l'agent de planification. À partir de quelques informations, tu prépares la structure détaillée du business plan.
Réponds uniquement avec un objet JSON de la forme :
{"title":"titre court du projet (80 caractères max)","summary":"résumé du projet en 2 phrases","sections":[{"key":"...","objective":"objectif précis de cette section pour CE projet","key_points":["3 à 6 points à traiter"],"suggested_prompt":"instruction que l'utilisateur pourrait donner à l'IA pour rédiger cette section, à la première personne, adaptée à CE projet"}]}
Utilise exactement les clés suivantes, une entrée par clé :
${DEFAULT_SECTIONS.map((s) => `- ${s.key} : ${s.title}`).join('\n')}`;

function normalize(data, plan, tokens, fallback = false) {
  const byKey = new Map((Array.isArray(data?.sections) ? data.sections : []).map((s) => [s?.key, s]));
  const sections = DEFAULT_SECTIONS.map((def, i) => {
    const ai = byKey.get(def.key) || {};
    const points = asStringArray(ai.key_points, 6);
    return {
      key: def.key,
      title: def.title,
      objective: typeof ai.objective === 'string' && ai.objective.trim() ? clip(ai.objective, 500) : def.objective,
      key_points: points.length ? points : def.key_points,
      suggested_prompt: typeof ai.suggested_prompt === 'string' && ai.suggested_prompt.trim() ? clip(ai.suggested_prompt, 800) : def.suggested_prompt,
      position: i + 1,
    };
  });
  const title = typeof data?.title === 'string' && data.title.trim() ? clip(data.title, 120) : clip(plan.idea.split(/[.\n]/)[0], 80);
  return {
    title,
    summary: typeof data?.summary === 'string' ? clip(data.summary, 600) : '',
    sections,
    tokens,
    fallback,
  };
}

/** Agent de planification (R9) : prépare le détail du plan et le transmet aux agents suivants (R4). */
export async function planOutline(plan) {
  const user = [
    wrapData('idee_du_projet', plan.idea),
    wrapData('secteur', plan.sector),
    wrapData('clients_cibles', plan.target_clients),
  ].join('\n');
  try {
    const { data, tokens } = await chatJson({ system: SYSTEM, user, temperature: 0.3, maxTokens: 3000 });
    return normalize(data, plan, tokens);
  } catch (err) {
    console.warn('[planner] repli sur la structure par défaut :', err.message);
    return normalize(null, plan, 0, true);
  }
}
