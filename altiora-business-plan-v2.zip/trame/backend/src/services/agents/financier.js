import { z } from 'zod';
import { chatJson } from '../groq.js';
import { BASE_RULES, wrapData, clip, planContext } from './common.js';

const SYSTEM = `${BASE_RULES}
Tu es l'agent d'extraction financière. Tu lis les sections d'un business plan et tu extrais UNIQUEMENT les valeurs numériques qui y sont écrites explicitement.
Règles strictes :
- Tu n'estimes rien, tu ne déduis rien, tu ne calcules rien : si une valeur n'est pas écrite noir sur blanc, tu mets null.
- Les montants sont des montants mensuels par client pour "price_per_customer_month" ; si le texte donne un prix annuel, tu ne le convertis pas : mets null et signale-le dans "missing".
- Les pourcentages sont exprimés en nombre (12 pour 12 %).
Réponds uniquement avec un objet JSON :
{"assumptions":{"currency":null,"price_per_customer_month":null,"setup_fee":null,"initial_customers":null,"new_customers_per_month":null,"new_customers_growth_pct":null,"monthly_churn_pct":null,"cac":null,"cogs_pct":null,"initial_investment":null,"initial_funding":null,"payment_delay_days":null,"fixed_costs":[{"label":"...","monthly_amount":0,"start_month":1}]},"found":["ce qui a été trouvé et dans quelle section"],"missing":["valeurs importantes absentes du plan, à demander à l'utilisateur"]}`;

const NUMBER_FIELDS = {
  price_per_customer_month: [0, 1e12], setup_fee: [0, 1e12], initial_customers: [0, 1e7], new_customers_per_month: [0, 1e6],
  new_customers_growth_pct: [-50, 100], monthly_churn_pct: [0, 100], cac: [0, 1e12], cogs_pct: [0, 100],
  initial_investment: [0, 1e12], initial_funding: [0, 1e12], payment_delay_days: [0, 180],
};

const fixedSchema = z.object({ label: z.string().trim().min(1).max(80), monthly_amount: z.number().min(0).max(1e12), start_month: z.number().int().min(1).max(60).catch(1) });

/** Extrait de vraies valeurs déjà écrites dans le plan pour pré-remplir les hypothèses. L'utilisateur les vérifie avant d'enregistrer. */
export async function suggestAssumptions({ plan, sections }) {
  const body = sections
    .filter((s) => s.content && s.content.trim())
    .map((s) => `### ${s.title}\n${clip(s.content, 1800)}`)
    .join('\n\n');
  if (!body) return { suggestions: {}, found: [], missing: ['Aucune section rédigée : renseignez les hypothèses à la main.'], tokens: 0 };

  const { data, tokens } = await chatJson({ system: SYSTEM, user: `${planContext(plan)}\n\n${wrapData('sections_du_plan', body)}`, temperature: 0, maxTokens: 1200 });

  const raw = data?.assumptions || {};
  const suggestions = {};
  for (const [key, [min, max]] of Object.entries(NUMBER_FIELDS)) {
    const v = raw[key];
    if (typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max) suggestions[key] = v;
  }
  if (typeof raw.currency === 'string' && raw.currency.trim() && raw.currency.trim().length <= 8) suggestions.currency = raw.currency.trim();
  const fixed = (Array.isArray(raw.fixed_costs) ? raw.fixed_costs : []).map((c) => fixedSchema.safeParse(c)).filter((r) => r.success).map((r) => r.data).slice(0, 30);
  if (fixed.length) suggestions.fixed_costs = fixed;

  const list = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string' && x.trim()).map((x) => clip(x, 300)).slice(0, 12) : []);
  return { suggestions, found: list(data?.found), missing: list(data?.missing), tokens };
}
