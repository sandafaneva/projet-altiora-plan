import { chatJson } from '../groq.js';
import { BASE_RULES, wrapData, clip, planContext, sectionsSummary } from './common.js';

const SYSTEM = `${BASE_RULES}
Tu es l'agent méta-prompt d'une application de business plan. Tu travailles en coulisses : l'utilisateur ne voit pas ton travail.
Ta mission : transformer la demande brute de l'utilisateur en une instruction complète, précise et directement exploitable par un agent rédacteur. Tu ne rédiges PAS la section toi-même.
L'instruction que tu produis doit :
1. rappeler le contexte du projet (idée, secteur, clients cibles) ;
2. préciser l'objectif de la section et les points à traiter ;
3. imposer une grande rigueur (décideurs, cycle de vente, ROI, chiffres justifiés ou marqués comme hypothèses) ;
4. intégrer les réponses de l'utilisateur aux questions de guidage ;
5. si une version précédente existe, lister les corrections à apporter (manques, incohérences) tout en conservant ce qui est bon ;
6. rester cohérente avec les autres sections déjà rédigées ;
7. fixer le format attendu (Markdown, 350 à 700 mots) ;
8. si un modèle financier calculé est fourni, exiger que la section s'appuie UNIQUEMENT sur ses chiffres (aucun autre montant, aucune autre projection).
Réponds uniquement avec un objet JSON : {"meta_prompt":"<instruction complète>"}`;

function fallbackMetaPrompt({ section, userPrompt, answers }) {
  const extra = answers.length ? `\nInformations complémentaires de l'utilisateur :\n${answers.map((a) => `- ${a.question} : ${a.answer}`).join('\n')}` : '';
  return `Rédige la section « ${section.title} » du business plan. Objectif : ${section.objective} Points à traiter : ${(section.key_points || []).join(' ; ')}.\nDemande de l'utilisateur : ${userPrompt}${extra}`;
}

/** Méta-prompt (R7) : enrichit, en coulisses, la demande de l'utilisateur avant l'appel au rédacteur. */
export async function buildMetaPrompt({ plan, section, others, userPrompt, answers, previousContent, previousAnalysis, financials }) {
  const parts = [
    planContext(plan),
    `Section à rédiger : ${section.title}\nObjectif : ${section.objective}\nPoints clés : ${(section.key_points || []).join(' ; ')}`,
    wrapData('demande_utilisateur', userPrompt),
  ];

  if (answers.length) {
    parts.push(wrapData('reponses_aux_questions_de_guidage', answers.map((a) => `Question : ${a.question}\nRéponse : ${a.answer}`).join('\n\n')));
  }
  if (previousContent) {
    parts.push(wrapData('version_precedente', clip(previousContent, 2500)));
    if (previousAnalysis) {
      const notes = [
        ...(previousAnalysis.manques || []).map((m) => `Manque : ${m}`),
        ...(previousAnalysis.incoherences || []).map((m) => `Incohérence : ${m}`),
      ].join('\n');
      if (notes) parts.push(wrapData('analyse_de_la_version_precedente', notes));
    }
  }
  const summary = sectionsSummary(others, { max: 500 });
  if (summary) parts.push(summary);
  if (financials) parts.push(wrapData('modele_financier_calcule', financials));

  const { data, tokens } = await chatJson({ system: SYSTEM, user: parts.join('\n\n'), temperature: 0.3, maxTokens: 1200 });
  const metaPrompt =
    typeof data?.meta_prompt === 'string' && data.meta_prompt.trim().length > 20
      ? data.meta_prompt.trim()
      : fallbackMetaPrompt({ section, userPrompt, answers });
  return { metaPrompt, tokens };
}
