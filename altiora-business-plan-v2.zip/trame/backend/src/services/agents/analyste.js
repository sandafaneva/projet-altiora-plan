import { chatJson } from '../groq.js';
import { BASE_RULES, wrapData, clip, planContext, sectionsSummary, asStringArray } from './common.js';

/** Grille d'analyse par section. */
const RUBRICS = {
  resume_executif: "Synthèse claire du problème, de la solution, de la cible, du modèle économique, des objectifs chiffrés et du besoin éventuel de financement ; parfaite cohérence avec les autres sections.",
  probleme_solution: "Problème vécu par le client (coût, fréquence), proposition de valeur exprimée en ROI / temps gagné / coûts réduits, solution concrète, preuves ou premiers retours.",
  marche_cibles: "Segments de clients précis (taille, secteur, zone), personas (décideur, utilisateur, prescripteur), taille du marché TAM/SAM/SOM avec sources ou hypothèses explicites.",
  offre_pricing: "Offre claire, modèle de revenus (abonnement, licence, projet), prix justifié, unit economics (CAC, LTV, marge, churn/MRR).",
  concurrence: "Concurrents directs, indirects et alternatives internes, comparaison factuelle, différenciation défendable.",
  strategie_commerciale: "Canaux d'acquisition, étapes et durée du cycle de vente, objectifs de conversion, partenariats, ressources commerciales.",
  plan_operationnel: "Organisation, équipe et rôles, processus de livraison et de support, outils et fournisseurs, jalons de mise en œuvre.",
  plan_financier: "Hypothèses explicites, revenus, coûts, seuil de rentabilité, trésorerie, besoin de financement ; cohérence avec le prix, le marché et la stratégie commerciale.",
  risques: "Risques principaux (marché, commercial, technique, financier, juridique), probabilité et impact, mesures de mitigation concrètes.",
};

const SYSTEM = `${BASE_RULES}
Tu es l'agent analyste et guide. Tu n'écris PAS le business plan : tu évalues une section rédigée par un autre agent et tu guides l'utilisateur pour l'améliorer. Sois exigeant et honnête.
Barème : moins de 40 = très incomplet ; 40 à 69 = à consolider ; 70 et plus = exploitable. Chaque critère de la grille absent ou vague fait baisser le score. Pénalise les chiffres non justifiés, les affirmations creuses et les incohérences avec les autres sections. Si un bloc modele_financier_calcule est fourni, il fait foi : tout chiffre du texte qui le contredit, ou qui n'en provient pas et n'est pas marqué comme hypothèse, est une incohérence.
Réponds uniquement avec un objet JSON :
{"score":0-100,"verdict":"une phrase","points_forts":["max 4"],"manques":["max 6, précis et actionnables"],"questions_guidees":["max 4 questions concrètes à poser à l'utilisateur pour obtenir les informations manquantes"],"suggestion_prompt":"nouvelle instruction que l'utilisateur pourrait donner à l'IA pour améliorer cette section, à la première personne","incoherences":["max 4, incohérences avec le contexte ou les autres sections ; liste vide si aucune"]}`;

function normalizeAnalysis(d) {
  let score = Math.round(Number(d?.score));
  if (!Number.isFinite(score)) score = 0;
  return {
    score: Math.max(0, Math.min(100, score)),
    verdict: typeof d?.verdict === 'string' ? clip(d.verdict, 300) : '',
    points_forts: asStringArray(d?.points_forts, 4),
    manques: asStringArray(d?.manques, 6),
    questions_guidees: asStringArray(d?.questions_guidees, 4),
    suggestion_prompt: typeof d?.suggestion_prompt === 'string' ? clip(d.suggestion_prompt, 800) : '',
    incoherences: asStringArray(d?.incoherences, 4),
  };
}

/** Analyse (R13) : score, points forts, manques, questions de guidage (R14). */
export async function analyzeSection({ plan, section, others, content, financials }) {
  const user = [
    planContext(plan),
    `Section évaluée : ${section.title}\nObjectif : ${section.objective}\nGrille : ${RUBRICS[section.section_key] || section.objective}`,
    wrapData('contenu_a_evaluer', clip(content, 6000)),
    sectionsSummary(others, { max: 500 }),
    financials ? wrapData('modele_financier_calcule', financials) : '',
  ]
    .filter(Boolean)
    .join('\n\n');
  const { data, tokens } = await chatJson({ system: SYSTEM, user, temperature: 0.2, maxTokens: 1200 });
  return { analysis: normalizeAnalysis(data), tokens };
}

const REVIEW_SYSTEM = `${BASE_RULES}
Tu es l'agent de contrôle de cohérence. Tu relis un business plan complet et tu repères les contradictions entre sections (prix, segments cibles, cycle de vente, objectifs chiffrés, hypothèses financières, résumé exécutif). Si un bloc modele_financier_calcule est fourni, compare les chiffres cités dans les sections avec ce modèle.
Réponds uniquement avec un objet JSON :
{"coherence_score":0-100,"verdict":"une phrase","incoherences":["max 6, précises, avec les sections concernées"],"recommandations":["max 5 actions prioritaires avant de présenter ce plan"]}`;

/** Contrôle final de cohérence de tout le plan avant la génération du document. */
export async function reviewWholePlan({ plan, sections, financials }) {
  const body = sections.map((s) => `### ${s.title}\n${clip(s.content, 1400)}`).join('\n\n');
  const user = `${planContext(plan)}\n\n${wrapData('business_plan_complet', body)}${financials ? `\n\n${wrapData('modele_financier_calcule', financials)}` : ''}`;
  const { data, tokens } = await chatJson({ system: REVIEW_SYSTEM, user, temperature: 0.2, maxTokens: 1000 });
  let score = Math.round(Number(data?.coherence_score));
  if (!Number.isFinite(score)) score = 0;
  return {
    review: {
      coherence_score: Math.max(0, Math.min(100, score)),
      verdict: typeof data?.verdict === 'string' ? clip(data.verdict, 300) : '',
      incoherences: asStringArray(data?.incoherences, 6),
      recommandations: asStringArray(data?.recommandations, 5),
    },
    tokens,
  };
}
