import { chatJson } from '../groq.js';
import { BASE_RULES, wrapData, clip, planContext, asStringArray } from './common.js';

const PLAN_SYSTEM = `${BASE_RULES}
Tu es l'agent de suivi. Tu transformes un business plan validé en plan d'exécution concret.
Produis 12 à 28 tâches réparties en 3 à 5 phases chronologiques (par exemple "Phase 1 : Fondations (semaines 1-4)"). Chaque tâche doit être actionnable, avoir un KPI mesurable tiré du business plan (sinon "[À définir]"), une valeur cible et une échéance en semaine (1 à 52).
Réponds uniquement avec un objet JSON :
{"tasks":[{"phase":"...","title":"...","description":"...","kpi":"...","target_value":"...","due_week":1}]}
Les tâches sont listées dans l'ordre chronologique.`;

/** Transforme le plan validé en tâches / jalons / KPI (R10). */
export async function buildExecutionPlan({ plan, sections }) {
  const body = sections.map((s) => `### ${s.title}\n${clip(s.content, 1200)}`).join('\n\n');
  const user = `${planContext(plan)}\n\n${wrapData('business_plan_valide', body)}`;
  const { data, tokens } = await chatJson({ system: PLAN_SYSTEM, user, temperature: 0.3, maxTokens: 3500 });

  const raw = Array.isArray(data?.tasks) ? data.tasks : [];
  const tasks = raw
    .filter((t) => t && typeof t.title === 'string' && t.title.trim())
    .slice(0, 40)
    .map((t, i) => {
      const week = Math.round(Number(t.due_week));
      return {
        phase: clip(typeof t.phase === 'string' && t.phase.trim() ? t.phase : 'Exécution', 150),
        title: clip(t.title, 250),
        description: typeof t.description === 'string' ? clip(t.description, 1000) : '',
        kpi: typeof t.kpi === 'string' ? clip(t.kpi, 250) : '',
        target_value: typeof t.target_value === 'string' || typeof t.target_value === 'number' ? clip(String(t.target_value), 150) : '',
        due_week: Number.isFinite(week) ? Math.max(1, Math.min(52, week)) : null,
        position: i + 1,
      };
    });
  if (!tasks.length) throw new Error("L'agent de suivi n'a produit aucune tâche");
  return { tasks, tokens };
}

const REVIEW_SYSTEM = `${BASE_RULES}
Tu es l'agent de suivi. Tu compares l'avancement réel d'un plan d'exécution avec ce qui était prévu à la date du jour (échéances, retards) et tu conseilles le porteur de projet.
Réponds uniquement avec un objet JSON :
{"health":"on_track|at_risk|late","summary":"2 à 3 phrases","achievements":["max 4"],"risks":["max 4"],"recommendations":["max 5 actions concrètes"],"next_actions":["max 4 tâches à traiter en priorité"]}`;

/** Bilan du suivi : avancement réel par rapport au plan et aux échéances. */
export async function reviewProgress({ plan, tasks, today, stats }) {
  const lines = tasks
    .map((t) => {
      const due = t.due_date ? `échéance ${t.due_date}${t.is_overdue ? `, EN RETARD de ${t.days_late} jour(s)` : ''}` : 'sans échéance';
      return `- [${t.status}, ${t.progress}%] ${t.phase} / ${t.title} (${due}, KPI : ${t.kpi || 'n/a'}, cible : ${t.target_value || 'n/a'})${t.note ? ` ; note : ${t.note}` : ''}`;
    })
    .join('\n');
  const summary = `Date du jour : ${today}. Début de l'exécution : ${plan.execution_start_date || 'non défini'}. Avancement réel : ${stats.progress} %. Avancement prévu à cette date : ${stats.planned_progress} %. Tâches en retard : ${stats.overdue}.`;
  const user = `${planContext(plan)}\n\n${summary}\n\n${wrapData('taches_et_avancement', lines)}`;
  const { data, tokens } = await chatJson({ system: REVIEW_SYSTEM, user, temperature: 0.3, maxTokens: 1200 });
  const health = ['on_track', 'at_risk', 'late'].includes(data?.health) ? data.health : stats.schedule;
  return {
    review: {
      health,
      summary: typeof data?.summary === 'string' ? clip(data.summary, 800) : '',
      achievements: asStringArray(data?.achievements, 4),
      risks: asStringArray(data?.risks, 4),
      recommendations: asStringArray(data?.recommendations, 5),
      next_actions: asStringArray(data?.next_actions, 4),
    },
    tokens,
  };
}
