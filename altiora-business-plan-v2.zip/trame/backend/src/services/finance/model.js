// Moteur de calcul financier : 100 % code, aucune IA. Les mêmes hypothèses donnent toujours les mêmes chiffres.
import { z } from 'zod';
import crypto from 'node:crypto';
import { getLang } from '../../utils/lang.js';
import { warningText } from './warnings.js';

const money = z.number().finite().min(0).max(1e12);
const pct = (min, max) => z.number().finite().min(min).max(max);

export const assumptionsSchema = z.object({
  currency: z.string().trim().min(1).max(8).default('Ar'),
  horizon_months: z.number().int().min(12).max(60).default(36),

  // Revenus
  price_per_customer_month: money.refine((v) => v > 0, 'Le prix doit être supérieur à 0'), // abonnement moyen par client et par mois
  setup_fee: money.default(0), // frais d'installation, facturés une fois par nouveau client
  initial_customers: z.number().finite().min(0).max(1e7).default(0),
  new_customers_per_month: z.number().finite().min(0).max(1e6).default(0), // nouveaux clients au mois 1
  new_customers_growth_pct: pct(-50, 100).default(0), // croissance mensuelle du nombre de nouveaux clients
  monthly_churn_pct: pct(0, 100).default(0), // part des clients perdus chaque mois
  annual_price_increase_pct: pct(-50, 100).default(0),

  // Coûts
  cac: money.default(0), // coût d'acquisition d'un nouveau client (commercial et marketing)
  cogs_pct: pct(0, 100).default(0), // coût direct de production ou de livraison, en % du chiffre d'affaires
  fixed_costs: z
    .array(z.object({ label: z.string().trim().min(1).max(80), monthly_amount: money, start_month: z.number().int().min(1).max(60).default(1) }))
    .max(30)
    .default([]),
  annual_cost_increase_pct: pct(-50, 100).default(0),

  // Trésorerie et financement
  initial_investment: money.default(0), // dépense unique au mois 1
  initial_funding: money.default(0), // fonds disponibles au mois 1 (capital, prêt, subvention)
  funding_rounds: z
    .array(z.object({ label: z.string().trim().min(1).max(80), month: z.number().int().min(1).max(60), amount: money.refine((v) => v > 0, 'Montant > 0') }))
    .max(10)
    .default([]),
  payment_delay_days: z.number().int().min(0).max(180).default(30), // délai moyen de paiement des clients
  tax_rate_pct: pct(0, 60).default(0), // impôt simplifié sur le résultat d'exploitation positif, sans report de déficit
});

const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

/** Empreinte des hypothèses : permet de savoir si un texte a été rédigé avec des chiffres périmés. */
export function assumptionsHash(assumptions) {
  return crypto.createHash('sha1').update(JSON.stringify(assumptions)).digest('hex');
}

export function parseAssumptions(input) {
  return assumptionsSchema.parse(input);
}

/** Calcule le modèle mensuel, les synthèses annuelles et les indicateurs clés. */
export function computeFinancials(rawAssumptions) {
  const a = assumptionsSchema.parse(rawAssumptions);
  const H = a.horizon_months;
  const delay = Math.round(a.payment_delay_days / 30);
  const churn = a.monthly_churn_pct / 100;
  const growth = a.new_customers_growth_pct / 100;
  const cogsRate = a.cogs_pct / 100;
  const taxRate = a.tax_rate_pct / 100;

  const months = [];
  let active = a.initial_customers;
  let cash = 0;
  let cumulativeNet = -a.initial_investment;
  let cumulativeRevenue = 0;
  let cumulativeCollections = 0;
  let paybackMonth = null;

  for (let t = 1; t <= H; t++) {
    const yearIdx = Math.floor((t - 1) / 12);
    const priceFactor = (1 + a.annual_price_increase_pct / 100) ** yearIdx;
    const costFactor = (1 + a.annual_cost_increase_pct / 100) ** yearIdx;

    const newCustomers = a.new_customers_per_month * (1 + growth) ** (t - 1);
    const churned = active * churn;
    active = active - churned + newCustomers;

    const arpa = a.price_per_customer_month * priceFactor;
    const recurring = active * arpa;
    const setup = newCustomers * a.setup_fee * priceFactor;
    const revenue = recurring + setup;
    const cogs = revenue * cogsRate;
    const grossProfit = revenue - cogs;
    const acquisition = newCustomers * a.cac * costFactor;
    const fixed = a.fixed_costs.filter((c) => c.start_month <= t).reduce((s, c) => s + c.monthly_amount, 0) * costFactor;
    const opex = acquisition + fixed;
    const operatingResult = grossProfit - opex;
    const tax = Math.max(0, operatingResult) * taxRate;
    const netResult = operatingResult - tax;

    // Trésorerie : les clients paient avec un retard (délai de paiement), les charges sont payées le mois même
    const source = t - delay;
    const collections = delay === 0 ? revenue : source >= 1 ? months[source - 1].revenue : 0;
    const funding = (t === 1 ? a.initial_funding : 0) + a.funding_rounds.filter((f) => f.month === t).reduce((s, f) => s + f.amount, 0);
    const capex = t === 1 ? a.initial_investment : 0;
    const cashFlow = collections - cogs - opex - tax + funding - capex;
    cash += cashFlow;

    cumulativeRevenue += revenue;
    cumulativeCollections += collections;
    cumulativeNet += netResult;
    if (paybackMonth === null && cumulativeNet >= 0) paybackMonth = t;

    months.push({
      month: t, new_customers: newCustomers, churned, customers: active, arpa, recurring, setup, revenue, cogs,
      gross_profit: grossProfit, acquisition, fixed, opex, operating_result: operatingResult, tax, net_result: netResult,
      collections, funding, capex, cash_flow: cashFlow, cash_balance: cash, receivables: cumulativeRevenue - cumulativeCollections,
    });
  }

  // Synthèses annuelles
  const years = [];
  for (let y = 0; y * 12 < H; y++) {
    const slice = months.slice(y * 12, Math.min(H, (y + 1) * 12));
    const sum = (k) => slice.reduce((s, m) => s + m[k], 0);
    const last = slice[slice.length - 1];
    years.push({
      year: y + 1, months_count: slice.length,
      revenue: sum('revenue'), cogs: sum('cogs'), gross_profit: sum('gross_profit'), acquisition: sum('acquisition'), fixed: sum('fixed'),
      opex: sum('opex'), operating_result: sum('operating_result'), tax: sum('tax'), net_result: sum('net_result'), new_customers: sum('new_customers'),
      customers_end: last.customers, mrr_end: last.recurring, cash_end: last.cash_balance,
    });
  }

  // Point mort durable : premier mois à partir duquel le résultat d'exploitation ne redevient plus négatif
  let breakEven = null;
  for (let t = H; t >= 1 && months[t - 1].operating_result >= 0; t--) breakEven = t;

  const minMonth = months.reduce((best, m) => (m.cash_balance < best.cash_balance ? m : best), months[0]);
  const grossMargin = 1 - cogsRate;
  const unitMargin = a.price_per_customer_month * grossMargin;
  const ltv = churn > 0 ? unitMargin / churn : null;
  const totalFunding = months.reduce((s, m) => s + m.funding, 0);
  const lastM = months[H - 1];

  const kpis = {
    gross_margin_pct: a.cogs_pct === 100 ? 0 : 100 - a.cogs_pct,
    customers_end: lastM.customers,
    mrr_end: lastM.recurring,
    arr_end: lastM.recurring * 12,
    revenue_total: months.reduce((s, m) => s + m.revenue, 0),
    break_even_month: breakEven,
    payback_month: paybackMonth,
    min_cash: minMonth.cash_balance,
    min_cash_month: minMonth.month,
    funding_gap: Math.max(0, -minMonth.cash_balance),
    total_funding: totalFunding,
    ltv,
    ltv_cac: ltv !== null && a.cac > 0 ? ltv / a.cac : null,
    cac_payback_months: a.cac > 0 && unitMargin > 0 ? a.cac / unitMargin : null,
    receivables_end: lastM.receivables,
  };

  return {
    horizon_months: H,
    currency: a.currency,
    months: months.map(roundObj),
    years: years.map(roundObj),
    kpis: roundObj(kpis),
    warnings: buildWarningItems(a, kpis).map(({ code, params }) => warningText(code, params, getLang())),
    warning_items: buildWarningItems(a, kpis),
  };
}

function roundObj(o) {
  return Object.fromEntries(Object.entries(o).map(([k, v]) => [k, typeof v === 'number' ? r2(v) : v]));
}

/** Alertes de bon sens calculées par le code (pas par l'IA). Chaque alerte a un code et des valeurs : le texte est rédigé dans la langue de la requête. */
function buildWarningItems(a, k) {
  const w = [];
  if (k.min_cash < 0) w.push({ code: 'negative_cash', params: { min_cash: k.min_cash, month: k.min_cash_month, gap: k.funding_gap, currency: a.currency } });
  if (k.break_even_month === null) w.push({ code: 'no_break_even', params: { months: a.horizon_months } });
  if (a.monthly_churn_pct > 3) {
    const annual = (1 - (1 - a.monthly_churn_pct / 100) ** 12) * 100;
    w.push({ code: 'high_churn', params: { churn: a.monthly_churn_pct, annual } });
  }
  if (k.ltv_cac !== null && k.ltv_cac < 3) w.push({ code: 'low_ltv_cac', params: { ratio: k.ltv_cac } });
  if (k.cac_payback_months !== null && k.cac_payback_months > 18) w.push({ code: 'slow_cac_payback', params: { months_payback: k.cac_payback_months } });
  if (a.payment_delay_days >= 60) w.push({ code: 'long_payment_delay', params: { days: a.payment_delay_days, receivables: k.receivables_end, currency: a.currency } });
  if (a.new_customers_growth_pct > 10) w.push({ code: 'fast_growth', params: { growth: a.new_customers_growth_pct, months: a.horizon_months } });
  if (a.fixed_costs.length === 0) w.push({ code: 'no_fixed_costs', params: {} });
  return w.map((x) => ({ ...x, params: Object.fromEntries(Object.entries(x.params).map(([key, v]) => [key, typeof v === 'number' ? r2(v) : v])) }));
}
