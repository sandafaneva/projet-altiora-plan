// Formatage des nombres à la française. On utilise l'espace insécable U+00A0 (présent dans toutes les polices),
// et non l'espace fine U+202F que produit toLocaleString('fr-FR') et que les polices PDF n'ont pas.
const NBSP = '\u00A0';

export function fmtNum(n, d = 0) {
  if (n === null || n === undefined || Number.isNaN(n)) return 'n/a';
  const sign = n < 0 && Number(Math.abs(n).toFixed(d)) !== 0 ? '-' : '';
  const [int, dec] = Math.abs(n).toFixed(d).split('.');
  const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, NBSP);
  return `${sign}${grouped}${dec ? `,${dec}` : ''}`;
}
