// Mise en forme des chiffres : tableaux partagés par le document Markdown, le Word et le PDF.
import { computeFinancials } from './model.js';
import { getLang } from '../../utils/lang.js';
import { fmtNum } from './numbers.js';
import { tt } from '../labels.js';
import { warningText } from './warnings.js';

const NBSP = '\u00A0';

export { fmtNum };
export const fmtMoney = (n, cur) => `${fmtNum(n)}${NBSP}${cur}`;
export const fmtPct = (n, d = 1) => `${fmtNum(n, d)}${NBSP}%`;

/** Toutes les tables de l'annexe financière, sous forme de données. Les libellés suivent la langue demandée (français par défaut). */
export function financeTables(assumptions, results, lang = 'fr') {
  const cur = results.currency;
  const a = assumptions;
  const k = results.kpis;
  const t = (key, p) => tt(key, p, lang);
  const monthLabel = (m) => (m === null || m === undefined ? t('notReached') : t('monthN', { n: m }));

  const hypotheses = {
    title: t('hypotheses'),
    head: [t('hypothesis'), t('value')],
    align: ['left', 'right'],
    rows: [
      [t('h.horizon'), t('monthsN', { n: a.horizon_months })],
      [t('h.price'), fmtMoney(a.price_per_customer_month, cur)],
      [t('h.setup'), fmtMoney(a.setup_fee, cur)],
      [t('h.initialCustomers'), fmtNum(a.initial_customers, 1)],
      [t('h.newCustomers'), fmtNum(a.new_customers_per_month, 1)],
      [t('h.growth'), fmtPct(a.new_customers_growth_pct)],
      [t('h.churn'), fmtPct(a.monthly_churn_pct)],
      [t('h.priceUp'), fmtPct(a.annual_price_increase_pct)],
      [t('h.cac'), fmtMoney(a.cac, cur)],
      [t('h.cogs'), fmtPct(a.cogs_pct)],
      ...a.fixed_costs.map((c) => [t('h.fixed', { label: c.label, m: c.start_month }), t('perMonth', { v: fmtMoney(c.monthly_amount, cur) })]),
      [t('h.costUp'), fmtPct(a.annual_cost_increase_pct)],
      [t('h.investment'), fmtMoney(a.initial_investment, cur)],
      [t('h.funding'), fmtMoney(a.initial_funding, cur)],
      ...a.funding_rounds.map((f) => [t('h.round', { label: f.label, m: f.month }), fmtMoney(f.amount, cur)]),
      [t('h.delay'), t('daysN', { n: a.payment_delay_days })],
      [t('h.tax'), fmtPct(a.tax_rate_pct)],
    ],
  };

  const ys = results.years;
  const yearRow = (key, pick, d = 0) => [t(`a.${key}`), ...ys.map((y) => fmtNum(pick(y), d))];
  const annual = {
    title: t('annual'),
    head: [t('item'), ...ys.map((y) => t('yearN', { n: y.year }))],
    align: ['left', ...ys.map(() => 'right')],
    rows: [
      yearRow('revenue', (y) => y.revenue),
      yearRow('cogs', (y) => y.cogs),
      yearRow('gross', (y) => y.gross_profit),
      yearRow('acquisition', (y) => y.acquisition),
      yearRow('fixed', (y) => y.fixed),
      yearRow('operating', (y) => y.operating_result),
      yearRow('tax', (y) => y.tax),
      yearRow('net', (y) => y.net_result),
      yearRow('newCustomers', (y) => y.new_customers),
      yearRow('customersEnd', (y) => y.customers_end),
      yearRow('mrrEnd', (y) => y.mrr_end),
      yearRow('cashEnd', (y) => y.cash_end),
    ],
  };

  const indicators = {
    title: t('indicators'),
    head: [t('indicator'), t('value')],
    align: ['left', 'right'],
    rows: [
      [t('i.revenueTotal'), fmtMoney(k.revenue_total, cur)],
      [t('i.grossMargin'), fmtPct(k.gross_margin_pct)],
      [t('i.arr'), fmtMoney(k.arr_end, cur)],
      [t('i.customersEnd'), fmtNum(k.customers_end, 0)],
      [t('i.breakEven'), monthLabel(k.break_even_month)],
      [t('i.payback'), monthLabel(k.payback_month)],
      [t('i.minCash'), t('minCashAt', { v: fmtMoney(k.min_cash, cur), m: k.min_cash_month })],
      [t('i.gap'), fmtMoney(k.funding_gap, cur)],
      [t('i.ltv'), k.ltv === null ? t('ltvNone') : fmtMoney(k.ltv, cur)],
      [t('i.ltvCac'), k.ltv_cac === null ? 'n/a' : fmtNum(k.ltv_cac, 1)],
      [t('i.cacPayback'), k.cac_payback_months === null ? 'n/a' : t('monthsN', { n: fmtNum(k.cac_payback_months, 1) })],
    ],
  };

  const monthly = {
    title: t('monthly'),
    widths: [0.07, 0.12, 0.09, 0.18, 0.18, 0.2, 0.16],
    head: [t('m.month'), t('m.newCustomers'), t('m.customers'), t('m.revenue'), t('m.charges'), t('m.operating'), t('m.cash')],
    align: ['left', 'right', 'right', 'right', 'right', 'right', 'right'],
    rows: results.months.map((m) => [
      String(m.month), fmtNum(m.new_customers, 1), fmtNum(m.customers, 0), fmtNum(m.revenue),
      fmtNum(m.cogs + m.opex + m.tax), fmtNum(m.operating_result), fmtNum(m.cash_balance),
    ]),
  };

  const warnings = (results.warning_items || []).map(({ code, params }) => warningText(code, params, lang));
  return { hypotheses, annual, indicators, monthly, warnings: results.warning_items ? warnings : results.warnings, currency: cur };
}

const mdTable = (t) => [
  `| ${t.head.join(' | ')} |`,
  `| ${t.align.map((al) => (al === 'right' ? '---:' : ':---')).join(' | ')} |`,
  ...t.rows.map((r) => `| ${r.join(' | ')} |`),
].join('\n');

/** Annexe financière au format Markdown (ajoutée au document final). */
export function annexMarkdown(assumptions, results, lang = 'fr') {
  const t = financeTables(assumptions, results, lang);
  const L = (key, p) => tt(key, p, lang);
  const lines = [
    `## ${L('annexTitle')}`, '',
    `*${L('annexNote', { cur: t.currency })}*`, '',
    `### ${L('hypotheses')}`, '', mdTable(t.hypotheses), '',
    `### ${L('annual')}`, '', mdTable(t.annual), '',
    `### ${L('indicators')}`, '', mdTable(t.indicators), '',
  ];
  if (t.warnings.length) lines.push(`### ${L('warnings')}`, '', ...t.warnings.map((w) => `- ${w}`), '');
  return lines.join('\n');
}

/** Bloc de contexte transmis aux agents IA : les chiffres du moteur font foi. */
export function financialContextBlock(assumptions, results) {
  const t = financeTables(assumptions, results, 'fr');
  const line = (r) => r.join(' : ');
  return [
    `Modèle financier calculé par le code (montants en ${t.currency}). Ces chiffres font foi : ne les modifie pas et n'en invente aucun autre.`,
    'HYPOTHÈSES :', ...t.hypotheses.rows.map(line),
    'RÉSULTATS PAR ANNÉE :', ...t.annual.rows.map((r) => `${r[0]} : ${r.slice(1).map((v, i) => `A${i + 1} ${v}`).join(', ')}`),
    'INDICATEURS :', ...t.indicators.rows.map(line),
    ...(t.warnings.length ? ['POINTS D\'ATTENTION :', ...t.warnings] : []),
  ].join('\n');
}

export function buildFinancials(assumptions) {
  const results = computeFinancials(assumptions);
  return { results, tables: financeTables(assumptions, results, getLang()) };
}
