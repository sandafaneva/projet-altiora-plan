import { tt } from '../labels.js';
import { fmtNum } from './numbers.js';

/** Texte d'une alerte du moteur dans la langue demandée. Le moteur envoie un code et des valeurs : le frontend peut aussi les rédiger lui-même. */
export function warningText(code, p, lang = 'fr') {
  return tt(`w.${code}`, {
    ...p,
    min_cash: fmtNum(p.min_cash ?? 0), gap: fmtNum(p.gap ?? 0), annual: fmtNum(p.annual ?? 0), churn: fmtNum(p.churn ?? 0, 1),
    ratio: fmtNum(p.ratio ?? 0, 1), months_payback: fmtNum(p.months_payback ?? 0, 1), receivables: fmtNum(p.receivables ?? 0), growth: fmtNum(p.growth ?? 0, 1),
  }, lang);
}
