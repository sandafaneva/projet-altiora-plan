import { env } from '../config/env.js';
import { HttpError } from '../utils/http.js';
import { getLang } from '../utils/lang.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const MAX_ATTEMPTS = 4;
const REASONING_MODEL = /gpt-oss/i;
const REASONING_HEADROOM = 1500;
const MAX_WAIT_MS = 30_000; // au-delà, on n'attend pas : on bascule sur le modèle de secours ou on informe l'utilisateur

/** Erreur interne : indique si un autre modèle a une chance de réussir. */
class GroqError extends HttpError {
  constructor(status, message, { fallback = false } = {}) {
    super(status, message);
    this.fallback = fallback;
  }
}

async function http(path, { method = 'GET', body, timeoutMs = 60_000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(`${env.groqBaseUrl}${path}`, {
      method,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.groqApiKey}` },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }
}

async function readError(res) {
  const text = await res.text().catch(() => '');
  try {
    const j = JSON.parse(text);
    return { message: String(j?.error?.message || ''), code: String(j?.error?.code || ''), raw: text };
  } catch {
    return { message: text.slice(0, 200), code: '', raw: text };
  }
}

/** Durée à attendre avant de réessayer (en ms), d'après l'en-tête retry-after ou le message de Groq ("try again in 6.03s"). */
function waitTime(res, err, attempt) {
  const header = Number(res.headers.get('retry-after'));
  if (Number.isFinite(header) && header > 0) return header * 1000 + 250;
  const m = err.message.match(/try again in\s+(?:(\d+)h)?\s*(?:(\d+)m(?!s))?\s*(?:([\d.]+)s)?/i);
  if (m && (m[1] || m[2] || m[3])) return ((Number(m[1] || 0) * 60 + Number(m[2] || 0)) * 60 + Number(m[3] || 0)) * 1000 + 250;
  return 1500 * attempt;
}

const humanWait = (ms) => (ms >= 90_000 ? `environ ${Math.ceil(ms / 60_000)} minutes` : `environ ${Math.ceil(ms / 1000)} secondes`);

async function chatWithModel(model, { system, user, json, temperature, maxTokens }) {
  // Modèles à raisonnement (ex. openai/gpt-oss-120b) : les tokens de raisonnement comptent dans max_completion_tokens.
  // On garde une marge pour que la réponse ne soit pas tronquée, et on n'envoie les paramètres de raisonnement qu'à ces modèles.
  const reasoning = REASONING_MODEL.test(model);
  const body = {
    model,
    temperature,
    max_completion_tokens: maxTokens + (reasoning ? REASONING_HEADROOM : 0),
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user },
    ],
  };
  if (reasoning) {
    body.include_reasoning = false; // la réflexion interne n'est pas renvoyée
    if (env.groqReasoningEffort) body.reasoning_effort = env.groqReasoningEffort;
  }
  if (json) body.response_format = { type: 'json_object' };

  let jsonModeDisabled = false;
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    let res;
    try {
      res = await http('/chat/completions', { method: 'POST', body });
    } catch {
      if (attempt < MAX_ATTEMPTS) {
        await sleep(800 * attempt);
        continue;
      }
      throw new GroqError(503, 'Le service Groq ne répond pas. Vérifiez la connexion internet du serveur puis réessayez.', { fallback: true });
    }

    if (res.ok) {
      const data = await res.json();
      let content = data.choices?.[0]?.message?.content ?? '';
      content = content.replace(/<think>[\s\S]*?<\/think>/g, '').trim(); // modèles "raisonnement"
      if (!content) {
        // Réponse vide : typiquement, le raisonnement a consommé tout le budget de tokens (finish_reason "length")
        const reason = data.choices?.[0]?.finish_reason;
        throw new GroqError(502, reason === 'length' ? "La réponse de l'IA a été tronquée. Réessayez." : "L'IA a renvoyé une réponse vide. Réessayez.", { fallback: true });
      }
      return { content, tokens: data.usage?.total_tokens ?? 0, model };
    }

    const err = await readError(res);

    // Le mode JSON de Groq peut échouer si le modèle produit un JSON invalide : on réessaie une fois en mode libre.
    if (res.status === 400 && err.code === 'json_validate_failed' && body.response_format && !jsonModeDisabled) {
      delete body.response_format;
      jsonModeDisabled = true;
      continue;
    }
    if (res.status === 401) throw new GroqError(503, "Clé Groq invalide ou révoquée. Vérifiez GROQ_API_KEY dans backend/.env.");
    if (res.status === 403) throw new GroqError(503, "Accès Groq refusé (clé, organisation ou région non autorisée).");
    if (res.status === 404 || err.code === 'model_not_found' || err.code === 'model_decommissioned' || /decommissioned|does not exist/i.test(err.message)) {
      throw new GroqError(503, `Le modèle Groq « ${model} » est indisponible. Vérifiez GROQ_MODEL (voir console.groq.com/docs/models).`, { fallback: true });
    }
    if (res.status === 413 || err.code === 'context_length_exceeded') {
      throw new GroqError(413, 'Le contenu envoyé à l’IA est trop long. Raccourcissez le texte de la section.');
    }
    if (res.status === 429) {
      const wait = waitTime(res, err, attempt);
      const tooLarge = /request too large/i.test(err.message);
      if (tooLarge) throw new GroqError(413, "La requête dépasse la limite de tokens du modèle Groq. Raccourcissez le texte.", { fallback: true });
      if (wait <= MAX_WAIT_MS && attempt < MAX_ATTEMPTS) {
        await sleep(wait);
        continue;
      }
      throw new GroqError(429, `Limite d'utilisation Groq atteinte. Réessayez dans ${humanWait(wait)}.`, { fallback: true });
    }
    if (res.status >= 500 && attempt < MAX_ATTEMPTS) {
      await sleep(1000 * attempt);
      continue;
    }
    console.error('[groq]', model, res.status, err.raw.slice(0, 300));
    throw new GroqError(502, `Erreur du service Groq (${res.status}). Réessayez.`, { fallback: res.status >= 500 });
  }
  throw new GroqError(502, 'Erreur du service Groq. Réessayez.');
}

// Consigne de langue : ajoutée à toutes les requêtes quand l'interface est en malgache. Elle l'emporte sur la règle « Réponds en français ».
const LANGUAGE_DIRECTIVE = {
  mg: `LANGUE DE SORTIE (prioritaire sur toute autre consigne de langue) : rédige tout le contenu destiné à l'utilisateur en malgache (Malagasy), dans un style clair et professionnel. Les clés JSON, les identifiants et les valeurs imposées (par exemple on_track, at_risk, late) restent exactement inchangés. Les termes techniques courants (CAC, LTV, KPI, churn, ROI) peuvent rester tels quels. Les marqueurs d'information manquante s'écrivent \"[Ilaina hofenoina : ...]\" et les estimations \"[Petra-kevitra hamarinina]\".`,
};

/**
 * Appel à l'API Groq (compatible OpenAI), uniquement depuis le backend (R5).
 * Gère : limites de débit (attente puis reprise), JSON invalide, modèle indisponible (bascule sur le modèle de secours).
 */
export async function chat({ system, user, json = false, temperature = 0.4, maxTokens = 2500 }) {
  const directive = LANGUAGE_DIRECTIVE[getLang()];
  if (directive) system = `${system}\n\n${directive}`;
  if (!env.groqApiKey) throw new HttpError(503, 'GROQ_API_KEY non configurée sur le serveur (backend/.env).');
  const models = [env.groqModel];
  if (env.groqFallbackModel && env.groqFallbackModel !== env.groqModel) models.push(env.groqFallbackModel);

  let last;
  for (const model of models) {
    try {
      return await chatWithModel(model, { system, user, json, temperature, maxTokens });
    } catch (err) {
      last = err;
      if (!err.fallback) throw err;
      console.warn(`[groq] échec avec ${model} : ${err.message}`);
    }
  }
  throw last;
}

function extractJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    /* on tente d'extraire le premier objet JSON */
  }
  const cleaned = text.replace(/```json|```/g, '');
  const match = cleaned.match(/\{[\s\S]*\}/);
  if (match) {
    try {
      return JSON.parse(match[0]);
    } catch {
      /* ignore */
    }
  }
  return null;
}

/** Sortie JSON structurée (entrée de l'agent suivant dans le pipeline). Une seconde tentative est faite si le JSON est illisible. */
export async function chatJson(options) {
  let totalTokens = 0;
  for (let i = 0; i < 2; i++) {
    const { content, tokens } = await chat({ ...options, json: true, temperature: i === 0 ? options.temperature : 0.1 });
    totalTokens += tokens;
    const data = extractJson(content);
    if (data && typeof data === 'object') return { data, tokens: totalTokens };
  }
  throw new HttpError(502, "La réponse de l'IA est illisible. Relancez l'opération.");
}

/** Diagnostic de la connexion Groq : clé valide, modèles disponibles, et (option deep) un vrai appel JSON. */
export async function checkGroq({ deep = false } = {}) {
  const out = {
    configured: Boolean(env.groqApiKey),
    key_valid: false,
    model: { name: env.groqModel, available: false },
    fallback_model: env.groqFallbackModel ? { name: env.groqFallbackModel, available: false } : null,
    json_test: null,
    error: null,
  };
  if (!out.configured) {
    out.error = 'GROQ_API_KEY absente de backend/.env';
    return out;
  }
  try {
    const res = await http('/models', { timeoutMs: 15_000 });
    if (res.status === 401 || res.status === 403) {
      out.error = 'Clé Groq invalide ou refusée';
      return out;
    }
    if (!res.ok) {
      out.error = `Groq a répondu ${res.status}`;
      return out;
    }
    out.key_valid = true;
    const ids = new Set(((await res.json()).data || []).map((m) => m.id));
    out.model.available = ids.has(env.groqModel);
    if (out.fallback_model) out.fallback_model.available = ids.has(env.groqFallbackModel);
    if (!out.model.available) out.error = `Le modèle « ${env.groqModel} » n'existe pas pour ce compte : corrigez GROQ_MODEL`;
  } catch {
    out.error = 'Groq injoignable depuis le serveur (réseau, pare-feu ou proxy)';
    return out;
  }
  if (deep && out.key_valid) {
    try {
      const t0 = Date.now();
      const { data } = await chatJson({ system: 'Réponds uniquement avec un objet JSON {"ok": true}.', user: 'ping', maxTokens: 20, temperature: 0 });
      out.json_test = { ok: data?.ok === true, latency_ms: Date.now() - t0 };
    } catch (e) {
      out.json_test = { ok: false, error: e.message };
    }
  }
  return out;
}
