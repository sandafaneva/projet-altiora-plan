// Libellés fixes des tableaux chiffrés, du document final et des exports, en français et en malgache.
import { getLang } from '../utils/lang.js';

const MONTHS_MG = ['Janoary', 'Febroary', 'Martsa', 'Aprily', 'Mey', 'Jona', 'Jolay', 'Aogositra', 'Septambra', 'Oktobra', 'Novambra', 'Desambra'];

const T = {
  fr: {
    sector: 'Secteur', clients: 'Clients cibles',
    'sec.probleme_solution': 'Problème et proposition de valeur', 'sec.marche_cibles': 'Marché et clients cibles', 'sec.offre_pricing': 'Offre et modèle économique',
    'sec.concurrence': 'Concurrence et différenciation', 'sec.strategie_commerciale': 'Stratégie commerciale et cycle de vente', 'sec.plan_operationnel': 'Plan opérationnel et équipe',
    'sec.plan_financier': 'Plan financier et hypothèses', 'sec.risques': 'Risques et plan de mitigation', 'sec.resume_executif': 'Résumé exécutif',
    notReached: 'Non atteint', monthN: 'Mois {n}', monthsN: '{n} mois', daysN: '{n} jours', perMonth: '{v} / mois', yearN: 'Année {n}', ltvNone: 'n/a (churn nul)', minCashAt: '{v} (mois {m})',
    toc: 'Sommaire', item: 'Poste',
    hypotheses: 'Hypothèses', hypothesis: 'Hypothèse', value: 'Valeur', annual: 'Résultats par année', indicators: 'Indicateurs clés', indicator: 'Indicateur', monthly: 'Détail mensuel',
    'h.horizon': 'Horizon de projection', 'h.price': 'Prix moyen par client et par mois', 'h.setup': "Frais d'installation par nouveau client", 'h.initialCustomers': 'Clients au démarrage',
    'h.newCustomers': 'Nouveaux clients par mois (mois 1)', 'h.growth': 'Croissance mensuelle des nouveaux clients', 'h.churn': 'Churn mensuel', 'h.priceUp': 'Hausse annuelle des prix',
    'h.cac': "Coût d'acquisition d'un client (CAC)", 'h.cogs': "Coûts directs (% du chiffre d'affaires)", 'h.fixed': 'Charge fixe : {label} (dès le mois {m})', 'h.costUp': 'Hausse annuelle des coûts',
    'h.investment': 'Investissement initial', 'h.funding': 'Financement initial', 'h.round': 'Financement : {label} (mois {m})', 'h.delay': 'Délai de paiement des clients', 'h.tax': "Taux d'impôt (simplifié)",
    'a.revenue': "Chiffre d'affaires", 'a.cogs': 'Coûts directs', 'a.gross': 'Marge brute', 'a.acquisition': 'Acquisition de clients', 'a.fixed': 'Charges fixes', 'a.operating': "Résultat d'exploitation",
    'a.tax': 'Impôt', 'a.net': 'Résultat net', 'a.newCustomers': 'Nouveaux clients', 'a.customersEnd': "Clients en fin d'année", 'a.mrrEnd': "Revenu récurrent mensuel en fin d'année", 'a.cashEnd': "Trésorerie en fin d'année",
    'i.revenueTotal': "Chiffre d'affaires cumulé", 'i.grossMargin': 'Marge brute', 'i.arr': 'Revenu annuel récurrent en fin de période', 'i.customersEnd': 'Clients en fin de période',
    'i.breakEven': "Point mort (résultat d'exploitation durablement positif)", 'i.payback': "Récupération de l'investissement initial", 'i.minCash': 'Trésorerie minimale',
    'i.gap': 'Financement supplémentaire nécessaire', 'i.ltv': 'Valeur vie client (LTV)', 'i.ltvCac': 'Ratio LTV / CAC', 'i.cacPayback': 'Récupération du CAC',
    'm.month': 'Mois', 'm.newCustomers': 'Nouveaux clients', 'm.customers': 'Clients', 'm.revenue': "Chiffre d'affaires", 'm.charges': 'Charges', 'm.operating': "Résultat d'exploitation", 'm.cash': 'Trésorerie',
    annexTitle: 'Annexe : modèle financier', annexNote: "Montants en {cur}. Chiffres calculés automatiquement à partir des hypothèses ci-dessous ; ils ne sont pas rédigés par l'IA.", warnings: "Points d'attention",
    annexNotePlain: "Montants en {cur}. Ces chiffres sont calculés automatiquement à partir des hypothèses ci-dessous ; ils ne sont pas rédigés par l'IA.",
    execAnnex: "Annexe : plan d'exécution", 'x.phase': 'Phase', 'x.task': 'Tâche', 'x.due': 'Échéance', 'x.kpi': 'KPI (cible)', 'x.status': 'Statut',
    'st.todo': 'À faire', 'st.in_progress': 'En cours', 'st.done': 'Terminée', 'st.blocked': 'Bloquée',
    kicker: 'Business plan', generatedOn: 'Document généré le {date}', page: 'Page', chartRevenue: "Chiffre d'affaires et charges (par mois)", chartRevenueLegend: "Chiffre d'affaires", chartCharges: 'Charges totales',
    chartCash: 'Trésorerie en fin de mois', chartCashLegend: 'Trésorerie', amountsIn: 'Montants en {cur}',
    'w.negative_cash': 'La trésorerie devient négative (minimum {min_cash} {currency} au mois {month}). Il manque au moins {gap} {currency} de financement.',
    'w.no_break_even': "Aucun point mort durable sur les {months} mois : le résultat d'exploitation reste négatif en fin de période.",
    'w.high_churn': 'Le churn mensuel ({churn} %) fait perdre environ {annual} % des clients par an : ce niveau est élevé.',
    'w.low_ltv_cac': "Le ratio LTV/CAC est de {ratio} : en dessous de 3, l'acquisition de clients est peu rentable.",
    'w.slow_cac_payback': "Le coût d'acquisition n'est récupéré qu'au bout de {months_payback} mois.",
    'w.long_payment_delay': 'Un délai de paiement de {days} jours immobilise beaucoup de trésorerie (créances clients en fin de période : {receivables} {currency}).',
    'w.fast_growth': "La croissance de {growth} % par mois du nombre de nouveaux clients se cumule très vite : vérifiez qu'elle est réaliste sur {months} mois.",
    'w.no_fixed_costs': "Aucune charge fixe n'est renseignée (salaires, loyers, outils) : le résultat est probablement surestimé.",
  },
  mg: {
    sector: 'Sehatra', clients: 'Mpanjifa kendrena',
    'sec.probleme_solution': "Olana sy tombontsoa entin'ny tolotra", 'sec.marche_cibles': 'Tsena sy mpanjifa kendrena', 'sec.offre_pricing': 'Tolotra sy modely ara-toekarena',
    'sec.concurrence': 'Fifaninanana sy fahasamihafana', 'sec.strategie_commerciale': "Paikady ara-barotra sy dingan'ny varotra", 'sec.plan_operationnel': 'Drafitra fanatanterahana sy ekipa',
    'sec.plan_financier': 'Drafitra ara-bola sy petra-kevitra', 'sec.risques': 'Loza mety hitranga sy fanalefahana azy', 'sec.resume_executif': "Famintinana ho an'ny mpitarika",
    notReached: 'Tsy tratra', monthN: 'Volana {n}', monthsN: '{n} volana', daysN: '{n} andro', perMonth: '{v} / volana', yearN: 'Taona {n}', ltvNone: 'n/a (churn 0)', minCashAt: '{v} (volana {m})',
    toc: 'Votoatiny', item: 'Karazana',
    hypotheses: 'Petra-kevitra', hypothesis: 'Petra-kevitra', value: 'Sanda', annual: 'Vokatra isan-taona', indicators: 'Famantarana lehibe', indicator: 'Famantarana', monthly: 'Antsipiriany isam-bolana',
    'h.horizon': "Faharetan'ny tombana", 'h.price': 'Vidiny antonony isaky ny mpanjifa isam-bolana', 'h.setup': 'Sarany fametrahana isaky ny mpanjifa vaovao', 'h.initialCustomers': "Mpanjifa amin'ny fiandohana",
    'h.newCustomers': 'Mpanjifa vaovao isam-bolana (volana 1)', 'h.growth': "Fitomboan'ny mpanjifa vaovao isam-bolana", 'h.churn': 'Churn isam-bolana', 'h.priceUp': "Fiakaran'ny vidiny isan-taona",
    'h.cac': 'Sarany hahazoana mpanjifa iray (CAC)', 'h.cogs': "Sarany mivantana (% amin'ny fidiram-bola)", 'h.fixed': "Sarany raikitra: {label} (manomboka amin'ny volana {m})", 'h.costUp': "Fiakaran'ny sarany isan-taona",
    'h.investment': 'Fampiasam-bola voalohany', 'h.funding': 'Famatsiam-bola voalohany', 'h.round': 'Famatsiam-bola: {label} (volana {m})', 'h.delay': "Fe-potoana fandoavan'ny mpanjifa", 'h.tax': "Tahan'ny hetra (tsotra)",
    'a.revenue': 'Fidiram-bola', 'a.cogs': 'Sarany mivantana', 'a.gross': 'Tombony ambony', 'a.acquisition': 'Fahazoana mpanjifa', 'a.fixed': 'Sarany raikitra', 'a.operating': 'Vokatra ara-pitantanana',
    'a.tax': 'Hetra', 'a.net': 'Vokatra net', 'a.newCustomers': 'Mpanjifa vaovao', 'a.customersEnd': "Mpanjifa amin'ny faran'ny taona", 'a.mrrEnd': "Fidiram-bola isam-bolana amin'ny faran'ny taona", 'a.cashEnd': "Tahiry ara-bola amin'ny faran'ny taona",
    'i.revenueTotal': 'Fidiram-bola nitambatra', 'i.grossMargin': 'Tombony ambony', 'i.arr': "Fidiram-bola mitranga isan-taona amin'ny farany", 'i.customersEnd': "Mpanjifa amin'ny farany",
    'i.breakEven': 'Fetra ahazoana tombony (maharitra)', 'i.payback': 'Fanarenana ny fampiasam-bola voalohany', 'i.minCash': 'Tahiry ara-bola kely indrindra',
    'i.gap': 'Famatsiam-bola fanampiny ilaina', 'i.ltv': "Sanda mandritra ny androm-piainan'ny mpanjifa (LTV)", 'i.ltvCac': "Tahan'ny LTV / CAC", 'i.cacPayback': 'Fanarenana ny CAC',
    'm.month': 'Volana', 'm.newCustomers': 'Mpanjifa vaovao', 'm.customers': 'Mpanjifa', 'm.revenue': 'Fidiram-bola', 'm.charges': 'Sarany', 'm.operating': 'Vokatra ara-pitantanana', 'm.cash': 'Tahiry ara-bola',
    annexTitle: 'Fanampiny: modely ara-bola', annexNote: "Vola amin'ny {cur}. Kajina ho azy avy amin'ny petra-kevitra etsy ambany ny tarehimarika; tsy ny AI no nanoratra azy.", warnings: 'Zavatra tokony hojerena',
    annexNotePlain: "Vola amin'ny {cur}. Kajina ho azy avy amin'ny petra-kevitra etsy ambany ireo tarehimarika ireo; tsy ny AI no nanoratra azy.",
    execAnnex: 'Fanampiny: drafitry ny fanatanterahana', 'x.phase': 'Dingana', 'x.task': 'Asa', 'x.due': 'Daty farany', 'x.kpi': 'KPI (tanjona)', 'x.status': 'Toetra',
    'st.todo': 'Hatao', 'st.in_progress': 'Mitohy', 'st.done': 'Vita', 'st.blocked': 'Voasakana',
    kicker: 'Drafitra ara-barotra', generatedOn: "Boky noforonina tamin'ny {date}", page: 'Pejy', chartRevenue: 'Fidiram-bola sy sarany (isam-bolana)', chartRevenueLegend: 'Fidiram-bola', chartCharges: 'Sarany rehetra',
    chartCash: "Tahiry ara-bola amin'ny faran'ny volana", chartCashLegend: 'Tahiry ara-bola', amountsIn: "Vola amin'ny {cur}",
    'w.negative_cash': "Lasa ratsy ny tahiry ara-bola (kely indrindra {min_cash} {currency} amin'ny volana faha-{month}). Mbola tsy ampy farafahakeliny {gap} {currency} amin'ny famatsiam-bola.",
    'w.no_break_even': "Tsy misy fetra ahazoana tombony maharitra mandritra ny {months} volana: mbola ratsy ny vokatra ara-pitantanana amin'ny farany.",
    'w.high_churn': "Ny churn isam-bolana ({churn} %) dia mahatonga ny very mpanjifa eo ho eo amin'ny {annual} % isan-taona: avo loatra.",
    'w.low_ltv_cac': "{ratio} ny tahan'ny LTV/CAC: raha ambanin'ny 3, tsy dia mahasoa ny fahazoana mpanjifa.",
    'w.slow_cac_payback': "Aorian'ny {months_payback} volana vao voafeno ny sarany fahazoana mpanjifa.",
    'w.long_payment_delay': "Ny fe-potoana {days} andro amin'ny fandoavana dia mamatotra tahiry ara-bola be (trosa ho azo amin'ny farany: {receivables} {currency}).",
    'w.fast_growth': "Mitombo faran'izay haingana ny fitomboana {growth} % isam-bolana amin'ny mpanjifa vaovao: hamarino raha azo tanterahina mandritra ny {months} volana.",
    'w.no_fixed_costs': 'Tsy misy sarany raikitra voasoratra (karama, hofan-trano, fitaovana): mety ho lehibe loatra ny vokatra.',
  },
};

/** Traduit une clé de libellé dans la langue de la requête (ou celle demandée). */
export function tt(key, params = {}, lang = getLang()) {
  const s = T[lang]?.[key] ?? T.fr[key] ?? key;
  return s.replace(/\{(\w+)\}/g, (_, k) => String(params[k] ?? ''));
}

/** Titre d'une section dans la langue active ; repli sur le titre enregistré. */
export const sectionTitleFor = (section, lang = getLang()) => T[lang]?.[`sec.${section.section_key}`] ?? section.title;

export function longDate(value, lang = getLang()) {
  const [y, m, d] = String(value).slice(0, 10).split('-').map(Number);
  if (!y) return '';
  if (lang === 'mg') return `${d} ${MONTHS_MG[m - 1]} ${y}`;
  return new Date(y, m - 1, d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

const norm = (t) => String(t ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/^\d+\s+/, '').trim();

/**
 * Retire du début d'un texte un titre qui répète celui de la section (« ### Marché et clients cibles »).
 * Le titre de la section est déjà ajouté par l'application : sans cela il apparaît deux fois.
 */
export function stripLeadingTitle(content, section) {
  const text = String(content ?? '');
  const m = text.match(/^\s*(?:#{1,6}\s+|\*\*)([^\n]+?)\**\s*(?:\n+|$)/);
  if (!m) return text;
  const known = new Set([section.title, T.fr[`sec.${section.section_key}`], T.mg[`sec.${section.section_key}`]].filter(Boolean).map(norm));
  return known.has(norm(m[1])) ? text.slice(m[0].length).trimStart() : text;
}
