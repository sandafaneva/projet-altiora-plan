// Construit le contenu commun du document exporté (Word et PDF) à partir des données du plan.
import { parseMarkdown } from './markdown.js';
import { longDate, sectionTitleFor, stripLeadingTitle, tt } from '../labels.js';

const run = (text, extra = {}) => [{ text: String(text ?? ''), ...extra }];

function tableBlock(t, extra = {}) {
  return {
    type: 'table',
    align: t.align,
    header: t.head.map((h) => run(h)),
    rows: t.rows.map((r) => r.map((c) => run(c))),
    ...extra,
  };
}

/** Annexe chiffrée : même contenu que dans le document Markdown, mais en blocs (avec graphiques pour le PDF). */
function financialAnnex(fin, L) {
  const t = fin.tables;
  const out = [
    { type: 'sectionTitle', text: L('annexTitle'), pageBreak: true },
    { type: 'paragraph', runs: run(L('annexNotePlain', { cur: t.currency }), { italic: true }) },
    { type: 'heading', depth: 3, runs: run(L('hypotheses')) },
    tableBlock(t.hypotheses, { widths: [0.68, 0.32] }),
    { type: 'heading', depth: 3, runs: run(L('annual')) },
    tableBlock(t.annual, { firstColWidth: 0.34 }),
    { type: 'chart', id: 'revenue_costs' },
    { type: 'chart', id: 'cash' },
    { type: 'heading', depth: 3, runs: run(L('indicators')) },
    tableBlock(t.indicators, { widths: [0.68, 0.32] }),
  ];
  if (t.warnings.length) {
    out.push({ type: 'heading', depth: 3, runs: run(L('warnings')) });
    out.push({ type: 'list', ordered: false, items: t.warnings.map((w) => ({ runs: run(w), children: [] })) });
  }
  out.push({ type: 'heading', depth: 3, runs: run(L('monthly')) });
  out.push(tableBlock(t.monthly, { compact: true, widths: t.monthly.widths }));
  return out;
}

function executionAnnex(tasks, L, lang) {
  return [
    { type: 'sectionTitle', text: L('execAnnex'), pageBreak: true },
    {
      type: 'table',
      compact: true,
      align: ['left', 'left', 'left', 'left', 'left'],
      widths: [0.16, 0.34, 0.14, 0.22, 0.14],
      header: ['x.phase', 'x.task', 'x.due', 'x.kpi', 'x.status'].map((h) => run(L(h))),
      rows: tasks.map((t) => [
        run(t.phase), run(t.title), run(t.due_date ? longDate(t.due_date, lang) : '-'),
        run([t.kpi, t.target_value ? `(${t.target_value})` : ''].filter(Boolean).join(' ') || '-'),
        run(`${L(`st.${t.status}`)}${t.progress ? ` ${t.progress} %` : ''}`),
      ]),
    },
  ];
}

export function buildDocument(data) {
  const { plan, sections, financial, tasks } = data;
  const lang = data.lang || 'fr';
  const L = (key, p) => tt(key, p, lang);
  const blocks = [];
  sections.forEach((s, i) => {
    blocks.push({ type: 'sectionTitle', text: `${i + 1}. ${sectionTitleFor(s, lang)}` });
    blocks.push(...parseMarkdown(stripLeadingTitle(s.content, s)));
  });
  if (financial) blocks.push(...financialAnnex(financial, L));
  if (tasks?.length) blocks.push(...executionAnnex(tasks, L, lang));

  return {
    cover: {
      title: plan.title,
      subtitle: `${plan.sector} – ${plan.target_clients}`,
      kicker: L('kicker'),
      date: L('generatedOn', { date: longDate(new Date().toISOString().slice(0, 10), lang) }),
    },
    blocks,
    financial,
    labels: {
      page: L('page'), toc: L('toc'), amountsIn: (cur) => L('amountsIn', { cur }), chartRevenue: L('chartRevenue'), chartRevenueLegend: L('chartRevenueLegend'),
      chartCharges: L('chartCharges'), chartCash: L('chartCash'), chartCashLegend: L('chartCashLegend'),
    },
  };
}

export function exportFilename(plan, ext) {
  const slug = plan.title.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 60) || 'business-plan';
  return `${slug}.${ext}`;
}
