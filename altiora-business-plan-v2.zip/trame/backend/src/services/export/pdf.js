import path from 'node:path';
import { createRequire } from 'node:module';
import PDFDocument from 'pdfkit';
import { runsText } from './markdown.js';
import { buildDocument } from './blocks.js';

const require = createRequire(import.meta.url);
const fontDir = (pkg) => path.join(path.dirname(require.resolve(`${pkg}/package.json`)), 'files');
const PS = fontDir('@fontsource/public-sans');
const BG = fontDir('@fontsource/bricolage-grotesque');
const FONTS = {
  Body: path.join(PS, 'public-sans-latin-400-normal.woff'),
  'Body-Bold': path.join(PS, 'public-sans-latin-600-normal.woff'),
  'Body-Italic': path.join(PS, 'public-sans-latin-400-italic.woff'),
  'Body-BoldItalic': path.join(PS, 'public-sans-latin-600-italic.woff'),
  Head: path.join(BG, 'bricolage-grotesque-latin-700-normal.woff'),
  HeadSemi: path.join(BG, 'bricolage-grotesque-latin-600-normal.woff'),
};

const C = { ink: '#0E1A3A', soft: '#5B6B82', accent: '#315EFB', wash: '#EEF2FF', line: '#DDE3EF', red: '#D63B3B', text: '#1B2438', gold: '#F5B83D' };
const M = { top: 64, bottom: 64, left: 60, right: 60 };

// Remplace les caractères que la police ne possède pas (sinon le PDF affiche des carrés)
const REPLACE = { '\u202F': ' ', '\u2009': ' ', '\u2007': ' ', '→': '->', '←': '<-', '≥': '>=', '≤': '<=', '✓': 'OK', '✔': 'OK', '×': 'x', '\u2011': '-', '−': '-' };
let glyphFont = null;
function clean(text) {
  let out = '';
  for (const ch of String(text)) {
    if (REPLACE[ch] !== undefined) out += REPLACE[ch];
    else if (ch === '\n' || ch === '\t' || !glyphFont || glyphFont.hasGlyphForCodePoint(ch.codePointAt(0))) out += ch;
  }
  return out;
}

const fontFor = (r, base = 'Body') => {
  if (r.bold && r.italic) return 'Body-BoldItalic';
  if (r.bold) return 'Body-Bold';
  if (r.italic) return 'Body-Italic';
  return base;
};

function writeRuns(doc, runs, { x, width, size = 10.5, color = C.text, align = 'left', lineGap = 3, bold = false, font = null }) {
  const parts = runs.filter((r) => r.text !== '');
  if (!parts.length) {
    doc.y += size;
    return;
  }
  parts.forEach((r, i) => {
    doc.font(font || fontFor({ ...r, bold: r.bold || bold })).fontSize(size).fillColor(color);
    const last = i === parts.length - 1;
    const opts = { continued: !last, width, align, lineGap };
    if (i === 0) doc.text(clean(r.text), x, doc.y, opts);
    else doc.text(clean(r.text), opts);
  });
}

const ensureSpace = (doc, needed) => {
  if (doc.y + needed > doc.page.height - M.bottom) doc.addPage();
};

/* ---------- Tableaux ---------- */

function columnWidths(block, total) {
  const n = block.header.length;
  if (block.widths) return block.widths.map((f) => f * total);
  if (block.firstColWidth) {
    const first = block.firstColWidth * total;
    return [first, ...Array(n - 1).fill((total - first) / (n - 1))];
  }
  const weight = block.header.map((h, c) => Math.max(6, runsText(h).length, ...block.rows.map((r) => Math.min(50, runsText(r[c] || []).length))));
  const sum = weight.reduce((a, b) => a + b, 0);
  const raw = weight.map((w) => Math.max(total * 0.08, (w / sum) * total));
  const scale = total / raw.reduce((a, b) => a + b, 0);
  return raw.map((w) => w * scale);
}

function drawTable(doc, block, { x, width }) {
  const widths = columnWidths(block, width);
  const size = block.compact ? 8 : 9;
  const padX = 5;
  const padY = block.compact ? 3 : 4;
  const cellText = (runs) => clean(runsText(runs)).replace(/\n/g, ' ');

  const rowHeight = (cells, bold) => {
    doc.font(bold ? 'Body-Bold' : 'Body').fontSize(size);
    return Math.max(...cells.map((c, i) => doc.heightOfString(cellText(c), { width: widths[i] - padX * 2 }))) + padY * 2;
  };

  const drawRow = (cells, y, { header = false } = {}) => {
    const h = rowHeight(cells, header);
    let cx = x;
    cells.forEach((c, i) => {
      if (header) doc.rect(cx, y, widths[i], h).fillColor(C.wash).fill();
      doc.lineWidth(0.5).strokeColor(C.line).rect(cx, y, widths[i], h).stroke();
      const allBold = c.length > 0 && c.every((r) => r.bold);
      doc.font(header || allBold ? 'Body-Bold' : 'Body').fontSize(size).fillColor(header ? C.ink : C.text)
        .text(cellText(c), cx + padX, y + padY, { width: widths[i] - padX * 2, align: block.align[i] || 'left', lineBreak: true });
      cx += widths[i];
    });
    return h;
  };

  let y = doc.y;
  const headerH = rowHeight(block.header, true);
  const heights = block.rows.map((row) => rowHeight(row, false));
  const limit = doc.page.height - M.bottom;

  // Prévoir les sauts de page avant de dessiner : une seule ligne ne doit jamais rester seule sur la dernière page.
  const breaks = new Set();
  let probe = y + headerH + 24 > limit ? M.top + headerH : y + headerH;
  if (y + headerH + 24 > limit) breaks.add(-1);
  let pageStart = -1; // index de la première ligne de la page courante
  heights.forEach((h, i) => {
    if (probe + h > limit) { breaks.add(i); probe = M.top + headerH; pageStart = i; }
    probe += h;
  });
  const lastBreak = Math.max(...[...breaks].filter((i) => i >= 0), -1);
  if (lastBreak >= 1 && heights.length - lastBreak === 1 && lastBreak - 1 >= 0) { breaks.delete(lastBreak); breaks.add(lastBreak - 1); }

  if (breaks.has(-1)) { doc.addPage(); y = doc.y; }
  y += drawRow(block.header, y, { header: true });
  block.rows.forEach((row, i) => {
    if (breaks.has(i)) {
      doc.addPage();
      y = doc.y;
      y += drawRow(block.header, y, { header: true }); // l'en-tête se répète à chaque page
    }
    y += drawRow(row, y);
  });
  doc.x = x;
  doc.y = y + 12;
}

/* ---------- Graphiques ---------- */

function niceStep(range, ticks) {
  const raw = range / ticks;
  const mag = 10 ** Math.floor(Math.log10(raw || 1));
  const n = raw / mag;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * mag;
}

function compact(n) {
  const a = Math.abs(n);
  const s = n < 0 ? '-' : '';
  if (a >= 1e9) return `${s}${(a / 1e9).toFixed(1).replace('.', ',')} Md`;
  if (a >= 1e6) return `${s}${(a / 1e6).toFixed(1).replace('.', ',')} M`;
  if (a >= 1e3) return `${s}${Math.round(a / 1e3)} k`;
  return `${s}${Math.round(a)}`;
}

function drawLineChart(doc, { title, series, months, currency, x, width, amountsIn }) {
  const height = 150;
  ensureSpace(doc, height + 70);
  let y = doc.y + 4;
  doc.font('HeadSemi').fontSize(11).fillColor(C.ink).text(title, x, y, { width });
  y = doc.y + 4;
  // légende
  let lx = x;
  doc.font('Body').fontSize(8.5);
  for (const s of series) {
    doc.rect(lx, y + 2, 8, 8).fillColor(s.color).fill();
    doc.fillColor(C.soft).text(s.name, lx + 12, y, { lineBreak: false });
    lx += 12 + doc.widthOfString(s.name) + 16;
  }
  y += 18;

  const left = 46;
  const plot = { x: x + left, y, w: width - left - 8, h: height - 24 };
  const all = series.flatMap((s) => s.values);
  let min = Math.min(0, ...all);
  let max = Math.max(0, ...all);
  if (max === min) max = min + 1;
  const step = niceStep(max - min, 4);
  min = Math.floor(min / step) * step;
  max = Math.ceil(max / step) * step;
  const sy = (v) => plot.y + plot.h - ((v - min) / (max - min)) * plot.h;
  const sx = (i) => plot.x + (i / Math.max(1, months - 1)) * plot.w;

  doc.font('Body').fontSize(7.5);
  for (let v = min; v <= max + step / 2; v += step) {
    const yy = sy(v);
    doc.lineWidth(v === 0 ? 0.9 : 0.4).strokeColor(v === 0 ? C.soft : C.line).moveTo(plot.x, yy).lineTo(plot.x + plot.w, yy).stroke();
    doc.fillColor(C.soft).text(compact(v), x, yy - 4, { width: left - 6, align: 'right', lineBreak: false });
  }
  const every = months > 36 ? 12 : 6;
  for (let i = 0; i < months; i++) {
    if ((i + 1) % every === 0 || i === 0) {
      doc.fillColor(C.soft).text(`M${i + 1}`, sx(i) - 10, plot.y + plot.h + 5, { width: 20, align: 'center', lineBreak: false });
    }
  }
  for (const s of series) {
    doc.lineWidth(1.6).strokeColor(s.color);
    s.values.forEach((v, i) => (i === 0 ? doc.moveTo(sx(i), sy(v)) : doc.lineTo(sx(i), sy(v))));
    doc.stroke();
  }
  doc.font('Body').fontSize(7.5).fillColor(C.soft).text(amountsIn(currency), x, plot.y + plot.h + 16, { width, align: 'right', lineBreak: false });
  doc.x = x;
  doc.y = plot.y + plot.h + 34;
}

function drawChart(doc, block, financial, x, width, labels) {
  if (!financial) return;
  const m = financial.results.months;
  const cur = financial.results.currency;
  if (block.id === 'revenue_costs') {
    drawLineChart(doc, {
      title: labels.chartRevenue, currency: cur, months: m.length, x, width, amountsIn: labels.amountsIn,
      series: [
        { name: labels.chartRevenueLegend, color: C.accent, values: m.map((r) => r.revenue) },
        { name: labels.chartCharges, color: C.red, values: m.map((r) => r.cogs + r.opex + r.tax) },
      ],
    });
  } else if (block.id === 'cash') {
    drawLineChart(doc, {
      title: labels.chartCash, currency: cur, months: m.length, x, width, amountsIn: labels.amountsIn,
      series: [{ name: labels.chartCashLegend, color: C.ink, values: m.map((r) => r.cash_balance) }],
    });
  }
}

/* ---------- Document ---------- */

export function renderPdf(data) {
  const { cover, blocks, financial, labels } = buildDocument(data);
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margins: M, bufferPages: true, info: { Title: cover.title, Author: 'ALTIORA', Subject: cover.kicker } });
    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
    for (const [name, file] of Object.entries(FONTS)) doc.registerFont(name, file);
    glyphFont = doc.font('Body')._font?.font ?? null;

    const x = M.left;
    const width = doc.page.width - M.left - M.right;

    /* Couverture */
    doc.rect(0, 0, doc.page.width, 330).fillColor(C.ink).fill();
    doc.rect(0, 330, doc.page.width, 5).fillColor(C.gold).fill();
    doc.font('Body-Bold').fontSize(12).fillColor('#F5B83D').text(cover.kicker, x, 150, { width });
    doc.font('Head').fontSize(32).fillColor('#FFFFFF').text(cover.title, x, doc.y + 12, { width, lineGap: 4 });
    doc.font('Body').fontSize(14).fillColor('#C9D6E0').text(cover.subtitle, x, doc.y + 14, { width });
    doc.font('Body').fontSize(10).fillColor(C.soft).text(cover.date, x, 380, { width });
    doc.addPage(); // page réservée au sommaire, remplie à la fin quand on connaît les numéros de page
    doc.addPage();

    /* Contenu */
    const toc = [];
    const renderBlocks = (list, level = 0) => {
      for (const b of list) {
        switch (b.type) {
          case 'sectionTitle':
            if (b.pageBreak) doc.addPage();
            else ensureSpace(doc, 90);
            doc.y += level === 0 ? 10 : 4;
            toc.push({ text: clean(b.text), page: doc.bufferedPageRange().count });
            doc.font('Head').fontSize(19).fillColor(C.ink).text(clean(b.text), x, doc.y, { width });
            doc.lineWidth(1.5).strokeColor(C.accent).moveTo(x, doc.y + 3).lineTo(x + 46, doc.y + 3).stroke();
            doc.y += 12;
            break;
          case 'heading': {
            ensureSpace(doc, 60);
            const d = b.depth;
            doc.y += 6;
            if (d <= 3) writeRuns(doc, b.runs, { x, width, size: 13, color: C.accent, font: 'HeadSemi', lineGap: 2 });
            else writeRuns(doc, b.runs, { x, width, size: 11, color: C.ink, bold: true, lineGap: 2 });
            doc.y += 4;
            break;
          }
          case 'paragraph':
            ensureSpace(doc, 30);
            writeRuns(doc, b.runs, { x: x + level * 14, width: width - level * 14 });
            doc.y += 6;
            break;
          case 'list':
            b.items.forEach((item, i) => {
              ensureSpace(doc, 34);
              const ix = x + level * 16;
              const y0 = doc.y;
              doc.font('Body').fontSize(10.5).fillColor(C.accent).text(b.ordered ? `${i + 1}.` : '•', ix, y0, { width: 16, lineBreak: false });
              doc.y = y0;
              writeRuns(doc, item.runs, { x: ix + 16, width: width - level * 16 - 16 });
              doc.y += 2;
              if (item.children.length) renderBlocks(item.children, level + 1);
            });
            doc.y += 4;
            break;
          case 'table':
            drawTable(doc, b, { x, width });
            break;
          case 'quote':
            renderBlocks(b.blocks, level + 1);
            break;
          case 'hr':
            doc.lineWidth(0.5).strokeColor(C.line).moveTo(x, doc.y + 4).lineTo(x + width, doc.y + 4).stroke();
            doc.y += 12;
            break;
          case 'code':
            doc.font('Body').fontSize(9).fillColor(C.soft).text(clean(b.text), x + 8, doc.y, { width: width - 16 });
            doc.y += 6;
            break;
          case 'chart':
            drawChart(doc, b, financial, x, width, labels);
            break;
          default:
            break;
        }
      }
    };
    renderBlocks(blocks);

    /* Sommaire (page 2) */
    doc.switchToPage(1);
    doc.font('Head').fontSize(24).fillColor(C.ink).text(labels.toc, x, M.top, { width, lineBreak: false });
    doc.lineWidth(1.5).strokeColor(C.accent).moveTo(x, M.top + 34).lineTo(x + 46, M.top + 34).stroke();
    let ty = M.top + 64;
    for (const entry of toc) {
      doc.font('Body').fontSize(11.5).fillColor(C.text).text(entry.text, x, ty, { width: width - 50, lineBreak: false, ellipsis: true });
      doc.font('Body-Bold').fontSize(11.5).fillColor(C.ink).text(String(entry.page), x, ty, { width, align: 'right', lineBreak: false });
      doc.lineWidth(0.5).strokeColor(C.line).moveTo(x, ty + 20).lineTo(x + width, ty + 20).stroke();
      ty += 30;
    }

    /* Pieds de page */
    const range = doc.bufferedPageRange();
    for (let i = 1; i < range.count; i++) {
      doc.switchToPage(i);
      const bottom = doc.page.margins.bottom;
      doc.page.margins.bottom = 0; // évite qu'un texte en pied de page déclenche une nouvelle page
      doc.font('Body').fontSize(8).fillColor(C.soft);
      doc.text(cover.title, x, doc.page.height - 40, { width: width - 80, lineBreak: false });
      doc.text(`${labels.page} ${i + 1} / ${range.count}`, x, doc.page.height - 40, { width, align: 'right', lineBreak: false });
      doc.page.margins.bottom = bottom;
    }
    doc.end();
  });
}
