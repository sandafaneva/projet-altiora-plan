import {
  AlignmentType, Bookmark, BorderStyle, Document, Footer, Header, HeadingLevel, InternalHyperlink, LevelFormat, Packer, PageNumber, Paragraph,
  ShadingType, Table, TableLayoutType, TableRow, TableCell, TextRun, VerticalAlign, WidthType,
} from 'docx';
import { runsText } from './markdown.js';
import { buildDocument } from './blocks.js';

const INK = '0E1A3A';
const ACCENT = '315EFB';
const LINE = 'DDE3EF';
const WASH = 'EEF2FF';
const FONT = 'Calibri';
const CONTENT_WIDTH = 9300; // A4, marges de 1 300 twips

const HEADINGS = { 3: HeadingLevel.HEADING_2, 4: HeadingLevel.HEADING_3 };

function textRuns(runs, base = {}) {
  const out = [];
  for (const r of runs) {
    const parts = r.text.split('\n');
    parts.forEach((part, i) => {
      out.push(new TextRun({
        text: part, break: i > 0 ? 1 : undefined, bold: r.bold || base.bold, italics: r.italic || base.italics,
        font: r.code ? 'Consolas' : base.font, size: base.size, color: base.color,
      }));
    });
  }
  return out;
}

function columnWidths(block, total) {
  const n = block.header.length;
  if (block.widths) return block.widths.map((f) => Math.round(f * total));
  if (block.firstColWidth) {
    const first = Math.round(block.firstColWidth * total);
    const rest = Math.floor((total - first) / (n - 1));
    return [first, ...Array(n - 1).fill(rest)];
  }
  // Largeur proportionnelle au contenu, avec un minimum
  const weight = block.header.map((h, c) => Math.max(6, runsText(h).length, ...block.rows.map((r) => Math.min(60, runsText(r[c] || []).length))));
  const sum = weight.reduce((a, b) => a + b, 0);
  const min = 900;
  const raw = weight.map((w) => Math.max(min, Math.round((w / sum) * total)));
  const scale = total / raw.reduce((a, b) => a + b, 0);
  return raw.map((w) => Math.floor(w * scale));
}

const ALIGN = { left: AlignmentType.LEFT, right: AlignmentType.RIGHT, center: AlignmentType.CENTER };
const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: LINE };

function renderTable(block) {
  const widths = columnWidths(block, CONTENT_WIDTH);
  const size = block.compact ? 17 : 19;
  const mk = (runs, i, { header = false } = {}) =>
    new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      verticalAlign: VerticalAlign.CENTER,
      margins: { top: 50, bottom: 50, left: 90, right: 90 },
      shading: header ? { type: ShadingType.CLEAR, fill: WASH, color: 'auto' } : undefined,
      children: [new Paragraph({ alignment: ALIGN[block.align[i]] || AlignmentType.LEFT, spacing: { after: 0, line: 250 }, children: textRuns(runs, { size, bold: header, color: header ? INK : undefined }) })],
    });
  return new Table({
    width: { size: CONTENT_WIDTH, type: WidthType.DXA },
    columnWidths: widths,
    layout: TableLayoutType.FIXED,
    borders: { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder, insideHorizontal: cellBorder, insideVertical: cellBorder },
    rows: [
      new TableRow({ tableHeader: true, cantSplit: true, children: block.header.map((h, i) => mk(h, i, { header: true })) }),
      ...block.rows.map((r) => new TableRow({ cantSplit: true, children: r.map((c, i) => mk(c, i)) })),
    ],
  });
}

export async function renderDocx(data) {
  const { cover, blocks, labels } = buildDocument(data);
  const numberedLists = [];
  let titleCount = 0; // chaque titre de section reçoit un signet : le sommaire y renvoie
  const titles = blocks.filter((b) => b.type === 'sectionTitle').map((b, i) => ({ id: `sec${i}`, text: b.text }));

  function render(list, { level = 0 } = {}) {
    const out = [];
    for (const b of list) {
      switch (b.type) {
        case 'sectionTitle':
          out.push(new Paragraph({
            heading: HeadingLevel.HEADING_1, pageBreakBefore: Boolean(b.pageBreak) || titleCount === 0,
            children: [new Bookmark({ id: titles[titleCount].id, children: [new TextRun(b.text)] })],
          }));
          titleCount += 1;
          break;
        case 'heading':
          out.push(new Paragraph({ heading: HEADINGS[b.depth] || HeadingLevel.HEADING_3, children: textRuns(b.runs) }));
          break;
        case 'paragraph':
          out.push(new Paragraph({ spacing: { after: 120, line: 300 }, indent: level ? { left: 360 * level } : undefined, children: textRuns(b.runs) }));
          break;
        case 'list': {
          let reference = 'bullets';
          if (b.ordered) {
            reference = `numbered-${numberedLists.length}`;
            numberedLists.push(reference);
          }
          for (const item of b.items) {
            out.push(new Paragraph({ numbering: { reference, level: Math.min(level, 2) }, spacing: { after: 60, line: 290 }, children: textRuns(item.runs) }));
            out.push(...render(item.children, { level: level + 1 }));
          }
          out.push(new Paragraph({ spacing: { after: 60 }, children: [] }));
          break;
        }
        case 'table':
          out.push(renderTable(b));
          out.push(new Paragraph({ spacing: { after: 160 }, children: [] }));
          break;
        case 'quote':
          for (const q of render(b.blocks)) out.push(q);
          break;
        case 'hr':
          out.push(new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: LINE, space: 1 } }, spacing: { after: 160 }, children: [] }));
          break;
        case 'code':
          out.push(new Paragraph({ shading: { type: ShadingType.CLEAR, fill: 'F3F5F7', color: 'auto' }, spacing: { after: 120 }, children: [new TextRun({ text: b.text, font: 'Consolas', size: 18 })] }));
          break;
        case 'chart':
          break; // les graphiques sont dans le PDF ; le Word contient les tables correspondantes
        default:
          break;
      }
    }
    return out;
  }

  const body = render(blocks);

  const levels = (fmt) => [0, 1, 2].map((level) => ({
    level,
    format: fmt === 'bullet' ? LevelFormat.BULLET : LevelFormat.DECIMAL,
    text: fmt === 'bullet' ? ['•', '–', '·'][level] : `%${level + 1}.`,
    alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 540 + level * 360, hanging: 300 } } },
  }));

  const doc = new Document({
    creator: 'ALTIORA',
    title: cover.title,
    description: cover.kicker,
    styles: {
      default: { document: { run: { font: FONT, size: 22, color: '1E2B37' } } },
      paragraphStyles: [
        { id: 'Title', name: 'Title', basedOn: 'Normal', next: 'Normal', run: { font: FONT, size: 60, bold: true, color: INK }, paragraph: { spacing: { after: 200 } } },
        { id: 'Heading1', name: 'heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 34, bold: true, color: INK }, paragraph: { spacing: { before: 420, after: 160 }, keepNext: true, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: ACCENT, space: 4 } } } },
        { id: 'Heading2', name: 'heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 26, bold: true, color: ACCENT }, paragraph: { spacing: { before: 280, after: 100 }, keepNext: true } },
        { id: 'Heading3', name: 'heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 23, bold: true, color: INK }, paragraph: { spacing: { before: 200, after: 80 }, keepNext: true } },
      ],
    },
    numbering: {
      config: [
        { reference: 'bullets', levels: levels('bullet') },
        ...numberedLists.map((reference) => ({ reference, levels: levels('decimal') })),
      ],
    },
    sections: [{
      properties: {
        titlePage: true,
        page: { size: { width: 11906, height: 16838 }, margin: { top: 1300, bottom: 1200, left: 1300, right: 1300 } },
      },
      headers: {
        default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: cover.title, size: 17, color: '6B7C8A' })] })] }),
        first: new Header({ children: [new Paragraph({ children: [] })] }),
      },
      footers: {
        default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [`${labels.page} `, PageNumber.CURRENT, ' / ', PageNumber.TOTAL_PAGES], size: 17, color: '6B7C8A' })] })] }),
        first: new Footer({ children: [new Paragraph({ children: [] })] }),
      },
      children: [
        new Paragraph({ spacing: { before: 2600, after: 200 }, children: [new TextRun({ text: cover.kicker, size: 26, color: ACCENT, bold: true })] }),
        new Paragraph({ style: 'Title', children: [new TextRun(cover.title)] }),
        new Paragraph({ spacing: { after: 200 }, border: { top: { style: BorderStyle.SINGLE, size: 12, color: ACCENT, space: 12 } }, children: [new TextRun({ text: cover.subtitle, size: 28, color: '4A5F70' })] }),
        new Paragraph({ spacing: { before: 2400 }, children: [new TextRun({ text: cover.date, size: 20, color: '6B7C8A' })] }),
        new Paragraph({ pageBreakBefore: true, spacing: { after: 240 }, children: [new TextRun({ text: labels.toc, bold: true, size: 40, color: INK, font: 'Calibri' })] }),
        ...titles.map((t) => new Paragraph({
          spacing: { after: 140 },
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: LINE, space: 4 } },
          children: [new InternalHyperlink({ anchor: t.id, children: [new TextRun({ text: t.text, color: INK, size: 24 })] })],
        })),
        ...body,
      ],
    }],
  });

  return Buffer.from(await Packer.toBuffer(doc));
}
