// Markdown -> petit arbre de blocs, partagé par les exports Word et PDF.
import { marked } from 'marked';

/** Texte en ligne -> suites de segments { text, bold, italic, code }. */
export function inline(tokens = [], style = {}) {
  const runs = [];
  for (const t of tokens) {
    switch (t.type) {
      case 'strong': runs.push(...inline(t.tokens, { ...style, bold: true })); break;
      case 'em': runs.push(...inline(t.tokens, { ...style, italic: true })); break;
      case 'del': runs.push(...inline(t.tokens, style)); break;
      case 'link': runs.push(...inline(t.tokens, style)); break;
      case 'codespan': runs.push({ ...style, text: t.text, code: true }); break;
      case 'br': runs.push({ ...style, text: '\n' }); break;
      case 'html': break; // balises HTML ignorées
      case 'image': if (t.text) runs.push({ ...style, text: t.text }); break;
      default:
        if (t.tokens?.length) runs.push(...inline(t.tokens, style));
        else if (t.text) runs.push({ ...style, text: t.text });
    }
  }
  return runs;
}

export const runsText = (runs) => runs.map((r) => r.text).join('');

/** Jetons Markdown -> blocs : heading, paragraph, list, table, quote, hr, code. */
export function blocks(tokens = []) {
  const out = [];
  for (const t of tokens) {
    switch (t.type) {
      case 'heading': out.push({ type: 'heading', depth: t.depth, runs: inline(t.tokens) }); break;
      case 'paragraph':
      case 'text': out.push({ type: 'paragraph', runs: inline(t.tokens || [{ type: 'text', text: t.text }]) }); break;
      case 'list':
        out.push({
          type: 'list',
          ordered: t.ordered,
          items: t.items.map((it) => {
            const first = it.tokens.find((x) => x.type === 'text' || x.type === 'paragraph');
            const rest = it.tokens.filter((x) => x !== first && x.type !== 'space');
            return { runs: first ? inline(first.tokens || [{ type: 'text', text: first.text }]) : [], children: blocks(rest) };
          }),
        });
        break;
      case 'table':
        out.push({
          type: 'table',
          align: t.align.map((a) => a || 'left'),
          header: t.header.map((c) => inline(c.tokens)),
          rows: t.rows.map((r) => r.map((c) => inline(c.tokens))),
        });
        break;
      case 'blockquote': out.push({ type: 'quote', blocks: blocks(t.tokens) }); break;
      case 'hr': out.push({ type: 'hr' }); break;
      case 'code': out.push({ type: 'code', text: t.text }); break;
      default: break; // space, html
    }
  }
  return out;
}

export const parseMarkdown = (md) => blocks(marked.lexer(String(md || '')));
