import { pool, query, parseJson } from '../db/pool.js';
import { env } from '../config/env.js';
import { HttpError } from '../utils/http.js';
import { planOutline } from './agents/planner.js';
import { buildMetaPrompt } from './agents/metaPrompt.js';
import { writeSection } from './agents/redacteur.js';
import { analyzeSection, reviewWholePlan } from './agents/analyste.js';
import { buildExecutionPlan, reviewProgress } from './agents/suivi.js';
import { suggestAssumptions } from './agents/financier.js';
import { computeFinancials, parseAssumptions, assumptionsHash } from './finance/model.js';
import { annexMarkdown, financialContextBlock, financeTables } from './finance/format.js';
import { getLang } from '../utils/lang.js';
import { sectionTitleFor, stripLeadingTitle, tt } from './labels.js';

/* ------------------------------------------------------------------ */
/* Accès aux données                                                   */
/* ------------------------------------------------------------------ */

const hydratePlan = (r) => ({ ...r, outline: parseJson(r.outline), final_review: parseJson(r.final_review), financial_assumptions: parseJson(r.financial_assumptions) });
const hydrateSection = (r) => ({ ...r, key_points: parseJson(r.key_points, []), analysis: parseJson(r.analysis) });

async function getPlan(planId, userId) {
  const rows = await query('SELECT * FROM business_plans WHERE id = ? AND user_id = ?', [planId, userId]);
  if (!rows.length) throw new HttpError(404, 'Business plan introuvable');
  return hydratePlan(rows[0]);
}

async function getSections(planId) {
  const rows = await query('SELECT * FROM plan_sections WHERE plan_id = ? ORDER BY position', [planId]);
  return rows.map(hydrateSection);
}

function pickSection(sections, key) {
  const section = sections.find((s) => s.section_key === key);
  if (!section) throw new HttpError(404, 'Section introuvable');
  return section;
}

const touchPlan = (planId) => query('UPDATE business_plans SET updated_at = CURRENT_TIMESTAMP WHERE id = ?', [planId]);

function assertEditable(plan) {
  if (plan.status === 'executing') {
    throw new HttpError(409, "Le business plan est en cours d'exécution : la rédaction est verrouillée.");
  }
}

/** Si le plan était déjà généré et qu'une section change, le document final n'est plus valable. */
async function reopenIfGenerated(plan) {
  if (plan.status === 'generated') {
    await query("UPDATE business_plans SET status = 'drafting', final_document = NULL, final_review = NULL, final_generated_at = NULL WHERE id = ?", [plan.id]);
  }
}

/* ------------------------------------------------------------------ */
/* Modèle financier (moteur de calcul en code)                         */
/* ------------------------------------------------------------------ */

// Sections rédigées par l'IA à partir des chiffres du moteur
const FINANCIAL_SECTIONS = ['plan_financier', 'resume_executif'];

/** Hypothèses enregistrées, résultats calculés et empreinte (null si le modèle n'est pas renseigné). */
function financialState(plan) {
  if (!plan.financial_assumptions) return null;
  const assumptions = parseAssumptions(plan.financial_assumptions);
  const results = computeFinancials(assumptions);
  return { assumptions, results, hash: assumptionsHash(assumptions), block: financialContextBlock(assumptions, results) };
}

/** Sections rédigées avec d'anciens chiffres : à régénérer après un changement d'hypothèses. */
function staleFinancialSections(plan, sections) {
  const fin = financialState(plan);
  if (!fin) return [];
  return sections
    .filter((s) => FINANCIAL_SECTIONS.includes(s.section_key) && s.content && s.financials_hash !== fin.hash)
    .map((s) => ({ key: s.section_key, title: s.title }));
}

const financialsPayload = (plan, sections) => {
  const fin = financialState(plan);
  return {
    defined: Boolean(fin),
    assumptions: fin?.assumptions ?? null,
    results: fin?.results ?? null,
    tables: fin ? financeTables(fin.assumptions, fin.results, getLang()) : null,
    stale_sections: staleFinancialSections(plan, sections),
  };
};

export async function getFinancials(userId, planId) {
  const plan = await getPlan(planId, userId);
  return financialsPayload(plan, await getSections(planId));
}

/** Calcul à la volée (aperçu pendant la saisie) : rien n'est enregistré. */
export function previewFinancials(input) {
  const assumptions = parseAssumptions(input);
  const results = computeFinancials(assumptions);
  return { assumptions, results, tables: financeTables(assumptions, results, getLang()) };
}

export async function saveFinancials(userId, planId, input) {
  const plan = await getPlan(planId, userId);
  assertEditable(plan);
  const assumptions = parseAssumptions(input); // valide et complète les valeurs par défaut
  await query('UPDATE business_plans SET financial_assumptions = ? WHERE id = ?', [JSON.stringify(assumptions), planId]);
  await reopenIfGenerated(plan); // le document final contient l'annexe chiffrée : il doit être régénéré
  await touchPlan(planId);
  return getFinancials(userId, planId);
}

/** L'IA lit le plan et propose seulement les valeurs déjà écrites ; l'utilisateur les vérifie. */
export async function suggestFinancials(userId, planId) {
  const plan = await getPlan(planId, userId);
  assertEditable(plan);
  const sections = await getSections(planId);
  const { suggestions, found, missing } = await suggestAssumptions({ plan, sections });
  return { suggestions, found, missing };
}

/* ------------------------------------------------------------------ */
/* Création (R3, R4, R9)                                               */
/* ------------------------------------------------------------------ */

export async function createPlan(userId, input) {
  // L'agent de planification prépare la structure adaptée au projet
  const outline = await planOutline(input);

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [res] = await conn.execute(
      'INSERT INTO business_plans (user_id, title, idea, sector, target_clients, outline) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, outline.title, input.idea, input.sector, input.target_clients, JSON.stringify({ summary: outline.summary, stale: outline.fallback })],
    );
    const planId = res.insertId;
    for (const s of outline.sections) {
      await conn.execute(
        'INSERT INTO plan_sections (plan_id, section_key, title, objective, key_points, suggested_prompt, position) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [planId, s.key, s.title, s.objective, JSON.stringify(s.key_points), s.suggested_prompt, s.position],
      );
    }
    await conn.commit();
    return planId;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

export async function listPlans(userId) {
  return query(
    `SELECT p.id, p.title, p.sector, p.status, p.created_at, p.updated_at,
       (SELECT COUNT(*) FROM plan_sections s WHERE s.plan_id = p.id) AS sections_total,
       (SELECT COUNT(*) FROM plan_sections s WHERE s.plan_id = p.id AND s.status = 'validated') AS sections_validated
     FROM business_plans p WHERE p.user_id = ? ORDER BY p.updated_at DESC`,
    [userId],
  );
}

export async function getPlanDetail(userId, planId) {
  const plan = await getPlan(planId, userId);
  const sections = await getSections(planId);
  return {
    plan,
    sections,
    validation_threshold: env.validationThreshold,
    financials: { defined: Boolean(plan.financial_assumptions), stale_sections: staleFinancialSections(plan, sections) },
  };
}

export async function deletePlan(userId, planId) {
  await getPlan(planId, userId);
  await query('DELETE FROM business_plans WHERE id = ?', [planId]);
}

/* ------------------------------------------------------------------ */
/* Boucle dynamique : prompt → méta-prompt → rédaction → analyse       */
/* (R6, R7, R8, R12, R13, R14, R15, R16)                               */
/* ------------------------------------------------------------------ */

async function nextVersion(sectionId) {
  const rows = await query('SELECT COALESCE(MAX(version), 0) + 1 AS v FROM prompt_iterations WHERE section_id = ?', [sectionId]);
  return Number(rows[0].v);
}

async function saveIteration({ plan, section, source, userPrompt, answers, metaPrompt, result, analysis, tokens }) {
  const version = await nextVersion(section.id);
  const res = await query(
    `INSERT INTO prompt_iterations (plan_id, section_id, version, source, user_prompt, answers, meta_prompt, result, analysis, score, tokens_used)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [plan.id, section.id, version, source, userPrompt ?? null, answers ? JSON.stringify(answers) : null, metaPrompt ?? null, result, JSON.stringify(analysis), analysis.score, tokens ?? 0],
  );
  return { id: res.insertId, version };
}

async function applyResult({ plan, section, content, analysis }) {
  // Les sections chiffrées mémorisent l'empreinte des hypothèses utilisées (détection des chiffres périmés)
  const fin = FINANCIAL_SECTIONS.includes(section.section_key) ? financialState(plan) : null;
  await query('UPDATE plan_sections SET content = ?, score = ?, analysis = ?, status = ?, financials_hash = ? WHERE id = ?', [
    content,
    analysis.score,
    JSON.stringify(analysis),
    'in_progress',
    fin ? fin.hash : null,
    section.id,
  ]);
  await reopenIfGenerated(plan);
  await touchPlan(plan.id);
}

/** Le mpampiasa dia manoratra prompt → l'IA rédige la section → l'analyste note et guide. */
export async function generateSection(userId, planId, key, input) {
  const plan = await getPlan(planId, userId);
  assertEditable(plan);
  const sections = await getSections(planId);
  const section = pickSection(sections, key);
  const others = sections.filter((s) => s.section_key !== key);

  const userPrompt = (input.prompt || '').trim() || section.suggested_prompt || section.objective;
  const answers = (input.answers || []).filter((a) => a.answer && a.answer.trim());

  // Les chiffres viennent du moteur de calcul : l'IA les explique, elle ne les invente pas
  const financials = FINANCIAL_SECTIONS.includes(key) ? financialState(plan)?.block : undefined;

  // 1. Méta-prompt (caché à l'utilisateur)
  const meta = await buildMetaPrompt({
    plan, section, others, userPrompt, answers,
    previousContent: section.content, previousAnalysis: section.analysis, financials,
  });
  // 2. Agent rédacteur
  const written = await writeSection({ plan, section, others, metaPrompt: meta.metaPrompt, previousContent: section.content, financials });
  // 3. Agent analyste / guide (séparé du rédacteur)
  const analyzed = await analyzeSection({ plan, section, others, content: written.content, financials });

  const iteration = await saveIteration({
    plan, section, source: 'ai', userPrompt, answers, metaPrompt: meta.metaPrompt,
    result: written.content, analysis: analyzed.analysis,
    tokens: meta.tokens + written.tokens + analyzed.tokens,
  });
  await applyResult({ plan, section, content: written.content, analysis: analyzed.analysis });

  const updated = pickSection(await getSections(planId), key);
  return { section: updated, iteration };
}

/** Modification manuelle par l'utilisateur, puis ré-analyse. */
export async function saveManualContent(userId, planId, key, content) {
  const plan = await getPlan(planId, userId);
  assertEditable(plan);
  const sections = await getSections(planId);
  const section = pickSection(sections, key);
  const others = sections.filter((s) => s.section_key !== key);

  const financials = FINANCIAL_SECTIONS.includes(key) ? financialState(plan)?.block : undefined;
  const analyzed = await analyzeSection({ plan, section, others, content, financials });
  const iteration = await saveIteration({
    plan, section, source: 'manual', result: content, analysis: analyzed.analysis, tokens: analyzed.tokens,
  });
  await applyResult({ plan, section, content, analysis: analyzed.analysis });

  return { section: pickSection(await getSections(planId), key), iteration };
}

export async function listIterations(userId, planId, key) {
  await getPlan(planId, userId);
  const section = pickSection(await getSections(planId), key);
  // Le méta-prompt n'est volontairement pas renvoyé : il reste dans les coulisses (R7)
  return query(
    'SELECT id, version, source, user_prompt, result, score, created_at FROM prompt_iterations WHERE section_id = ? ORDER BY version DESC',
    [section.id],
  );
}

export async function restoreIteration(userId, planId, key, iterationId) {
  const plan = await getPlan(planId, userId);
  assertEditable(plan);
  const section = pickSection(await getSections(planId), key);
  const rows = await query('SELECT * FROM prompt_iterations WHERE id = ? AND section_id = ?', [iterationId, section.id]);
  if (!rows.length) throw new HttpError(404, 'Version introuvable');
  const it = rows[0];
  const analysis = parseJson(it.analysis) || { score: it.score ?? 0, verdict: '', points_forts: [], manques: [], questions_guidees: [], suggestion_prompt: '', incoherences: [] };

  await saveIteration({ plan, section, source: 'restore', userPrompt: `Restauration de la version ${it.version}`, result: it.result, analysis, tokens: 0 });
  await applyResult({ plan, section, content: it.result, analysis });
  return { section: pickSection(await getSections(planId), key) };
}

/* ------------------------------------------------------------------ */
/* Validation des sections                                             */
/* ------------------------------------------------------------------ */

export async function validateSection(userId, planId, key, force) {
  const plan = await getPlan(planId, userId);
  assertEditable(plan);
  const section = pickSection(await getSections(planId), key);
  if (!section.content || !section.content.trim()) {
    throw new HttpError(409, "Rédigez d'abord la section avant de la valider.");
  }
  const score = section.score ?? 0;
  if (score < env.validationThreshold && !force) {
    throw new HttpError(409, `Score insuffisant (${score}/${env.validationThreshold}).`, { score, threshold: env.validationThreshold });
  }
  await query("UPDATE plan_sections SET status = 'validated' WHERE id = ?", [section.id]);
  await touchPlan(planId);
  return { section: pickSection(await getSections(planId), key) };
}

export async function unvalidateSection(userId, planId, key) {
  const plan = await getPlan(planId, userId);
  assertEditable(plan);
  const section = pickSection(await getSections(planId), key);
  await query("UPDATE plan_sections SET status = 'in_progress' WHERE id = ?", [section.id]);
  await reopenIfGenerated(plan);
  await touchPlan(planId);
  return { section: pickSection(await getSections(planId), key) };
}

/* ------------------------------------------------------------------ */
/* Génération finale (R15)                                             */
/* ------------------------------------------------------------------ */

function assembleDocument(plan, sections, fin) {
  // Le résumé exécutif est rédigé en dernier mais placé en tête du document
  const ordered = [
    ...sections.filter((s) => s.section_key === 'resume_executif'),
    ...sections.filter((s) => s.section_key !== 'resume_executif'),
  ];
  const lang = getLang();
  const lines = [`# ${plan.title}`, '', `*${tt('sector')} : ${plan.sector}. ${tt('clients')} : ${plan.target_clients}.*`, ''];
  ordered.forEach((s, i) => lines.push(`## ${i + 1}. ${sectionTitleFor(s, lang)}`, '', stripLeadingTitle(s.content, s).trim(), ''));
  if (fin) lines.push(annexMarkdown(fin.assumptions, fin.results, lang));
  return lines.join('\n');
}

export async function finalizePlan(userId, planId) {
  const plan = await getPlan(planId, userId);
  if (plan.status === 'executing') throw new HttpError(409, "Le plan est déjà en cours d'exécution.");
  const sections = await getSections(planId);
  const missing = sections.filter((s) => s.status !== 'validated');
  if (missing.length) {
    throw new HttpError(409, `Sections à valider avant la génération : ${missing.map((s) => s.title).join(', ')}.`, {
      missing: missing.map((s) => s.section_key),
    });
  }

  // Les textes chiffrés doivent avoir été rédigés avec les hypothèses actuelles
  const stale = staleFinancialSections(plan, sections);
  if (stale.length) {
    throw new HttpError(409, `Les hypothèses financières ont changé depuis la rédaction de : ${stale.map((x) => x.title).join(', ')}. Régénérez ces sections avant de générer le plan.`, {
      stale_sections: stale.map((x) => x.key),
    });
  }
  const fin = financialState(plan);

  // Contrôle de cohérence entre toutes les sections (ne bloque pas la génération s'il échoue)
  let review = null;
  try {
    review = (await reviewWholePlan({ plan, sections, financials: fin?.block })).review;
  } catch (err) {
    console.warn('[final] contrôle de cohérence indisponible :', err.message);
  }

  const document = assembleDocument(plan, sections, fin);
  await query(
    "UPDATE business_plans SET status = 'generated', final_document = ?, final_review = ?, final_generated_at = NOW() WHERE id = ?",
    [document, review ? JSON.stringify(review) : null, planId],
  );
  return getPlanDetail(userId, planId);
}

/* ------------------------------------------------------------------ */
/* Modification du projet et re-planification (R9, R16)                */
/* ------------------------------------------------------------------ */

/** Modifie les 3 champs de départ. La planification devient « à mettre à jour » (outline.stale). */
export async function updatePlanInputs(userId, planId, input) {
  const plan = await getPlan(planId, userId);
  assertEditable(plan);
  const next = {
    idea: input.idea ?? plan.idea,
    sector: input.sector ?? plan.sector,
    target_clients: input.target_clients ?? plan.target_clients,
  };
  const changed = ['idea', 'sector', 'target_clients'].some((k) => next[k] !== plan[k]);
  if (changed) {
    await query('UPDATE business_plans SET idea = ?, sector = ?, target_clients = ?, outline = ? WHERE id = ?', [
      next.idea, next.sector, next.target_clients, JSON.stringify({ ...(plan.outline || {}), stale: true }), planId,
    ]);
    await reopenIfGenerated(plan);
    await touchPlan(planId);
  }
  return getPlanDetail(userId, planId);
}

/**
 * L'agent de planification refait le détail des sections non validées à partir du projet actuel.
 * Les sections déjà validées et leur contenu ne sont jamais écrasés.
 */
export async function replanPlan(userId, planId) {
  const plan = await getPlan(planId, userId);
  assertEditable(plan);
  const outline = await planOutline(plan);
  if (outline.fallback) throw new HttpError(502, "L'agent de planification n'a pas pu répondre. Réessayez dans un instant.");

  const sections = await getSections(planId);
  const kept = [];
  for (const s of outline.sections) {
    const existing = sections.find((x) => x.section_key === s.key);
    if (!existing) continue;
    if (existing.status === 'validated') {
      kept.push(existing.title);
      continue;
    }
    await query('UPDATE plan_sections SET objective = ?, key_points = ?, suggested_prompt = ? WHERE id = ?', [
      s.objective, JSON.stringify(s.key_points), s.suggested_prompt, existing.id,
    ]);
  }
  await query('UPDATE business_plans SET outline = ? WHERE id = ?', [JSON.stringify({ summary: outline.summary, stale: false }), planId]);
  await touchPlan(planId);
  return { ...(await getPlanDetail(userId, planId)), kept_validated: kept };
}

/* ------------------------------------------------------------------ */
/* Exécution et suivi (R10)                                            */
/* ------------------------------------------------------------------ */

const pad = (n) => String(n).padStart(2, '0');
export function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
const toUtc = (s) => {
  const [y, m, d] = s.split('-').map(Number);
  return Date.UTC(y, m - 1, d);
};
const addDays = (s, n) => {
  const d = new Date(toUtc(s) + n * 86_400_000);
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
};
const diffDays = (a, b) => Math.round((toUtc(a) - toUtc(b)) / 86_400_000);
const dueDateFromWeek = (start, week) => addDays(start, week * 7 - 1); // la semaine N se termine le jour 7N - 1
const weekFromDueDate = (start, due) => Math.max(1, Math.min(52, Math.ceil((diffDays(due, start) + 1) / 7)));

export function assertDate(value, label = 'Date') {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || addDays(value, 0) !== value) {
    throw new HttpError(400, `${label} invalide (format AAAA-MM-JJ).`);
  }
  return value;
}

async function getTasks(planId) {
  return query('SELECT * FROM plan_tasks WHERE plan_id = ? ORDER BY position, id', [planId]);
}

function decorate(task, today) {
  const overdue = task.status !== 'done' && Boolean(task.due_date) && task.due_date < today;
  return {
    ...task,
    is_overdue: overdue,
    days_late: overdue ? diffDays(today, task.due_date) : 0,
    days_left: task.due_date ? diffDays(task.due_date, today) : null,
  };
}

export async function startExecution(userId, planId, startDate) {
  const plan = await getPlan(planId, userId);
  if (plan.status === 'executing') throw new HttpError(409, "L'exécution a déjà démarré.");
  if (plan.status !== 'generated') throw new HttpError(409, "Générez d'abord le business plan final.");
  const start = startDate ? assertDate(startDate, 'Date de début') : todayStr();

  const sections = await getSections(planId);
  const { tasks } = await buildExecutionPlan({ plan, sections });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    for (const t of tasks) {
      await conn.execute(
        'INSERT INTO plan_tasks (plan_id, phase, title, description, kpi, target_value, due_week, due_date, position) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [planId, t.phase, t.title, t.description, t.kpi, t.target_value, t.due_week, t.due_week ? dueDateFromWeek(start, t.due_week) : null, t.position],
      );
    }
    await conn.execute("UPDATE business_plans SET status = 'executing', execution_start_date = ? WHERE id = ?", [start, planId]);
    await conn.commit();
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
  return getTracking(userId, planId);
}

function computeStats(tasks, today) {
  const phases = new Map();
  let progressSum = 0;
  let done = 0;
  let overdue = 0;
  let dueSoon = 0;
  let planned = 0;
  for (const t of tasks) {
    if (!phases.has(t.phase)) phases.set(t.phase, { phase: t.phase, total: 0, done: 0, sum: 0 });
    const p = phases.get(t.phase);
    p.total += 1;
    p.sum += t.progress;
    progressSum += t.progress;
    if (t.status === 'done') {
      p.done += 1;
      done += 1;
    }
    if (t.is_overdue) overdue += 1;
    if (t.status !== 'done' && t.days_left !== null && t.days_left >= 0 && t.days_left <= 7) dueSoon += 1;
    if (t.due_date && t.due_date <= today) planned += 1;
  }
  const total = tasks.length;
  const progress = total ? Math.round(progressSum / total) : 0;
  const plannedProgress = total ? Math.round((planned / total) * 100) : 0;
  const gap = progress - plannedProgress;
  return {
    total,
    done,
    overdue,
    due_soon: dueSoon,
    progress,
    planned_progress: plannedProgress, // part du plan qui devrait être terminée à la date du jour
    schedule: gap >= -5 ? 'on_track' : gap >= -20 ? 'at_risk' : 'late',
    by_phase: [...phases.values()].map((p) => ({ phase: p.phase, total: p.total, done: p.done, progress: Math.round(p.sum / p.total) })),
  };
}

export async function getTracking(userId, planId) {
  const plan = await getPlan(planId, userId);
  const today = todayStr();
  const tasks = (await getTasks(planId)).map((t) => decorate(t, today));
  const reviews = await query('SELECT review, created_at FROM tracking_reviews WHERE plan_id = ? ORDER BY id DESC LIMIT 1', [planId]);

  return {
    plan_status: plan.status,
    start_date: plan.execution_start_date,
    today,
    tasks,
    stats: computeStats(tasks, today),
    alerts: tasks.filter((t) => t.is_overdue).sort((a, b) => b.days_late - a.days_late).slice(0, 8),
    last_review: reviews.length ? { ...parseJson(reviews[0].review, {}), created_at: reviews[0].created_at } : null,
  };
}

async function assertExecuting(userId, planId) {
  const plan = await getPlan(planId, userId);
  if (plan.status !== 'executing') throw new HttpError(409, "Le suivi n'est pas démarré pour ce plan.");
  return plan;
}

export async function createTask(userId, planId, input) {
  const plan = await assertExecuting(userId, planId);
  const start = plan.execution_start_date || todayStr();
  let dueDate = input.due_date || null;
  let dueWeek = input.due_week ?? null;
  if (dueDate) {
    assertDate(dueDate, "Date d'échéance");
    dueWeek = weekFromDueDate(start, dueDate);
  } else if (dueWeek) {
    dueDate = dueDateFromWeek(start, dueWeek);
  }
  const pos = await query('SELECT COALESCE(MAX(position), 0) + 1 AS p FROM plan_tasks WHERE plan_id = ?', [planId]);
  const res = await query(
    `INSERT INTO plan_tasks (plan_id, phase, title, description, kpi, target_value, due_week, due_date, position, source)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'manual')`,
    [planId, input.phase, input.title, input.description ?? null, input.kpi ?? null, input.target_value ?? null, dueWeek, dueDate, Number(pos[0].p)],
  );
  await touchPlan(planId);
  const rows = await query('SELECT * FROM plan_tasks WHERE id = ?', [res.insertId]);
  return decorate(rows[0], todayStr());
}

export async function updateTask(userId, planId, taskId, patch) {
  const plan = await assertExecuting(userId, planId);
  const rows = await query('SELECT * FROM plan_tasks WHERE id = ? AND plan_id = ?', [taskId, planId]);
  if (!rows.length) throw new HttpError(404, 'Tâche introuvable');
  const task = rows[0];
  const start = plan.execution_start_date || todayStr();

  // Statut et avancement restent cohérents entre eux
  let status = patch.status ?? task.status;
  let progress = patch.progress ?? task.progress;
  if (patch.status === 'done') progress = 100;
  if (patch.status === 'todo' && patch.progress === undefined) progress = 0;
  if (patch.progress !== undefined && patch.status === undefined) {
    if (progress >= 100) status = 'done';
    else if (progress > 0 && (status === 'todo' || status === 'done')) status = 'in_progress';
    else if (progress === 0 && status === 'in_progress') status = 'todo';
  }

  // Échéance : la date et la semaine restent cohérentes entre elles
  let dueDate = task.due_date;
  let dueWeek = task.due_week;
  if (patch.due_date !== undefined) {
    dueDate = patch.due_date ? assertDate(patch.due_date, "Date d'échéance") : null;
    dueWeek = dueDate ? weekFromDueDate(start, dueDate) : null;
  } else if (patch.due_week !== undefined) {
    dueWeek = patch.due_week;
    dueDate = dueWeek ? dueDateFromWeek(start, dueWeek) : null;
  }

  await query(
    `UPDATE plan_tasks SET phase = ?, title = ?, description = ?, kpi = ?, target_value = ?, note = ?,
       status = ?, progress = ?, due_week = ?, due_date = ? WHERE id = ?`,
    [
      patch.phase ?? task.phase, patch.title ?? task.title,
      patch.description !== undefined ? patch.description : task.description,
      patch.kpi !== undefined ? patch.kpi : task.kpi,
      patch.target_value !== undefined ? patch.target_value : task.target_value,
      patch.note !== undefined ? patch.note : task.note,
      status, progress, dueWeek, dueDate, taskId,
    ],
  );
  await touchPlan(planId);
  const updated = await query('SELECT * FROM plan_tasks WHERE id = ?', [taskId]);
  return decorate(updated[0], todayStr());
}

export async function deleteTask(userId, planId, taskId) {
  await assertExecuting(userId, planId);
  const res = await query('DELETE FROM plan_tasks WHERE id = ? AND plan_id = ?', [taskId, planId]);
  if (!res.affectedRows) throw new HttpError(404, 'Tâche introuvable');
  await touchPlan(planId);
}

export async function reviewTracking(userId, planId) {
  const plan = await assertExecuting(userId, planId);
  const today = todayStr();
  const tasks = (await getTasks(planId)).map((t) => decorate(t, today));
  if (!tasks.length) throw new HttpError(409, "Ajoutez d'abord des tâches au plan de suivi.");
  const { review } = await reviewProgress({ plan, tasks, today, stats: computeStats(tasks, today) });
  await query('INSERT INTO tracking_reviews (plan_id, review) VALUES (?, ?)', [planId, JSON.stringify(review)]);
  return review;
}

/* ------------------------------------------------------------------ */
/* Données pour les exports Word et PDF                                */
/* ------------------------------------------------------------------ */

export async function getExportData(userId, planId) {
  const plan = await getPlan(planId, userId);
  if (plan.status === 'drafting' || !plan.final_document) {
    throw new HttpError(409, "Générez d'abord le business plan final pour pouvoir l'exporter.");
  }
  const sections = await getSections(planId);
  const ordered = [
    ...sections.filter((s) => s.section_key === 'resume_executif'),
    ...sections.filter((s) => s.section_key !== 'resume_executif'),
  ];
  const fin = financialState(plan);
  const today = todayStr();
  const tasks = plan.status === 'executing' ? (await getTasks(planId)).map((t) => decorate(t, today)) : null;
  return {
    plan,
    sections: ordered,
    financial: fin ? { assumptions: fin.assumptions, results: fin.results, tables: financeTables(fin.assumptions, fin.results, getLang()) } : null,
    review: plan.final_review,
    tasks,
    generatedAt: plan.final_generated_at || new Date(),
    lang: getLang(),
  };
}
