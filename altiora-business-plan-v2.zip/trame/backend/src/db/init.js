import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mysql from 'mysql2/promise';

const dir = path.dirname(fileURLToPath(import.meta.url));
const schema = fs.readFileSync(path.join(dir, '../../schema.sql'), 'utf8');
const dbName = process.env.DB_NAME || 'trame';

if (!/^[A-Za-z0-9_]+$/.test(dbName)) {
  console.error('DB_NAME invalide (lettres, chiffres et _ uniquement).');
  process.exit(1);
}

const conn = await mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  multipleStatements: true,
});

await conn.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
await conn.query(`USE \`${dbName}\``);
await conn.query(schema);
await conn.end();
console.log(`Base "${dbName}" prête.`);
