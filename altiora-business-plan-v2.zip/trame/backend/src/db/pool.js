import mysql from 'mysql2/promise';
import { env } from '../config/env.js';

export const pool = mysql.createPool({
  ...env.db,
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4',
  dateStrings: ['DATE'], // les colonnes DATE restent des textes AAAA-MM-JJ (pas de décalage de fuseau)
});

/** Exécute une requête préparée et renvoie les lignes (ou le ResultSetHeader pour INSERT/UPDATE). */
export async function query(sql, params = []) {
  const safe = params.map((p) => (p === undefined ? null : p));
  const [rows] = await pool.execute(sql, safe);
  return rows;
}

/** MySQL renvoie les colonnes JSON déjà parsées, MariaDB les renvoie en texte : on gère les deux. */
export function parseJson(value, fallback = null) {
  if (value === null || value === undefined) return fallback;
  if (typeof value === 'object') return value;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}
