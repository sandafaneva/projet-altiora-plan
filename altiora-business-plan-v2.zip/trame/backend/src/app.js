import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { env } from './config/env.js';
import authRoutes from './routes/auth.js';
import businessPlanRoutes from './routes/businessPlan.js';
import { errorHandler, notFound, asyncHandler } from './utils/http.js';
import { requireAuth } from './middleware/auth.js';
import { checkGroq } from './services/groq.js';
import { langMiddleware } from './utils/lang.js';

const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: env.clientOrigin, exposedHeaders: ['Content-Disposition'], allowedHeaders: ['Content-Type', 'Authorization', 'X-Lang'] }));
app.use(express.json({ limit: '200kb' }));
app.use(langMiddleware); // langue de l'interface (X-Lang) : fr ou mg

app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 600, standardHeaders: true, legacyHeaders: false }));
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 40,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Trop de tentatives, réessayez plus tard.' },
});

app.get('/api/health', (req, res) => res.json({ ok: true }));
// Diagnostic de la connexion Groq (clé valide, modèle disponible). N'expose jamais la clé.
app.get('/api/ai/status', requireAuth, asyncHandler(async (req, res) => res.json(await checkGroq({ deep: req.query.deep === '1' }))));
app.use('/api/auth', authLimiter, authRoutes);
// R1 : ce routeur se branche tel quel dans l'application existante
app.use('/api/business-plans', businessPlanRoutes);

app.use(notFound);
app.use(errorHandler);

export default app;
