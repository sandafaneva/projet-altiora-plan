-- Schéma MySQL 8 / MariaDB 10.5+ (utf8mb4).
-- Exécution : npm run db:init   (crée la base DB_NAME si besoin, puis les tables)

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Un business plan = les 3 champs saisis (R3/R4) + la structure préparée par l'agent de planification (R9)
CREATE TABLE IF NOT EXISTS business_plans (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(200) NOT NULL,
  idea TEXT NOT NULL,
  sector VARCHAR(160) NOT NULL,
  target_clients VARCHAR(255) NOT NULL,
  outline JSON NULL,
  financial_assumptions JSON NULL,
  status ENUM('drafting','generated','executing') NOT NULL DEFAULT 'drafting',
  final_document LONGTEXT NULL,
  final_review JSON NULL,
  final_generated_at DATETIME NULL,
  execution_start_date DATE NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_plan_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_plan_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sections du business plan : état courant (contenu, score, analyse, statut)
CREATE TABLE IF NOT EXISTS plan_sections (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  plan_id INT UNSIGNED NOT NULL,
  section_key VARCHAR(60) NOT NULL,
  title VARCHAR(160) NOT NULL,
  objective TEXT NULL,
  key_points JSON NULL,
  suggested_prompt TEXT NULL,
  position SMALLINT UNSIGNED NOT NULL,
  status ENUM('pending','in_progress','validated') NOT NULL DEFAULT 'pending',
  score TINYINT UNSIGNED NULL,
  content LONGTEXT NULL,
  analysis JSON NULL,
  financials_hash CHAR(40) NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_plan_section (plan_id, section_key),
  CONSTRAINT fk_section_plan FOREIGN KEY (plan_id) REFERENCES business_plans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Historique des itérations (peaufinage R8) : prompt saisi, méta-prompt caché (R7), résultat, analyse
CREATE TABLE IF NOT EXISTS prompt_iterations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  plan_id INT UNSIGNED NOT NULL,
  section_id INT UNSIGNED NOT NULL,
  version INT UNSIGNED NOT NULL,
  source ENUM('ai','manual','restore') NOT NULL DEFAULT 'ai',
  user_prompt TEXT NULL,
  answers JSON NULL,
  meta_prompt LONGTEXT NULL,
  result LONGTEXT NOT NULL,
  analysis JSON NULL,
  score TINYINT UNSIGNED NULL,
  tokens_used INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_iter_plan FOREIGN KEY (plan_id) REFERENCES business_plans(id) ON DELETE CASCADE,
  CONSTRAINT fk_iter_section FOREIGN KEY (section_id) REFERENCES plan_sections(id) ON DELETE CASCADE,
  INDEX idx_iter_section (section_id, version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exécution et suivi (R10)
CREATE TABLE IF NOT EXISTS plan_tasks (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  plan_id INT UNSIGNED NOT NULL,
  phase VARCHAR(160) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NULL,
  kpi VARCHAR(255) NULL,
  target_value VARCHAR(160) NULL,
  due_week SMALLINT UNSIGNED NULL,
  due_date DATE NULL,
  source ENUM('ai','manual') NOT NULL DEFAULT 'ai',
  position SMALLINT UNSIGNED NOT NULL,
  status ENUM('todo','in_progress','done','blocked') NOT NULL DEFAULT 'todo',
  progress TINYINT UNSIGNED NOT NULL DEFAULT 0,
  note TEXT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_task_plan FOREIGN KEY (plan_id) REFERENCES business_plans(id) ON DELETE CASCADE,
  INDEX idx_task_plan (plan_id, position)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS tracking_reviews (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  plan_id INT UNSIGNED NOT NULL,
  review JSON NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_review_plan FOREIGN KEY (plan_id) REFERENCES business_plans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
