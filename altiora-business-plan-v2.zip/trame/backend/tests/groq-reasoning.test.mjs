// Modèles à raisonnement (openai/gpt-oss-*) : paramètres envoyés, marge de tokens, réponses tronquées.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';

process.env.JWT_SECRET = 'x';
process.env.GROQ_API_KEY = 'test-key';
process.env.GROQ_BASE_URL = 'http://127.0.0.1:4905/v1';
process.env.GROQ_MODEL = 'openai/gpt-oss-120b';
process.env.GROQ_FALLBACK_MODEL = 'llama-3.1-8b-instant';
process.env.GROQ_REASONING_EFFORT = 'low';
const { chat, checkGroq } = await import('../src/services/groq.js');

const seen = [];
let handler;
const server = http.createServer((req, res) => {
  let raw = '';
  req.on('data', (c) => (raw += c));
  req.on('end', () => {
    const body = raw ? JSON.parse(raw) : {};
    seen.push(body);
    handler(req, res, body);
  });
});
await new Promise((r) => server.listen(4905, r));
test.after(() => server.close());

const send = (res, status, obj) => { res.writeHead(status, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };

test('gpt-oss : raisonnement masqué, effort bas et marge de tokens', async () => {
  seen.length = 0;
  handler = (req, res) => send(res, 200, { choices: [{ message: { content: 'ok' }, finish_reason: 'stop' }], usage: { total_tokens: 5 } });
  await chat({ system: 's', user: 'u', maxTokens: 1000 });
  assert.equal(seen[0].include_reasoning, false);
  assert.equal(seen[0].reasoning_effort, 'low');
  assert.equal(seen[0].max_completion_tokens, 2500, '1 000 demandés + 1 500 de marge pour le raisonnement');
});

test('modèle de secours non « raisonnement » : aucun paramètre de raisonnement envoyé', async () => {
  seen.length = 0;
  handler = (req, res, body) => (body.model.includes('gpt-oss')
    ? send(res, 400, { error: { message: 'model decommissioned', code: 'model_decommissioned' } })
    : send(res, 200, { choices: [{ message: { content: 'secours' }, finish_reason: 'stop' }], usage: {} }));
  const r = await chat({ system: 's', user: 'u', maxTokens: 1000 });
  assert.equal(r.content, 'secours');
  const fallbackBody = seen[seen.length - 1];
  assert.equal(fallbackBody.model, 'llama-3.1-8b-instant');
  assert.equal('include_reasoning' in fallbackBody, false);
  assert.equal('reasoning_effort' in fallbackBody, false);
  assert.equal(fallbackBody.max_completion_tokens, 1000);
});

test('réponse vide tronquée (raisonnement trop long) : bascule sur le modèle de secours', async () => {
  seen.length = 0;
  handler = (req, res, body) => (body.model.includes('gpt-oss')
    ? send(res, 200, { choices: [{ message: { content: '' }, finish_reason: 'length' }], usage: {} })
    : send(res, 200, { choices: [{ message: { content: 'reponse complete' }, finish_reason: 'stop' }], usage: {} }));
  const r = await chat({ system: 's', user: 'u' });
  assert.equal(r.content, 'reponse complete');
});

test('checkGroq avec gpt-oss : l\'appel de test JSON ne se fait plus étouffer par le raisonnement', async () => {
  handler = (req, res, body) => (req.url.endsWith('/models')
    ? send(res, 200, { data: [{ id: 'openai/gpt-oss-120b' }, { id: 'llama-3.1-8b-instant' }] })
    : send(res, 200, { choices: [{ message: { content: '{"ok": true}' }, finish_reason: 'stop' }], usage: {} }));
  seen.length = 0;
  const r = await checkGroq({ deep: true });
  assert.equal(r.model.available, true);
  assert.equal(r.json_test.ok, true);
  assert.ok(seen.find((b) => b.max_completion_tokens)?.max_completion_tokens >= 1500);
});
