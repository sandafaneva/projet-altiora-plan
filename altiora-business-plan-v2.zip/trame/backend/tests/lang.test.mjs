// Langue de l'interface (français / malgache) : alertes chiffrées, tableaux, annexe et consigne envoyée à l'IA.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';

process.env.JWT_SECRET = 'x';
process.env.GROQ_API_KEY = 'test-key';
process.env.GROQ_BASE_URL = 'http://127.0.0.1:4902/v1';
process.env.GROQ_FALLBACK_MODEL = '';
const { withLang, getLang, langMiddleware } = await import('../src/utils/lang.js');
const { computeFinancials } = await import('../src/services/finance/model.js');
const { annexMarkdown, financialContextBlock, buildFinancials } = await import('../src/services/finance/format.js');
const { parseAssumptions } = await import('../src/services/finance/model.js');
const { buildDocument } = await import('../src/services/export/blocks.js');
const { chat } = await import('../src/services/groq.js');
const { stripLeadingTitle } = await import('../src/services/labels.js');

const risky = parseAssumptions({ currency: 'Ar', horizon_months: 12, price_per_customer_month: 100, new_customers_per_month: 1, monthly_churn_pct: 5, payment_delay_days: 60, initial_funding: 0, fixed_costs: [{ label: 'Loyer', monthly_amount: 5000, start_month: 1 }] });

test('par défaut, la langue est le français', () => {
  assert.equal(getLang(), 'fr');
});

test('l\'en-tête X-Lang choisit la langue, une valeur inconnue retombe sur le français', () => {
  let seen;
  langMiddleware({ headers: { 'x-lang': 'mg' } }, {}, () => { seen = getLang(); });
  assert.equal(seen, 'mg');
  langMiddleware({ headers: { 'x-lang': 'xx' } }, {}, () => { seen = getLang(); });
  assert.equal(seen, 'fr');
});

test('alertes : un code et des valeurs, plus un texte dans la langue active', () => {
  const fr = computeFinancials(risky);
  assert.ok(fr.warning_items.some((w) => w.code === 'negative_cash' && w.params.currency === 'Ar'));
  assert.match(fr.warnings.join(' '), /trésorerie devient négative/);
  const mg = withLang('mg', () => computeFinancials(risky));
  assert.match(mg.warnings.join(' '), /tahiry ara-bola/);
  assert.deepEqual(mg.warning_items, fr.warning_items); // les données ne changent pas, seul le texte change
});

test('annexe et tableaux en malgache ; le contexte donné à l\'IA reste en français', () => {
  const results = computeFinancials(risky);
  assert.match(annexMarkdown(risky, results, 'mg'), /Fanampiny: modely ara-bola/);
  assert.match(annexMarkdown(risky, results, 'fr'), /Annexe : modèle financier/);
  assert.equal(buildFinancials(risky).tables.annual.head[1], 'Année 1');
  assert.equal(withLang('mg', () => buildFinancials(risky).tables.annual.head[1]), 'Taona 1');
  assert.match(withLang('mg', () => financialContextBlock(risky, results)), /HYPOTHÈSES/);
});

test('export : couverture, titres de section et libellés suivent la langue', () => {
  const fin = { ...buildFinancials(risky), assumptions: risky };
  const data = { plan: { title: 'X', sector: 'S', target_clients: 'C' }, sections: [{ section_key: 'risques', title: 'Risques et plan de mitigation', content: 'Texte' }], financial: fin, tasks: null };
  const mg = buildDocument({ ...data, lang: 'mg' });
  assert.equal(mg.cover.kicker, 'Drafitra ara-barotra');
  assert.equal(mg.blocks[0].text, '1. Loza mety hitranga sy fanalefahana azy');
  assert.equal(mg.labels.page, 'Pejy');
  const fr = buildDocument(data);
  assert.equal(fr.blocks[0].text, '1. Risques et plan de mitigation');
});

test('IA : la consigne « malgache » est ajoutée seulement quand la langue est mg', async () => {
  const systems = [];
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      systems.push(JSON.parse(raw).messages[0].content);
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ choices: [{ message: { content: 'ok' } }], usage: { total_tokens: 1 } }));
    });
  });
  await new Promise((r) => server.listen(4902, r));
  try {
    await chat({ system: 'BASE', user: 'u' });
    await withLang('mg', () => chat({ system: 'BASE', user: 'u' }));
  } finally {
    server.close();
  }
  assert.equal(systems[0], 'BASE');
  assert.match(systems[1], /malgache/);
  assert.ok(systems[1].startsWith('BASE'));
});

test('un titre répété au début du texte de la section est retiré, un autre titre est conservé', () => {
  const section = { section_key: 'marche_cibles', title: 'Marché et clients cibles' };
  assert.equal(stripLeadingTitle('### Marché et clients cibles\n\nTexte', section), 'Texte');
  assert.equal(stripLeadingTitle('## 3. Marché et clients cibles\nTexte', section), 'Texte');
  assert.equal(stripLeadingTitle('### Tsena sy mpanjifa kendrena\nTexte', section), 'Texte');
  assert.equal(stripLeadingTitle('### Segments visés\nTexte', section), '### Segments visés\nTexte');
});

test('export : un sommaire liste les titres, dans les deux langues', () => {
  const data = { plan: { title: 'X', sector: 'S', target_clients: 'C' }, sections: [{ section_key: 'risques', title: 'Risques', content: '### Risques et plan de mitigation\nTexte' }], financial: null, tasks: null };
  assert.equal(buildDocument(data).labels.toc, 'Sommaire');
  assert.equal(buildDocument({ ...data, lang: 'mg' }).labels.toc, 'Votoatiny');
  assert.ok(!buildDocument(data).blocks.some((b) => b.type === 'heading'), 'le titre répété est retiré du contenu');
});
