// Le moteur financier est vérifié sur des cas calculables à la main.
import test from 'node:test';
import assert from 'node:assert/strict';

process.env.JWT_SECRET = 'x';
const { computeFinancials, parseAssumptions, assumptionsHash } = await import('../src/services/finance/model.js');
const { annexMarkdown, financialContextBlock, fmtNum } = await import('../src/services/finance/format.js');

const base = {
  currency: 'EUR', horizon_months: 12, price_per_customer_month: 1000, new_customers_per_month: 10,
  fixed_costs: [{ label: 'Équipe', monthly_amount: 5000, start_month: 1 }], initial_funding: 20000, payment_delay_days: 0,
};

test('cas simple : 10 clients/mois, aucun churn, 5 000 de charges fixes', () => {
  const r = computeFinancials(base);
  assert.equal(r.months[0].customers, 10);
  assert.equal(r.months[11].customers, 120);
  assert.equal(r.months[0].revenue, 10_000);
  assert.equal(r.months[0].operating_result, 5_000);
  assert.equal(r.months[0].cash_balance, 25_000);
  assert.equal(r.years[0].revenue, 780_000); // 10 000 x (1 + 2 + ... + 12)
  assert.equal(r.kpis.break_even_month, 1);
  assert.equal(r.kpis.min_cash, 25_000);
  assert.equal(r.kpis.funding_gap, 0);
  assert.equal(r.kpis.ltv, null);
});

test('churn : clients(t) = clients(t-1) x (1 - churn) + nouveaux', () => {
  const r = computeFinancials({ ...base, monthly_churn_pct: 10 });
  assert.equal(r.months[1].customers, 19);
  assert.equal(r.months[2].customers, 27.1);
  assert.equal(r.kpis.ltv, 10_000); // 1 000 x 100 % de marge / 0,10
});

test('délai de paiement : 60 jours = encaissement décalé de 2 mois', () => {
  const r = computeFinancials({ ...base, payment_delay_days: 60, initial_funding: 0 });
  assert.equal(r.months[0].collections, 0);
  assert.equal(r.months[1].collections, 0);
  assert.equal(r.months[2].collections, r.months[0].revenue);
  assert.equal(r.months[0].cash_balance, -5_000); // charges payées, rien encaissé
  assert.ok(r.kpis.funding_gap > 0);
  assert.ok(r.warnings.some((w) => /trésorerie devient négative/i.test(w)));
});

test('CAC, coûts directs, frais d\'installation, hausse des prix', () => {
  const r = computeFinancials({ ...base, horizon_months: 24, cac: 500, cogs_pct: 20, setup_fee: 100, annual_price_increase_pct: 10 });
  const m1 = r.months[0];
  assert.equal(m1.revenue, 10_000 + 1_000); // abonnement + installation
  assert.equal(m1.cogs, 2_200);
  assert.equal(m1.acquisition, 5_000);
  assert.equal(m1.operating_result, 11_000 - 2_200 - 5_000 - 5_000);
  assert.equal(r.months[12].arpa, 1_100); // année 2 : prix +10 %
  assert.equal(r.kpis.cac_payback_months, 0.63); // 500 / (1 000 x 80 %)
});

test('investissement initial, tours de financement, impôt', () => {
  const r = computeFinancials({ ...base, initial_investment: 30_000, funding_rounds: [{ label: 'Prêt', month: 3, amount: 10_000 }], tax_rate_pct: 20 });
  assert.equal(r.months[0].capex, 30_000);
  assert.equal(r.months[0].tax, 1_000); // 20 % de 5 000
  // mois 1 : +10 000 encaissés -5 000 charges -1 000 impôt +20 000 financement -30 000 investissement
  assert.equal(r.months[0].cash_balance, -6_000);
  assert.equal(r.months[2].funding, 10_000);
  assert.equal(r.kpis.total_funding, 30_000);
});

test('point mort durable et récupération de l\'investissement', () => {
  // Beaucoup de charges au départ : le résultat devient positif seulement quand la base de clients grandit
  const r = computeFinancials({
    ...base, new_customers_per_month: 2, fixed_costs: [{ label: 'Équipe', monthly_amount: 9_000, start_month: 1 }], initial_investment: 10_000,
  });
  // résultat(t) = 2 000 t - 9 000 : positif dès t = 5
  assert.equal(r.kpis.break_even_month, 5);
  assert.equal(r.months[3].operating_result, -1_000);
  assert.equal(r.months[4].operating_result, 1_000);
  assert.equal(r.kpis.payback_month, 10); // cumul : somme(2 000 t - 9 000) - 10 000 >= 0
  assert.ok(r.years.length === 1);
});

test('aucun point mort : alertes générées par le code', () => {
  const r = computeFinancials({ ...base, new_customers_per_month: 1, monthly_churn_pct: 8, cac: 5_000, fixed_costs: [] });
  assert.ok(r.warnings.some((w) => /churn mensuel/i.test(w)));
  assert.ok(r.warnings.some((w) => /LTV\/CAC/.test(w)));
  assert.ok(r.warnings.some((w) => /charge fixe/i.test(w)));
});

test('horizon de 30 mois : années partielles', () => {
  const r = computeFinancials({ ...base, horizon_months: 30 });
  assert.equal(r.years.length, 3);
  assert.equal(r.years[2].months_count, 6);
  assert.equal(r.months.length, 30);
});

test('validation : prix obligatoire, bornes respectées', () => {
  assert.throws(() => parseAssumptions({ price_per_customer_month: 0 }));
  assert.throws(() => parseAssumptions({ ...base, monthly_churn_pct: 120 }));
  assert.throws(() => parseAssumptions({ ...base, horizon_months: 200 }));
  const ok = parseAssumptions({ price_per_customer_month: 50 });
  assert.equal(ok.horizon_months, 36);
  assert.equal(ok.currency, 'Ar');
});

test('empreinte stable et sensible aux changements', () => {
  const a = parseAssumptions(base);
  assert.equal(assumptionsHash(a), assumptionsHash(parseAssumptions(base)));
  assert.notEqual(assumptionsHash(a), assumptionsHash(parseAssumptions({ ...base, cac: 1 })));
});

test('mise en forme : annexe Markdown et contexte pour l\'IA', () => {
  const a = parseAssumptions(base);
  const md = annexMarkdown(a, computeFinancials(a));
  assert.match(md, /## Annexe : modèle financier/);
  assert.match(md, /\| Chiffre d'affaires \|/);
  assert.match(md, /Année 1/);
  assert.match(financialContextBlock(a, computeFinancials(a)), /font foi/);
  assert.equal(fmtNum(1234567.5, 0), '1\u00A0234\u00A0568');
  assert.equal(fmtNum(-12.345, 1), '-12,3');
});
