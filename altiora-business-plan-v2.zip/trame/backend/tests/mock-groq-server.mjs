// Faux serveur Groq (API compatible OpenAI) pour tester l'application SANS clé ni quota.
//   Terminal 1 : npm run dev:mock
//   Terminal 2 : GROQ_BASE_URL=http://localhost:4900/openai/v1 GROQ_API_KEY=test npm run dev
// Il sert aussi aux tests automatiques (npm test).
import http from 'node:http';

export const counters = { planner: 0, meta: 0, redacteur: 0, analyste: 0, review: 0, suivi: 0, suiviReview: 0, extraction: 0, redacteurWithFinancials: 0, analysteWithFinancials: 0 };

const SECTION_KEYS = ['probleme_solution', 'marche_cibles', 'offre_pricing', 'concurrence', 'strategie_commerciale', 'plan_operationnel', 'plan_financier', 'risques', 'resume_executif'];

function answer(system, user) {
  if (system.includes("agent d'extraction financière")) {
    counters.extraction++;
    return JSON.stringify({
      assumptions: {
        currency: 'Ar', price_per_customer_month: 1000000, new_customers_per_month: 2, monthly_churn_pct: 2, cac: 1500000,
        cogs_pct: 250, // valeur invalide : doit être ignorée
        setup_fee: null,
        fixed_costs: [{ label: 'Équipe', monthly_amount: 6000000, start_month: 1 }, { label: '', monthly_amount: 1 }],
      },
      found: ['Prix mensuel trouvé dans la section Offre et modèle économique'],
      missing: ['Charges fixes détaillées', 'Coût des ventes'],
    });
  }
  if (system.includes("agent de planification")) {
    counters.planner++;
    return JSON.stringify({
      title: 'Plateforme logistique pour PME de transport',
      summary: 'Un logiciel de planification de tournées pour les PME de transport.',
      sections: SECTION_KEYS.map((key) => ({
        key,
        objective: `Objectif détaillé de la section ${key} pour ce projet.`,
        key_points: ['Point clé 1', 'Point clé 2', 'Point clé 3'],
        suggested_prompt: `Rédige la section ${key} de mon business plan en t'appuyant sur mon projet.`,
      })),
    });
  }
  if (system.includes("agent méta-prompt")) {
    counters.meta++;
    const withAnswers = user.includes('reponses_aux_questions_de_guidage');
    return JSON.stringify({ meta_prompt: `Rédige la section demandée pour ce projet, de façon précise. ${withAnswers ? 'INTEGRER_REPONSES' : ''}` });
  }
  if (system.includes("agent rédacteur")) {
    counters.redacteur++;
    const title = (user.match(/Section : (.*)/) || [])[1] || 'Section';
    const withFin = user.includes('modele_financier_calcule');
    if (withFin) counters.redacteurWithFinancials++;
    const extra = user.includes('INTEGRER_REPONSES') ? '\n\n### Précisions apportées\nLes informations fournies par le porteur de projet ont été intégrées : 500 PME ciblées dans la zone.' : '';
    return `### ${title}\nNotre offre s'adresse aux décideurs des PME de transport. Le cycle de vente est estimé à 3 mois [Hypothèse à valider]. [À compléter : taille exacte du marché]${withFin ? ' [Modèle financier intégré]' : ''}${extra}`;
  }
  if (system.includes("agent analyste")) {
    counters.analyste++;
    if (user.includes('modele_financier_calcule')) counters.analysteWithFinancials++;
    const good = user.includes('Précisions apportées');
    return JSON.stringify({
      score: good ? 78 : 58,
      verdict: good ? 'Section solide, quelques chiffres restent à valider.' : 'Section prometteuse mais encore trop générale.',
      points_forts: ['Cible clairement identifiée'],
      manques: good ? ['Sources des chiffres'] : ['Taille du marché absente', 'Aucun concurrent cité'],
      questions_guidees: good ? [] : ['Combien d’entreprises cibles existent dans votre zone ?', 'Quels sont vos trois concurrents directs ?'],
      suggestion_prompt: 'Ajoute la taille du marché (TAM/SAM/SOM) et compare avec trois concurrents.',
      incoherences: [],
    });
  }
  if (system.includes("contrôle de cohérence")) {
    counters.review++;
    return JSON.stringify({ coherence_score: 82, verdict: 'Plan globalement cohérent.', incoherences: ['Le prix du résumé diffère légèrement de la section offre.'], recommandations: ['Aligner les prix entre les sections.'] });
  }
  if (system.includes("avancement réel")) {
    counters.suiviReview++;
    return JSON.stringify({ health: 'at_risk', summary: 'Le démarrage est correct mais des tâches sont en retard.', achievements: ['Première tâche terminée'], risks: ['Retards sur les pilotes'], recommendations: ['Prioriser les tâches en retard'], next_actions: ['Relancer les clients pilotes'] });
  }
  if (system.includes("plan d'exécution")) {
    counters.suivi++;
    return JSON.stringify({
      tasks: [
        { phase: 'Phase 1 : Fondations (semaines 1-4)', title: 'Signer 3 clients pilotes', description: 'Contacter les PME cibles.', kpi: 'Pilotes signés', target_value: 3, due_week: 3 },
        { phase: 'Phase 1 : Fondations (semaines 1-4)', title: 'Publier le site', description: 'Site vitrine.', kpi: 'Visites', target_value: '500', due_week: 4 },
        { phase: 'Phase 2 : Lancement (semaines 5-12)', title: 'Recruter un commercial', description: 'Profil commercial.', kpi: 'Recrutement', target_value: '1', due_week: 8 },
        { phase: 'Phase 2 : Lancement (semaines 5-12)', title: 'Atteindre 10 clients', description: 'Conversion des pilotes.', kpi: 'Clients', target_value: '10', due_week: 12 },
      ],
    });
  }
  return JSON.stringify({ ok: true });
}

export function startMockGroq(port = 4900, hooks = {}) {
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      if (hooks.before) {
        const handled = hooks.before(req, res, raw);
        if (handled) return;
      }
      if (!(req.headers.authorization || '').startsWith('Bearer ')) {
        res.writeHead(401, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ error: { message: 'Invalid API Key', code: 'invalid_api_key' } }));
      }
      if (req.method === 'GET' && req.url.endsWith('/models')) {
        res.writeHead(200, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ data: [{ id: 'openai/gpt-oss-120b' }, { id: 'openai/gpt-oss-20b' }, { id: 'llama-3.3-70b-versatile' }, { id: 'llama-3.1-8b-instant' }] }));
      }
      if (req.method === 'POST' && req.url.endsWith('/chat/completions')) {
        const body = JSON.parse(raw);
        const content = answer(body.messages[0].content, body.messages[1].content);
        res.writeHead(200, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ model: body.model, choices: [{ message: { role: 'assistant', content } }], usage: { total_tokens: 120 } }));
      }
      res.writeHead(404, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'not found' } }));
    });
  });
  return new Promise((resolve) => server.listen(port, () => resolve(server)));
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.MOCK_PORT || 4900);
  await startMockGroq(port);
  console.log(`Faux Groq prêt sur http://localhost:${port}/openai/v1`);
  console.log(`Lancez le backend avec : GROQ_BASE_URL=http://localhost:${port}/openai/v1 GROQ_API_KEY=test npm run dev`);
}
