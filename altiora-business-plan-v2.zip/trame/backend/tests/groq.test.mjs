// Tests du client Groq : erreurs, limites de débit, JSON invalide, bascule sur le modèle de secours.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';

process.env.JWT_SECRET = 'x';
process.env.GROQ_API_KEY = 'test-key';
process.env.GROQ_BASE_URL = 'http://127.0.0.1:4901/v1';
process.env.GROQ_MODEL = 'main-model';
process.env.GROQ_FALLBACK_MODEL = 'backup-model';
const { chat, chatJson, checkGroq } = await import('../src/services/groq.js');

let handler = () => {};
const log = [];
const server = http.createServer((req, res) => {
  let raw = '';
  req.on('data', (c) => (raw += c));
  req.on('end', () => {
    const body = raw ? JSON.parse(raw) : {};
    log.push({ url: req.url, model: body.model, json: Boolean(body.response_format), auth: req.headers.authorization });
    handler(req, res, body);
  });
});
await new Promise((r) => server.listen(4901, r));
test.after(() => server.close());

const send = (res, status, obj, headers = {}) => {
  res.writeHead(status, { 'content-type': 'application/json', ...headers });
  res.end(JSON.stringify(obj));
};
const ok = (content) => (req, res) => send(res, 200, { choices: [{ message: { content } }], usage: { total_tokens: 42 } });
const reset = () => (log.length = 0);

test('appel réussi : renvoie le contenu et les tokens, avec la clé en Bearer', async () => {
  reset();
  handler = ok('Bonjour');
  const r = await chat({ system: 's', user: 'u' });
  assert.equal(r.content, 'Bonjour');
  assert.equal(r.tokens, 42);
  assert.equal(log[0].auth, 'Bearer test-key');
});

test('chatJson : parse un JSON entouré de texte / de balises', async () => {
  handler = ok('Voici :\n```json\n{"a": 1}\n```');
  const r = await chatJson({ system: 's', user: 'u' });
  assert.deepEqual(r.data, { a: 1 });
});

test('chatJson : retire les balises <think> des modèles de raisonnement', async () => {
  handler = ok('<think>je réfléchis {faux}</think>{"b": 2}');
  const r = await chatJson({ system: 's', user: 'u' });
  assert.deepEqual(r.data, { b: 2 });
});

test('chatJson : refait un appel si la première réponse est illisible', async () => {
  reset();
  let n = 0;
  handler = (req, res) => ok(n++ === 0 ? 'pas du json' : '{"c": 3}')(req, res);
  const r = await chatJson({ system: 's', user: 'u' });
  assert.deepEqual(r.data, { c: 3 });
  assert.equal(log.length, 2);
});

test('json_validate_failed : réessaie sans le mode JSON', async () => {
  reset();
  handler = (req, res, body) =>
    body.response_format
      ? send(res, 400, { error: { message: 'Failed to generate JSON', code: 'json_validate_failed' } })
      : ok('{"d": 4}')(req, res);
  const r = await chatJson({ system: 's', user: 'u' });
  assert.deepEqual(r.data, { d: 4 });
  assert.equal(log[0].json, true);
  assert.equal(log[1].json, false);
});

test('429 avec retry-after court : attend puis réussit', async () => {
  reset();
  let n = 0;
  handler = (req, res) => (n++ === 0 ? send(res, 429, { error: { message: 'Rate limit reached' } }, { 'retry-after': '1' }) : ok('ok')(req, res));
  const t0 = Date.now();
  const r = await chat({ system: 's', user: 'u' });
  assert.equal(r.content, 'ok');
  assert.ok(Date.now() - t0 >= 1000, 'a bien attendu');
  assert.equal(log.length, 2);
});

test('429 quota journalier (attente longue) : bascule sur le modèle de secours', async () => {
  reset();
  handler = (req, res, body) =>
    body.model === 'main-model'
      ? send(res, 429, { error: { message: 'Rate limit reached for tokens per day. Please try again in 14m22.5s.' } })
      : ok('depuis le secours')(req, res);
  const r = await chat({ system: 's', user: 'u' });
  assert.equal(r.content, 'depuis le secours');
  assert.equal(r.model, 'backup-model');
});

test('modèle principal retiré : bascule sur le secours', async () => {
  reset();
  handler = (req, res, body) =>
    body.model === 'main-model'
      ? send(res, 400, { error: { message: 'The model has been decommissioned', code: 'model_decommissioned' } })
      : ok('secours')(req, res);
  const r = await chat({ system: 's', user: 'u' });
  assert.equal(r.model, 'backup-model');
});

test('401 : message clair, pas de bascule', async () => {
  reset();
  handler = (req, res) => send(res, 401, { error: { message: 'Invalid API Key', code: 'invalid_api_key' } });
  await assert.rejects(chat({ system: 's', user: 'u' }), (e) => e.status === 503 && /Clé Groq invalide/.test(e.message));
  assert.equal(log.length, 1);
});

test('erreur 500 puis succès : réessaie', async () => {
  reset();
  let n = 0;
  handler = (req, res) => (n++ === 0 ? send(res, 500, { error: { message: 'boom' } }) : ok('reprise')(req, res));
  const r = await chat({ system: 's', user: 'u' });
  assert.equal(r.content, 'reprise');
});

test('checkGroq : clé valide, modèles présents et appel JSON', async () => {
  handler = (req, res) =>
    req.url.endsWith('/models')
      ? send(res, 200, { data: [{ id: 'main-model' }, { id: 'backup-model' }] })
      : ok('{"ok": true}')(req, res);
  const r = await checkGroq({ deep: true });
  assert.equal(r.key_valid, true);
  assert.equal(r.model.available, true);
  assert.equal(r.fallback_model.available, true);
  assert.equal(r.json_test.ok, true);
});

test('checkGroq : détecte un modèle inexistant et une clé refusée', async () => {
  handler = (req, res) => send(res, 200, { data: [{ id: 'autre' }] });
  let r = await checkGroq();
  assert.equal(r.model.available, false);
  assert.match(r.error, /GROQ_MODEL/);
  handler = (req, res) => send(res, 401, { error: { message: 'bad' } });
  r = await checkGroq();
  assert.equal(r.key_valid, false);
});
