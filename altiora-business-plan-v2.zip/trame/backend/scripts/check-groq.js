// Vérifie la connexion à Groq : npm run check:groq
import { checkGroq } from '../src/services/groq.js';
import { env } from '../src/config/env.js';

console.log(`Modèle principal : ${env.groqModel}`);
console.log(`Modèle de secours : ${env.groqFallbackModel || '(désactivé)'}`);
const r = await checkGroq({ deep: true });
const mark = (b) => (b ? 'OK ' : 'ÉCHEC');
console.log(`${mark(r.configured)} clé présente`);
console.log(`${mark(r.key_valid)} clé valide`);
console.log(`${mark(r.model.available)} modèle principal disponible`);
if (r.fallback_model) console.log(`${mark(r.fallback_model.available)} modèle de secours disponible`);
if (r.json_test) console.log(`${mark(r.json_test.ok)} appel JSON de test ${r.json_test.latency_ms ? `(${r.json_test.latency_ms} ms)` : r.json_test.error || ''}`);
if (r.error) console.log(`\nProblème : ${r.error}`);
process.exit(r.configured && r.key_valid && r.model.available && r.json_test?.ok ? 0 : 1);
